// Le labo des neurones, mode Sumo (J5, robot 3) : les couches se règlent à la souris, le réseau s'entraîne sous les yeux
// (il se redessine à chaque époque, la courbe d'erreur descend), puis le robot est essayé contre les robots d'entraînement
// (moteur Python du jeu) et son cerveau exporté pour la stratégie de génération 3.
import { PilotePython } from "../commun/python.js";
import { creerReseau, epoque, exactitude, erreurMoyenne, exporterCerveau, preparer, predire } from "./reseau.js";
import { MODELES } from "./modeles.js";

const $ = (id) => document.getElementById(id);
const creer = (balise, classe, texte) => { const e = document.createElement(balise); if (classe) e.className = classe; if (texte !== undefined) e.textContent = texte; return e; };
const MAX_COUCHES = 4, MAX_NEURONES = 16;
const NOMS_ENTREES = ["distance", "énergie (moi)", "énergie (adversaire)", "bord derrière moi", "bord derrière lui", "il a poussé"];

const etat = { cachees: [8, 6], reseau: null, donnees: null, actions: [], lignes: [], courbe: [], enCours: false, pause: false, onglet: "essai", essai: null };
const pilote = new PilotePython((nom) => {
  const e = $("etat-python");
  if (nom === "pret") { e.textContent = "Python est prêt"; e.className = "etat-python pret"; }
  if (nom === "echec") { e.textContent = "Python n'a pas pu se charger. Rechargez la page."; e.className = "etat-python echec"; }
});

function nouveauReseau() {
  etat.reseau = creerReseau([6, ...etat.cachees, etat.actions.length || 5]);
  etat.courbe = []; etat.essai = null;
  dessinerReseau(); dessinerCourbe(); chiffres(); afficher(etat.onglet);
}

// ---------- le dessin du réseau ----------
let zonesCouches = [];
function dessinerReseau() {
  const c = $("dessin-reseau"), ctx = c.getContext("2d"), r = window.devicePixelRatio || 1;
  const l = c.clientWidth, h = c.clientHeight; c.width = l * r; c.height = h * r; ctx.setTransform(r, 0, 0, r, 0, 0);
  ctx.fillStyle = "#131419"; ctx.fillRect(0, 0, l, h);
  const tailles = [6, ...etat.cachees, etat.actions.length || 5], n = tailles.length;
  const x = (k) => 120 + (k * (l - 260)) / (n - 1);
  const y = (k, i) => { const t = tailles[k], esp = Math.min(46, (h - 80) / Math.max(1, t)); return h / 2 - ((t - 1) * esp) / 2 + i * esp; };
  // les poids
  const couches = etat.reseau ? etat.reseau.couches : [];
  const maxi = Math.max(0.001, ...couches.flatMap((cc) => cc.flatMap((ne) => ne.poids.map(Math.abs))));
  couches.forEach((couche, k) => couche.forEach((ne, j) => ne.poids.forEach((p, i) => {
    ctx.strokeStyle = p >= 0 ? `rgba(242,140,30,${0.15 + 0.85 * Math.abs(p) / maxi})` : `rgba(80,160,255,${0.15 + 0.85 * Math.abs(p) / maxi})`;
    ctx.lineWidth = 0.4 + 4 * Math.abs(p) / maxi;
    ctx.beginPath(); ctx.moveTo(x(k), y(k, i)); ctx.lineTo(x(k + 1), y(k + 1, j)); ctx.stroke();
  })));
  // les neurones
  zonesCouches = [];
  tailles.forEach((t, k) => {
    for (let i = 0; i < t; i++) {
      ctx.beginPath(); ctx.arc(x(k), y(k, i), 11, 0, Math.PI * 2);
      ctx.fillStyle = k === 0 ? "#2e2a4a" : k === n - 1 ? "#1f4d36" : "#3a3d48"; ctx.fill();
      ctx.strokeStyle = "#e8e3d6"; ctx.lineWidth = 1.5; ctx.stroke();
    }
    ctx.fillStyle = "#cfd3dc"; ctx.font = "13px Barlow, sans-serif"; ctx.textAlign = k === 0 ? "right" : k === n - 1 ? "left" : "center";
    if (k === 0) NOMS_ENTREES.forEach((nom, i) => ctx.fillText(nom, x(k) - 18, y(k, i) + 4));
    else if (k === n - 1) (etat.actions.length ? etat.actions : ["", "", "", "", ""]).forEach((a, i) => ctx.fillText(a, x(k) + 18, y(k, i) + 4));
    else {
      ctx.fillText(`${t} neurones`, x(k), 22);
      zonesCouches.push({ k: k - 1, x1: x(k) - 30, x2: x(k) + 30 });
    }
  });
  ctx.textAlign = "center"; ctx.fillStyle = "#f5b82e"; ctx.fillText("entrées", x(0), h - 14); ctx.fillText("actions", x(n - 1), h - 14);
}

// ---------- la courbe et les chiffres ----------
function dessinerCourbe() {
  const c = $("courbe"), ctx = c.getContext("2d"), r = window.devicePixelRatio || 1;
  const l = c.clientWidth, h = c.clientHeight; c.width = l * r; c.height = h * r; ctx.setTransform(r, 0, 0, r, 0, 0);
  ctx.clearRect(0, 0, l, h);
  ctx.strokeStyle = "#dad6e8"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(36, 8); ctx.lineTo(36, h - 22); ctx.lineTo(l - 6, h - 22); ctx.stroke();
  ctx.fillStyle = "#3a3a48"; ctx.font = "12px Barlow, sans-serif"; ctx.fillText("erreur", 2, 14); ctx.fillText("époques", l - 52, h - 6);
  const pts = etat.courbe; if (pts.length < 2) return;
  const maxi = Math.max(...pts.map((p) => Math.max(p.ent, p.test))), mini = 0;
  const X = (i) => 36 + (i * (l - 46)) / (pts.length - 1), Y = (v) => (h - 22) - ((v - mini) / (maxi - mini || 1)) * (h - 34);
  for (const [cle, couleur] of [["ent", "#17824C"], ["test", "#c27a3e"]]) {
    ctx.strokeStyle = couleur; ctx.lineWidth = 2; ctx.beginPath();
    pts.forEach((p, i) => (i ? ctx.lineTo(X(i), Y(p[cle])) : ctx.moveTo(X(i), Y(p[cle])))); ctx.stroke();
  }
  ctx.fillStyle = "#17824C"; ctx.fillText("entraînement", 44, 14); ctx.fillStyle = "#c27a3e"; ctx.fillText("test", 130, 14);
}
function chiffres() {
  const z = $("chiffres"); z.innerHTML = "";
  if (!etat.donnees) { z.textContent = "Chargement des données…"; return; }
  const der = etat.courbe.at(-1);
  const params = etat.reseau.couches.reduce((s, c) => s + c.length * (c[0].poids.length + 1), 0);
  z.append(creer("div", "", `Réseau : 6 → ${etat.cachees.join(" → ") || "aucune couche cachée"} → ${etat.actions.length}`),
    creer("div", "", `${params} poids et biais`), creer("div", "", `${etat.courbe.length} époque(s)`));
  if (der) {
    const b = creer("div"); b.append(creer("strong", "", `${Math.round(der.exact * 100)} %`), document.createTextNode(" de bonnes réponses sur les données de test")); z.append(b);
  }
}

// ---------- l'entraînement : quelques époques par image, la page reste fluide ----------
async function entrainer() {
  if (etat.enCours || !etat.donnees) return;
  etat.enCours = true; etat.pause = false;
  $("bouton-entrainer").disabled = true; $("bouton-pause").disabled = false;
  const total = Number($("choix-epoques").value), taux = Number($("choix-taux").value);
  try {
    for (let e = 0; e < total; e++) {
      while (etat.pause) await new Promise((ok) => setTimeout(ok, 100));
      const ent = epoque(etat.reseau, etat.donnees.entrainement, { taux });
      etat.courbe.push({ ent, test: erreurMoyenne(etat.reseau, etat.donnees.test), exact: exactitude(etat.reseau, etat.donnees.test) });
      if (e % 2 === 1 || e === total - 1) { dessinerReseau(); dessinerCourbe(); chiffres(); await new Promise((ok) => requestAnimationFrame(ok)); }
    }
  } finally {
    etat.enCours = false; $("bouton-entrainer").disabled = false; $("bouton-pause").disabled = true;
    etat.essai = null; afficher(etat.onglet);
  }
}

// ---------- essayer et exporter ----------
const codeRobot = () => MODELES[3].replace("CERVEAU = None", exporterCerveau(etat.reseau, etat.actions));
async function essayer() {
  const p = $("panneau"); p.innerHTML = ""; p.append(creer("p", "", "Le robot affronte les cinq robots d'entraînement, en A puis en B…"));
  const r = await pilote.sumo("bilan", [{ nom: "robot 3", code: codeRobot() }], 30000);
  etat.essai = r; afficher("essai");
}
function afficher(nom) {
  etat.onglet = nom;
  for (const o of document.querySelectorAll(".onglet")) o.setAttribute("aria-selected", String(o.dataset.onglet === nom));
  const p = $("panneau"); p.innerHTML = "";
  if (nom === "essai") {
    const b = creer("button", "bouton principal", "Essayer contre les robots d'entraînement"); b.type = "button"; b.addEventListener("click", essayer);
    p.append(b);
    if (!etat.courbe.length) p.append(creer("p", "vide", "Un réseau non entraîné joue presque au hasard : entraînez-le d'abord, puis essayez-le."));
    const r = etat.essai;
    if (r && r.erreur) p.append(creer("p", "erreur", r.erreur.message));
    else if (r) {
      p.append(creer("p", "", `${r.victoires} victoire(s) sur ${r.combats}.`));
      const t = creer("table", "tours"), tete = creer("tr"); ["Adversaire", "En A", "En B"].forEach((x) => tete.append(creer("th", "", x))); t.append(tete);
      for (const l of r.lignes) { const tr = creer("tr"); tr.append(creer("td", "", l.adversaire), creer("td", l.enA === "gagné" ? "gagne" : l.enA === "perdu" ? "perdu" : "", l.enA), creer("td", l.enB === "gagné" ? "gagne" : l.enB === "perdu" ? "perdu" : "", l.enB)); t.append(tr); }
      p.append(t);
    }
  } else {
    const zone = creer("textarea", "cerveau"); zone.readOnly = true; zone.value = exporterCerveau(etat.reseau, etat.actions);
    const copier = creer("button", "bouton principal", "Copier le cerveau"); copier.type = "button";
    copier.addEventListener("click", async () => { zone.select(); try { await navigator.clipboard.writeText(zone.value); copier.textContent = "Copié"; } catch { document.execCommand("copy"); copier.textContent = "Copié"; } });
    const ouvrir = creer("button", "bouton", "Ouvrir dans l'atelier (génération 3)"); ouvrir.type = "button";
    ouvrir.addEventListener("click", () => {
      try {
        const cle = "jeux-python.sumo.v1", m = JSON.parse(localStorage.getItem(cle)) || {};
        m.codes = m.codes || {}; m.codes[3] = codeRobot(); m.generation = 3; localStorage.setItem(cle, JSON.stringify(m));
      } catch { /* navigation privée */ }
      location.href = "sumo.html";
    });
    const rangee = creer("div", "envoi"); rangee.append(copier, ouvrir);
    p.append(creer("p", "", "Collez cette ligne à la place de « CERVEAU = None » dans votre robot de génération 3 (atelier du sumo, ou robot3.py dans VS Code)."), zone, rangee);
  }
}

// ---------- les données ----------
function ajouterDecisionsCSV(texte) {
  const lignes = texte.trim().split(/\r?\n/), tete = lignes.shift().split(";");
  const col = (n) => tete.indexOf(n), cles = ["distance", "energie_moi", "energie_adversaire", "bord_moi", "bord_adversaire", "adversaire_a_pousse"];
  if (cles.some((k) => col(k) < 0) || col("action") < 0 || col("issue") < 0) throw new Error("Ce fichier n'a pas les colonnes d'un fichier de décisions (export « Décisions des robots » du tournoi).");
  const compte = new Map(); let n = 0;
  for (const l of lignes) {
    const v = l.split(";");
    if (v[col("issue")] !== "gagne" || v[col("valide")] !== "True") continue;
    const y = etat.actions.indexOf(v[col("action")]); if (y < 0) continue;
    const cle = [...cles.map((k) => Number(v[col(k)])), y].join(","); compte.set(cle, (compte.get(cle) || 0) + 1); n++;
  }
  for (const [cle, k] of compte) etat.lignes.push([...cle.split(",").map(Number), k]);
  etat.donnees = preparer(etat.lignes);
  return n;
}

async function demarrer() {
  const d = await (await fetch("sumo/decisions-gagnants.json")).json();
  etat.actions = d.actions; etat.lignes = d.lignes; etat.donnees = preparer(d.lignes);
  $("texte-donnees").textContent = `Les données : ${d.decisions} décisions des robots gagnants (${d.lignes.length} situations différentes), tirées de ${d.combats.toLocaleString("fr-BE")} combats entre les robots d'entraînement. Entrée : six nombres ; sortie : l'action jouée. Un quart des situations est gardé de côté pour le test.`;
  nouveauReseau();
  $("bouton-entrainer").addEventListener("click", entrainer);
  $("bouton-pause").addEventListener("click", () => { etat.pause = !etat.pause; $("bouton-pause").textContent = etat.pause ? "Reprendre" : "Pause"; });
  $("bouton-zero").addEventListener("click", () => { if (!etat.enCours) nouveauReseau(); });
  $("couche-plus").addEventListener("click", () => { if (!etat.enCours && etat.cachees.length < MAX_COUCHES) { etat.cachees.push(6); nouveauReseau(); } });
  $("couche-moins").addEventListener("click", () => { if (!etat.enCours && etat.cachees.length) { etat.cachees.pop(); nouveauReseau(); } });
  $("dessin-reseau").addEventListener("click", (ev) => {
    if (etat.enCours) return;
    const r = ev.currentTarget.getBoundingClientRect(), x = ev.clientX - r.left;
    const z = zonesCouches.find((c) => x >= c.x1 && x <= c.x2); if (!z) return;
    etat.cachees[z.k] = Math.max(1, Math.min(MAX_NEURONES, etat.cachees[z.k] + (ev.shiftKey ? -1 : 1)));
    nouveauReseau();
  });
  $("fichier-decisions").addEventListener("change", async (ev) => {
    const f = ev.target.files[0]; ev.target.value = ""; if (!f) return;
    try { const n = ajouterDecisionsCSV(await f.text()); $("texte-donnees").textContent += ` Ajouté : ${n} décisions gagnantes de ${f.name}.`; nouveauReseau(); }
    catch (e) { $("panneau").prepend(creer("p", "erreur", e.message)); }
  });
  for (const o of document.querySelectorAll(".onglet")) o.addEventListener("click", () => afficher(o.dataset.onglet));
  new ResizeObserver(() => { dessinerReseau(); dessinerCourbe(); }).observe(document.body);
}
demarrer();
window.labo = { etat, entrainer, predire };
