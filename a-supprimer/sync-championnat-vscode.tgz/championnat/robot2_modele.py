"""Votre robot de combat · génération 2, machine learning. Binôme : (vos prénoms)

Les règles de ce robot ne sont pas écrites à l'intuition : elles viennent d'un arbre de décision entraîné sur les
décisions qui ont mené à la victoire, celles des robots d'entraînement et celles des joueurs de la classe
(notebook robot2_arbre.ipynb, export_text). Recopiez l'arbre en if / elif. Il parle avec les nombres calculés au début.
"""
import regles


def strategie(etat):
    adv = etat["adversaire"]
    distance = etat["distance"]
    vie_moi, vie_adversaire = etat["moi"]["vie"], adv["vie"]
    energie_moi, energie_adversaire = etat["moi"]["energie"], adv["energie"]
    bord_moi, bord_adversaire = etat["moi"]["bord_derriere"], adv["bord_derriere"]
    adv_prepare = 1 if adv["phase"] == "preparation" else 0
    adv_frappe = 1 if adv["phase"] == "frappe" else 0
    adv_recupere = 1 if adv["phase"] == "recuperation" else 0
    adv_garde = 1 if adv["phase"] == "garde" else 0
    adv_sonne = 1 if adv["phase"] == "sonne" else 0
    adv_reste = adv["reste"]

    # Recopiez ici les règles de l'arbre. Une ligne « |--- distance <= 150.00 » devient « if distance <= 150.00: »,
    # la ligne « class: direct » en dessous devient « action = "direct" ».
    action = "garde"

    # sécurité : une action trop chère est refusée, et le robot perdrait l'instant
    cout = regles.COUPS[action]["energie"] if action in regles.COUPS else regles.ESQUIVE["energie"] if action == "esquive" else 0
    if cout > energie_moi:
        action = "garde"
    return action
