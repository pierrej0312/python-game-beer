"""Corrigé du robot 2 (notebook robot2_arbre.ipynb, max_depth=4, random_state=0).

Les règles de ce robot ne sont pas écrites à l'intuition : elles viennent d'un arbre de décision entraîné sur les
décisions qui ont mené à la victoire, celles des robots d'entraînement et celles des joueurs de la classe
(notebook robot2_arbre.ipynb, export_text). Recopiez l'arbre en if / elif. Il parle avec les nombres calculés au début.
"""
import regles


def strategie(etat):
    adv = etat["adversaire"]
    distance = etat["distance"]
    vie_moi, vie_adversaire = etat["moi"]["vie"], adv["vie"]
    energie_moi, energie_adversaire = etat["moi"]["energie"], adv["energie"]
    bord_moi, bord_adversaire = etat["moi"]["bord_derriere"], adv["bord_derriere"]
    adv_prepare = 1 if adv["phase"] == "preparation" else 0
    adv_frappe = 1 if adv["phase"] == "frappe" else 0
    adv_recupere = 1 if adv["phase"] == "recuperation" else 0
    adv_garde = 1 if adv["phase"] == "garde" else 0
    adv_sonne = 1 if adv["phase"] == "sonne" else 0
    adv_reste = adv["reste"]

    # Recopiez ici les règles de l'arbre. Une ligne « |--- distance <= 150.00 » devient « if distance <= 150.00: »,
    # la ligne « class: direct » en dessous devient « action = "direct" ».
    if distance <= 222.50:
        if energie_moi <= 58.50:
            if bord_adversaire <= 493.50:
                if distance <= 171.00:
                    action = "garde"
                else:
                    action = "avancer"
            else:
                if adv_prepare <= 0.50:
                    action = "garde"
                else:
                    action = "garde"
        else:
            if adv_recupere <= 0.50:
                if distance <= 172.50:
                    action = "garde"
                else:
                    action = "garde"
            else:
                if distance <= 162.50:
                    action = "direct"
                else:
                    action = "garde"
    else:
        if energie_moi <= 69.50:
            if energie_adversaire <= 49.50:
                if bord_moi <= 50.50:
                    action = "avancer"
                else:
                    action = "avancer"
            else:
                if adv_reste <= 2.50:
                    action = "avancer"
                else:
                    action = "avancer"
        else:
            if energie_adversaire <= 6.50:
                if adv_prepare <= 0.50:
                    action = "special"
                else:
                    action = "avancer"
            else:
                if energie_adversaire <= 9.50:
                    action = "avancer"
                else:
                    action = "avancer"

    # sécurité : une action trop chère est refusée, et le robot perdrait l'instant
    cout = regles.COUPS[action]["energie"] if action in regles.COUPS else regles.ESQUIVE["energie"] if action == "esquive" else 0
    if cout > energie_moi:
        action = "garde"
    return action
