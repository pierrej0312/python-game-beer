def nombre_de_tournees(casiers):
    """Renvoie le nombre de tournées nécessaires pour sortir tous les casiers."""
    pass
