"""Corrigé du robot 2 (notebook robot2_arbre.ipynb, max_depth=3, random_state=0).

Les règles de ce robot ne sont pas écrites à l'intuition : elles viennent d'un arbre de décision
entraîné sur les décisions des robots gagnants (notebook robot2_arbre.ipynb, export_text).
Recopiez l'arbre en if / elif. L'arbre parle avec les six nombres calculés au début de la fonction.
"""
import regles


def strategie(etat):
    distance = etat["distance"]
    energie_moi = etat["moi"]["energie"]
    energie_adversaire = etat["adversaire"]["energie"]
    bord_moi = etat["bord_derriere_moi"]
    bord_adversaire = etat["bord_derriere_adversaire"]
    adversaire_a_pousse = 1 if etat["dernier_coup_adversaire"] == "pousser" else 0

    # L'arbre appris (export_text) :
    # |--- energie_moi <= 0.50
    # |   |--- class: recharger
    # |--- energie_moi >  0.50
    # |   |--- distance <= 1.50
    # |   |   |--- energie_moi <= 2.50
    # |   |   |   |--- class: recharger
    # |   |   |--- energie_moi >  2.50
    # |   |   |   |--- class: pousser
    # |   |--- distance >  1.50
    # |   |   |--- energie_moi <= 3.50
    # |   |   |   |--- class: avancer
    # |   |   |--- energie_moi >  3.50
    # |   |   |   |--- class: avancer
    if energie_moi <= 0.50:
        action = "recharger"
    else:
        if distance <= 1.50:
            if energie_moi <= 2.50:
                action = "recharger"
            else:
                action = "pousser"
        else:
            if energie_moi <= 3.50:
                action = "avancer"
            else:
                action = "avancer"

    # sécurité : une action trop chère est refusée, et le robot perdrait son tour
    if regles.COUT[action] > energie_moi:
        action = "recharger"
    return action
