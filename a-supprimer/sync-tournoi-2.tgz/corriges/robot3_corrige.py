"""Corrigé du robot 3 (notebook robot3_reseau.ipynb, couches (8, 6), random_state=0).

Le cerveau de ce robot est un réseau de neurones entraîné sur les décisions des robots gagnants,
dans le labo des neurones (mode Sumo) ou dans le notebook. Collez la ligne « CERVEAU = {...} » exportée
à la place de « CERVEAU = {'actions': ['ancrer', 'avancer', 'pousser', 'recharger', 'reculer'], 'couches': [[[[-0.13, 2.732, -0.095, 0.119, 0.048, -0.866], 0.091], [[1.382, 0.04, -0.071, -0.064, 0.185, 0.738], 0.3], [[-0.149, 1.513, 0.263, -0.474, -0.291, 3.152], 0.324], [[-3.494, 0.253, -0.071, 0.978, 1.156, 0.7], -0.157], [[-0.037, -2.551, -0.008, 0.409, 0.721, 3.207], 1.038], [[-0.448, 2.223, 0.058, 0.323, 0.226, -0.268], -0.366], [[-0.0, -0.0, 0.0, 0.0, -0.0, -0.0], -0.381], [[0.303, -0.63, -0.063, 0.913, 0.923, 0.258], 0.209]], [[[0.132, -0.397, -0.377, -0.355, -0.56, 0.78, -0.0, 0.852], 0.264], [[-1.182, -0.963, -0.975, -1.346, 1.453, -0.472, 0.0, 0.642], 1.255], [[1.194, -2.705, 0.755, 1.162, 1.277, -1.098, -0.0, -0.558], 0.602], [[-2.632, -0.817, -0.92, 1.523, 0.983, 4.011, 0.0, 0.312], 0.392], [[-0.664, 0.06, 1.14, -3.172, 0.269, 0.783, -0.0, 0.906], -0.274], [[-0.52, -0.8, -0.715, -3.096, 0.634, 1.382, 0.0, 0.872], 0.936]], [[[-0.441, 1.441, 0.819, -0.266, -0.679, -2.086], 1.173], [[-0.186, 0.928, 0.483, -4.438, 1.375, 1.149], -0.64], [[-0.482, -8.532, 1.945, -2.053, -2.756, 1.285], 0.691], [[1.404, 0.676, -1.767, 4.536, 0.063, 0.804], 0.573], [[-0.065, 1.163, 0.023, -1.567, -0.199, -0.504], -0.413]]]} ». La stratégie fait le calcul couche par couche, avec la fonction neurone.
"""
import regles

CERVEAU = {'actions': ['ancrer', 'avancer', 'pousser', 'recharger', 'reculer'], 'couches': [[[[-0.13, 2.732, -0.095, 0.119, 0.048, -0.866], 0.091], [[1.382, 0.04, -0.071, -0.064, 0.185, 0.738], 0.3], [[-0.149, 1.513, 0.263, -0.474, -0.291, 3.152], 0.324], [[-3.494, 0.253, -0.071, 0.978, 1.156, 0.7], -0.157], [[-0.037, -2.551, -0.008, 0.409, 0.721, 3.207], 1.038], [[-0.448, 2.223, 0.058, 0.323, 0.226, -0.268], -0.366], [[-0.0, -0.0, 0.0, 0.0, -0.0, -0.0], -0.381], [[0.303, -0.63, -0.063, 0.913, 0.923, 0.258], 0.209]], [[[0.132, -0.397, -0.377, -0.355, -0.56, 0.78, -0.0, 0.852], 0.264], [[-1.182, -0.963, -0.975, -1.346, 1.453, -0.472, 0.0, 0.642], 1.255], [[1.194, -2.705, 0.755, 1.162, 1.277, -1.098, -0.0, -0.558], 0.602], [[-2.632, -0.817, -0.92, 1.523, 0.983, 4.011, 0.0, 0.312], 0.392], [[-0.664, 0.06, 1.14, -3.172, 0.269, 0.783, -0.0, 0.906], -0.274], [[-0.52, -0.8, -0.715, -3.096, 0.634, 1.382, 0.0, 0.872], 0.936]], [[[-0.441, 1.441, 0.819, -0.266, -0.679, -2.086], 1.173], [[-0.186, 0.928, 0.483, -4.438, 1.375, 1.149], -0.64], [[-0.482, -8.532, 1.945, -2.053, -2.756, 1.285], 0.691], [[1.404, 0.676, -1.767, 4.536, 0.063, 0.804], 0.573], [[-0.065, 1.163, 0.023, -1.567, -0.199, -0.504], -0.413]]]}


def neurone(entrees, poids, biais):
    return sum(e * p for e, p in zip(entrees, poids)) + biais


def caracteristiques(etat):
    """Les six nombres que voit le robot : les mêmes que pendant l'entraînement, dans le même ordre."""
    return [etat["distance"], etat["moi"]["energie"], etat["adversaire"]["energie"],
            etat["bord_derriere_moi"], etat["bord_derriere_adversaire"],
            1 if etat["dernier_coup_adversaire"] == "pousser" else 0]


def strategie(etat):
    if CERVEAU is None:
        return "recharger"
    valeurs = [x / 10 for x in caracteristiques(etat)]        # comme à l'entraînement : les entrées divisées par 10
    couches = CERVEAU["couches"]
    for numero, couche in enumerate(couches):
        valeurs = [neurone(valeurs, poids, biais) for poids, biais in couche]
        if numero < len(couches) - 1:
            valeurs = [max(0, v) for v in valeurs]              # ReLU sur les couches cachées
    action = CERVEAU["actions"][valeurs.index(max(valeurs))]   # la sortie la plus forte décide
    if regles.COUT[action] > etat["moi"]["energie"]:
        action = "recharger"
    return action
