"""Votre robot de sumo · génération 2, machine learning. Binôme : (vos prénoms)

Les règles de ce robot ne sont pas écrites à l'intuition : elles viennent d'un arbre de décision
entraîné sur les décisions des robots gagnants (notebook robot2_arbre.ipynb, export_text).
Recopiez l'arbre en if / elif. L'arbre parle avec les six nombres calculés au début de la fonction.
"""
import regles


def strategie(etat):
    distance = etat["distance"]
    energie_moi = etat["moi"]["energie"]
    energie_adversaire = etat["adversaire"]["energie"]
    bord_moi = etat["bord_derriere_moi"]
    bord_adversaire = etat["bord_derriere_adversaire"]
    adversaire_a_pousse = 1 if etat["dernier_coup_adversaire"] == "pousser" else 0

    # Recopiez ici les règles de l'arbre. Une ligne « |--- energie_moi <= 0.50 » devient « if energie_moi <= 0.50: »,
    # la ligne « class: recharger » en dessous devient « action = "recharger" ».
    action = "recharger"

    # sécurité : une action trop chère est refusée, et le robot perdrait son tour
    if regles.COUT[action] > energie_moi:
        action = "recharger"
    return action
