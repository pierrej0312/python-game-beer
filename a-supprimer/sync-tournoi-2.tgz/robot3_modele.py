"""Votre robot de sumo · génération 3, réseau de neurones. Binôme : (vos prénoms)

Le cerveau de ce robot est un réseau de neurones entraîné sur les décisions des robots gagnants,
dans le labo des neurones (mode Sumo) ou dans le notebook. Collez la ligne « CERVEAU = {...} » exportée
à la place de « CERVEAU = None ». La stratégie fait le calcul couche par couche, avec la fonction neurone.
"""
import regles

CERVEAU = None


def neurone(entrees, poids, biais):
    return sum(e * p for e, p in zip(entrees, poids)) + biais


def caracteristiques(etat):
    """Les six nombres que voit le robot : les mêmes que pendant l'entraînement, dans le même ordre."""
    return [etat["distance"], etat["moi"]["energie"], etat["adversaire"]["energie"],
            etat["bord_derriere_moi"], etat["bord_derriere_adversaire"],
            1 if etat["dernier_coup_adversaire"] == "pousser" else 0]


def strategie(etat):
    if CERVEAU is None:
        return "recharger"
    valeurs = [x / 10 for x in caracteristiques(etat)]        # comme à l'entraînement : les entrées divisées par 10
    couches = CERVEAU["couches"]
    for numero, couche in enumerate(couches):
        valeurs = [neurone(valeurs, poids, biais) for poids, biais in couche]
        if numero < len(couches) - 1:
            valeurs = [max(0, v) for v in valeurs]              # ReLU sur les couches cachées
    action = CERVEAU["actions"][valeurs.index(max(valeurs))]   # la sortie la plus forte décide
    if regles.COUT[action] > etat["moi"]["energie"]:
        action = "recharger"
    return action
