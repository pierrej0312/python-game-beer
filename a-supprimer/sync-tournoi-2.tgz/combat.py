"""Faites combattre votre robot (strategie.py) contre les robots d'entraînement.

    python combat.py                 bilan contre tous les robots d'entraînement, aller et retour
    python combat.py foncer          un combat contre foncer, tour par tour
    python combat.py foncer --journal combat.csv    le même, et son journal en CSV
    python combat.py --robot robot2.py               un autre fichier que strategie.py (robots 2 et 3)
"""
import importlib.util
import sys
from pathlib import Path

import regles as R
from moteur_combat import combattre, ecrire_journal
from strategies_reference import REFERENCES


def charger(chemin="strategie.py"):
    """Charge la fonction strategie d'un fichier .py."""
    spec = importlib.util.spec_from_file_location("strategie_joueur", chemin)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not hasattr(module, "strategie"):
        sys.exit(f"{chemin} ne contient pas de fonction strategie(etat).")
    return module.strategie


def plateforme(a, b):
    cases = ["."] * R.TAILLE_PLATEFORME
    if 0 <= a < R.TAILLE_PLATEFORME: cases[a] = "A"
    if 0 <= b < R.TAILLE_PLATEFORME: cases[b] = "B"
    gauche = "x" if a < 0 else " "
    droite = "x" if b >= R.TAILLE_PLATEFORME else " "
    return f"{gauche}[{' '.join(cases)}]{droite}"


def raconter(resultat, nom_a, nom_b):
    print(f"A = {nom_a}   B = {nom_b}")
    print(f"tour  {'plateforme':<{2 * R.TAILLE_PLATEFORME + 3}}  énergie A/B  actions")
    for l in resultat["journal"]:
        act_a = l["action_a"] if l["valide_a"] else f"{l['action_a']} (refusé : {l['raison_a']})"
        act_b = l["action_b"] if l["valide_b"] else f"{l['action_b']} (refusé : {l['raison_b']})"
        print(f"{l['tour']:>4}  {plateforme(l['position_a'], l['position_b'])}  {l['energie_a']:>4} / {l['energie_b']:<4}  A {act_a}  ·  B {act_b}")
    v = resultat["vainqueur"]
    qui = {"a": f"A ({nom_a})", "b": f"B ({nom_b})", "egalite": "égalité"}[v]
    comment = "un robot est sorti de la plateforme" if resultat["fin"] == "sortie" else f"{R.TOURS_MAX} tours joués"
    print(f"Résultat : {qui} ({comment}).")


def bilan(ma_strategie):
    print(f"{'adversaire':<10}  {'vous en A':<10}  {'vous en B':<10}")
    victoires = 0
    for nom, autre in REFERENCES.items():
        r1 = combattre(ma_strategie, autre, "vous", nom)["vainqueur"]
        r2 = combattre(autre, ma_strategie, nom, "vous")["vainqueur"]
        en_a = {"a": "gagné", "b": "perdu", "egalite": "égalité"}[r1]
        en_b = {"b": "gagné", "a": "perdu", "egalite": "égalité"}[r2]
        victoires += (r1 == "a") + (r2 == "b")
        print(f"{nom:<10}  {en_a:<10}  {en_b:<10}")
    print(f"Victoires : {victoires} sur {2 * len(REFERENCES)}. Revoyez un combat : python combat.py <adversaire>")


if __name__ == "__main__":
    dossier = Path(__file__).resolve().parent
    args = sys.argv[1:]
    fichier = "strategie.py"
    if "--robot" in args:
        i = args.index("--robot")
        fichier = args[i + 1]
        del args[i:i + 2]
    ma_strategie = charger(dossier / fichier)
    if not args:
        bilan(ma_strategie)
    else:
        nom = args[0]
        if nom not in REFERENCES:
            sys.exit(f"Robot inconnu : {nom}. Robots d'entraînement : {', '.join(REFERENCES)}.")
        resultat = combattre(ma_strategie, REFERENCES[nom], "vous", nom)
        raconter(resultat, "vous", nom)
        if "--journal" in args:
            chemin = args[args.index("--journal") + 1]
            ecrire_journal(resultat["journal"], chemin)
            print(f"Journal enregistré : {chemin}")
