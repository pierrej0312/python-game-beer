"""Fabrique les données d'entraînement des robots 2 et 3 : des milliers de combats entre les robots d'entraînement.

    python donnees_apprentissage.py            écrit decisions.csv (une ligne par décision d'un robot)

Chaque ligne : ce que le robot voyait (les mêmes valeurs que dans etat), l'action qu'il a choisie, et l'issue du combat
pour lui (gagne, perdu, egalite). Pour apprendre « ce que font les gagnants », on garde les lignes gagne et valides.

Pour varier les situations, les robots d'entraînement jouent parfois un coup au hasard (10 % ou 25 % des tours, selon
le combat). Graine fixe : le fichier est le même à chaque fois.
"""
import csv
import random

import regles as R
from moteur_combat import combattre
from strategies_reference import REFERENCES
from apprentissage import caracteristiques

COLONNES = ["combat_id", "tour", "robot", "adversaire", "distance", "energie_moi", "energie_adversaire",
            "bord_moi", "bord_adversaire", "adversaire_a_pousse", "action", "au_hasard", "valide", "issue", "fin"]


def espionne(nom, strategie, bruit, hasard, carnet):
    """Enveloppe une stratégie : note chaque décision (ce que voyait le robot, l'action) ; joue parfois au hasard."""
    def jouer(etat):
        au_hasard = hasard.random() < bruit
        if au_hasard:
            possibles = [a for a, c in R.COUT.items() if c <= etat["moi"]["energie"]]
            action = hasard.choice(possibles)
        else:
            action = strategie(etat)
        carnet.append((etat["tour"], caracteristiques(etat), action, au_hasard))
        return action
    return jouer


def produire(chemin="decisions.csv", graines=24):
    hasard = random.Random(R.GRAINE)
    lignes, n = [], 0
    noms = list(REFERENCES)
    for bruit in (0.0, 0.10, 0.25):
        for g in range(graines if bruit else 1):
            for na in noms:
                for nb in noms:
                    carnet_a, carnet_b = [], []
                    sa = espionne(na, REFERENCES[na], bruit, hasard, carnet_a)
                    sb = espionne(nb, REFERENCES[nb], bruit, hasard, carnet_b)
                    cid = f"{na}-vs-{nb}-b{int(bruit * 100)}-{g}"
                    r = combattre(sa, sb, na, nb, graine=R.GRAINE + g, combat_id=cid)
                    n += 1
                    issue = {"a": ("gagne", "perdu"), "b": ("perdu", "gagne"), "egalite": ("egalite", "egalite")}[r["vainqueur"]]
                    for cote, carnet, nom, autre, iss in (("a", carnet_a, na, nb, issue[0]), ("b", carnet_b, nb, na, issue[1])):
                        for (tour, c, action, au_hasard), ligne in zip(carnet, r["journal"]):
                            lignes.append(dict(zip(COLONNES, [cid, tour, nom, autre, *c, action, au_hasard, ligne[f"valide_{cote}"], iss, r["fin"]])))
    with open(chemin, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLONNES, delimiter=";")
        w.writeheader()
        w.writerows(lignes)
    return n, len(lignes)


if __name__ == "__main__":
    combats, decisions = produire()
    print(f"{combats} combats, {decisions} décisions : decisions.csv")
