# Tests de la mission 3.2 (atelier). « test_ » : étoile 1 ; « bonus_ » : étoile 3.
# Mission à fonction : les cas de test sont dans mission.json (« cas »).
