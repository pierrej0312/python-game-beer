import json, sys
sys.path.insert(0, "/home/claude/depot/site/python")
import ligne
d = json.load(sys.stdin)
print(json.dumps(ligne.executer_ligne(d["code"], d["niveau"], d["tests"], d["suivre"]), ensure_ascii=False))
