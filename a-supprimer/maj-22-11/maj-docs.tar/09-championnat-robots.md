# Le championnat des robots (remplace le sumo, décidé le 21/11/2026)

Retour du formateur : le sumo « moche » décevrait des stagiaires à qui l'on a annoncé un championnat de robots. Décisions du 21/11 : combat **en temps réel**, façon Real Steel ; les stagiaires **jouent d'abord eux-mêmes** au clavier et leurs combats servent de données ; robot 3 **par renforcement** ; **ring dans le hall de la brasserie** (décor de l'usine).

## Le jeu

- Temps réel découpé en instants : 10 par seconde, 60 s au plus (`regles.py`). Ring de 10 m sur une ligne ; distances en cm, tout en nombres entiers.
- Onze actions (22/11) : attendre, avancer, reculer, garde (haute), garde_basse, direct, crochet, coup_bas, projection, esquive, spécial. Un coup se prépare (2 à 7 instants), frappe (1 instant), puis le robot récupère (3 à 9 instants). Aucune défense n'arrête tout : la garde haute bloque direct, crochet, spécial ; la garde basse bloque coup bas et projection ; un coup bloqué fait un cinquième des dégâts ; l'esquive rend intouchable 3 instants mais coûte 12 d'énergie ; frapper un robot qui prépare ou récupère son coup = contre (dégâts x 3/2).
- `strategie(etat)` est appelée quand le robot est libre : `etat` donne la distance, sa vie, son énergie, les cordes derrière, et ce que fait l'adversaire (action, phase, instants restants). Lire l'adversaire et choisir le moment, c'est tout le jeu.
- Six robots d'entraînement (boxeur, cogneur, mur, lutteur, danseur, hasard) : aucun ne gagne tout (22/11 : mur 8/10, boxeur et danseur 6/10, lutteur 4/10, cogneur 2/10, hasard 0/10). Le robot de départ (deux lignes) gagne 6 combats sur 12.
- Clavier : → D avancer, ← Q reculer, ↑ Z garde haute, ↓ S garde basse, J direct, K crochet, L coup bas, M projection, I spécial, Espace esquive.

## Où

| Fichier | Rôle |
|---|---|
| `championnat/` (VS Code) | `regles.py`, `moteur.py`, `robots_entrainement.py`, `mon_robot.py`, `combat.py` (bilan, moments forts, `combat.json` à revoir en 3D, `--journal`, `--robot`), `tournoi.py` ; J5 : `apprentissage.py` (19 caractéristiques, `arbre_en_code`), `decisions.csv` (325 combats, 70 537 décisions), `donnees_apprentissage.py`, `robot2_arbre.ipynb`, `robot2_modele.py`, `robot3_modele.py` ; `corriges/` ; `championnat-depart.zip` (J3) et `championnat-J5.zip` (J5) pour les stagiaires |
| `jeux-python/site/robots.html` | L'arène : Jouer (au clavier contre un robot d'entraînement ; décisions enregistrées, « Télécharger mes combats ») ; Programmer (génération 1, 2 ou 3, combat et bilan dans le moteur Python) ; Revoir (`combat.json`) ; Envoyer (formulaire Netlify `robot-championnat` : binome, generation, modele, code) ; choix « Votre robot » (modèle 3D) en haut du ring |
| `jeux-python/site/tournoi.html` | Poste du formateur : import (CSV Netlify, .py, collage), tournoi, classement (points, V, N, D, K.-O.), matrice des générations, rejeu 3D, export du journal et des décisions |
| `jeux-python/site/labo.html` | Labo des neurones : mode Combat (robot 3 par renforcement, en direct) et mode Ventes |
| `jeux-python/site/robots/` | `catalogue.json` (les robots 3D et leurs animations), `modeles/*.glb`, `animations/mixamo.glb` ; fichiers produits par `outils-construction/faire_robots.py` |
| `site/js/combat/moteur.js` | Copie JavaScript du moteur (jeu au clavier, renforcement) ; `qa/verifie_moteur_combat.py` : 35 combats identiques instant par instant au moteur Python |

## Robot 3 : renforcement

Stratégie d'évolution : à chaque génération, 24 variantes du réseau (19 entrées → 16 → 11 notes d'action) affrontent les six robots d'entraînement en A et en B ; le réseau avance vers les variantes qui gagnent (rangs, Adam). Aucun exemple à imiter. Mesures du 22/11 (11 actions) : 4 victoires sur 12 au départ, 8 sur 12 après 23 générations ; 0,5 s par génération (Node). Le cerveau exporté (3 décimales) se rejoue en Python pur : le corrigé fait aussi 8 sur 12.

## Robot 2 : arbre de décision

Notebook `robot2_arbre.ipynb` : d'abord, une décision tenue ne compte qu'une fois (une garde tenue 5 s = 50 lignes identiques ; sans cette étape, l'arbre ne fait que se mettre en garde : 0 victoire sur 12) ; puis décisions des gagnants (robots, et joueurs de la classe si on ajoute leurs combats), `DecisionTreeClassifier(max_depth=4)`, 53 % de bonnes réponses au test, `export_text`, `arbre_en_code` : 6 victoires sur 12 (22/11).

Essai du tournoi le 22/11 (8 robots : robot 3 corrigé, robot de départ, six d'entraînement ; 56 combats, 3,9 s) : robot 3 premier, robot de départ quatrième.

## Les robots 3D (22/11)

- Retour du formateur : au tournoi, les robots restaient sur place en s'enfonçant dans le sol. Les robots deviennent des modèles 3D animés (.glb), au choix dans une librairie ; le robot en formes simples reste en secours, pieds recalés au sol.
- Source choisie : Mixamo (téléchargements par le formateur avec son compte). Licence : la FAQ Adobe autorise l'usage dans les jeux vidéo et ne dit rien de la redistribution ; le forum Adobe dit « intégrés au jeu, pas proposés seuls ». Netlify sert les .glb publiquement : risque accepté par le formateur. Les FBX bruts restent hors du dépôt (`04-ateliers/jeux/mixamo-brut/`).
- Chaîne : `mixamo-brut/robots/*.fbx` (FBX Binary, With Skin, T-pose) et `mixamo-brut/animations/*.fbx` (FBX Binary, Without Skin, 30 i/s, In Place) → `python outils-construction/faire_robots.py <mixamo-brut>` (FBXLoader et GLTFExporter de three.js dans Chrome sans fenêtre) → un .glb par robot, un `animations/mixamo.glb` partagé, catalogue mis à jour. Chaque animation est rangée dans un état du jeu d'après le nom de son fichier ; le moment du coup est mesuré (main ou pied le plus en avant). Essayé le 22/11 sur un FBX Mixamo des exemples three.js (non publié) : conversion, chargement et animation partagée vérifiés dans l'arène.
- Dans le jeu (`robot-modele.js`) : la frappe de l'animation est calée sur l'instant où le moteur fait frapper ; réaction « touché » ou « bloqué », esquive, sonné, K.-O., victoire, salut d'entrée ; couleur du binôme sur les pièces peintes (`teinte`) et anneau lumineux au sol (son éclat suit l'énergie).
- Les animations attendues (16) : attente en garde, garde, garde basse, avancer, reculer, direct, crochet, coup bas, projection, spécial, esquive, touché, encaisse en garde, sonné, K.-O., victoire (+ salut d'entrée facultatif).
- Robot d'essai « Rétro » (RobotExpressive, CC0) : ses animations ne sont pas des animations de combat (un seul coup de poing), en attendant les fichiers Mixamo.
- Effets : traînée du coup, aura puis onde de choc du spécial, poussière (coup bas, projection), flash du robot touché, arcs électriques du robot sonné, fumée du K.-O.

## À vérifier

- Un envoi réel au formulaire `robot-championnat` après le déploiement, et les colonnes de son export CSV.
- Fluidité du jeu au clavier sur un poste de la salle, avec les robots .glb (le test automatique tourne sans carte graphique, beaucoup plus lentement).
- Voile blanc sur toute l'image en « graphismes complets » dans le navigateur de test sans carte graphique (avec les deux sortes de robots) : à regarder sur un vrai poste.
- Les animations Mixamo réelles : noms reconnus par `faire_robots.py`, moment du coup mesuré, rendu sur des robots aux proportions différentes.
- Le dossier `tournoi/` (sumo) et `sumo-depart.zip` ne servent plus ; anciens fichiers du site rangés dans `jeux-python/a-supprimer/ancien-sumo/`.
