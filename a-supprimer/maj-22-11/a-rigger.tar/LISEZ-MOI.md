# Robots prêts pour le rigging Mixamo

Chaque ZIP contient `robot.obj`, `robot.mtl` et les textures de couleur (PNG). Préparés le 22/11/2026 par
`outils-construction/robots/apercu.js` (fonction `preparer`) : un seul maillage en pose de repos, squelette d'origine
retiré (Mixamo fait son propre rigging, le même pour tous), accessoires retirés, centré, pieds au sol, face vers l'avant,
allégé à environ 60 000 triangles au plus.

| ZIP | Préparation | Triangles |
|---|---|---|
| clank.zip | tel quel (pas de squelette d'origine) | 59 899 (71 836 au départ) |
| droide-b1.zip | blaster retiré, pose de repos | 2 496 |
| optimus.zip | hache et canon retirés, pose de repos | 8 053 |
| doctor.zip | textures de couleur (fournies à part) rattachées, pose de repos ; cape et dos voûté : rigging risqué | 59 995 (103 297 au départ) |

Pas préparés : T-800 (accroupi), Unitree G1 (aucune pose neutre dans le fichier : couché en pose de repos, penché ou en
train de danser sinon), Mechagodzilla (queue, textures de couleur manquantes). Il faut d'abord les remettre debout,
bras écartés, dans Blender.

## Sur Mixamo

1. Upload Character, choisis le ZIP.
2. Place les repères : menton, poignets, coudes, genoux, aine. Skeleton LOD : Standard.
3. Si le résultat convient : Download, FBX Binary, With Skin, T-pose, sans animation.
4. Range le FBX dans `mixamo-brut/robots/` sous le nom du robot (ex. `clank.fbx`).

Les textures ne doivent pas forcément survivre à Mixamo : l'outil de conversion remet celles du modèle d'origine.
