# Plan — Data Science & Machine Learning - Python de base

> **Mise à jour du 22/11/2026.** Plan d'origine du 17/11, remplacé par `03-supports/storyboard-macro.md` § 0 (cinq jours) ; le sumo y est remplacé par le championnat des robots (`04-ateliers/jeux/09-championnat-robots.md`).

Durée totale : 4 jours (19, 24, 25, 26/11/2026), 8h30 - 17h00 | Niveau : groupe hétérogène en programmation | Modalité : présentiel, Technifutur Seraing, 13 stagiaires

> Statut : **jour 1 validé le 17/11/2026 après simulation** (avocat du diable, deux stagiaires simulés ; synthèse : `simulations/plan-J1-synthese.md`, tous les constats retenus). Jours 2 à 4 : à construire après le tri des anciens supports (esquisse dans `04-ateliers/jeux/03-jeu1-missions.md` § 13).
> Sources : brief, `01-notes/inventaire-notions.md`, `01-notes/proposition-theorie-intro.md`, `01-notes/recherche-J1.md` (faits vérifiés, sources 22 à 42).
> Horaires des pauses : 15 minutes le matin et l'après-midi, une heure de midi (12:30 - 13:30), confirmés par le formateur le 17/11/2026.

## Fil rouge

Une microbrasserie fictive (nom et jeu de données à construire ; ne pas reprendre la « Brasserie du Sart » des exemples du modèle de diapositives). Les stagiaires automatisent ses tâches : prix des commandes, étiquettes des fûts et des casiers, commandes du jour, stock, livraisons, fichier des ventes. Les mêmes données servent aux mini-jeux à partir du jour 2.

## Jour 1 — jeudi 19/11/2026 : comprendre pourquoi Python, puis écrire ses premières lignes

Objectifs du jour (objectifs 1 et 2 du brief) : à la fin de la journée, le stagiaire sait
- situer Python dans l'IA, le machine learning et le métier de data analyst, et décrire les étapes d'un projet de machine learning ;
- exécuter un script dans VS Code et lire un message d'erreur ;
- créer des variables, choisir et convertir un type, calculer avec les opérateurs, afficher et lire au clavier ;
- manipuler une chaîne de caractères (indices, tranches simples, quelques méthodes) et afficher un prix avec une f-string.

Pas de mini-jeu ce jour-là (les postes viennent d'être installés et le jeu sera prêt pour le jour 2).

| Horaire | Séquence | Objectif | Méthode | Durée | Atelier lié |
|---|---|---|---|---|---|
| 08:30 | Accueil et vérification des postes | Chaque poste lance Python et VS Code ; extension Python installée | Fiche de vérification projetée ; les plus rapides aident leurs voisins ; binômes formés d'office pour qu'un poste en panne ne laisse personne seul | 20 | Vérification du poste |
| 08:50 | Ouverture | Programme du jour, objectifs, la brasserie du fil rouge | Diapositives (programme, objectifs, fiche de la brasserie) | 10 | |
| 09:00 | Séq. 1 · Pourquoi Python | Pourquoi Python pour la data et le machine learning, et pourquoi l'apprendre même si l'IA écrit du code | Le même calcul en Excel, en SQL et en Python ; « Vrai ou faux ? Trois idées reçues » | 15 | |
| 09:15 | Séq. 6 (réduite) · Premier script | Écrire et exécuter un premier script avec le bouton Exécuter de VS Code ; lire une première erreur | Pratique guidée : `print()` ; une erreur provoquée exprès et lue ensemble (type, ligne, message) | 20 | Exercice 0.1 : premier script |
| 09:35 | Séq. 2 · IA, machine learning, deep learning, IA générative | Savoir qui contient quoi | Définitions (source 34), cercles imbriqués animés ; classer 6 cas de la brasserie en binôme | 15 | Classement en binôme |
| 09:50 | Séq. 3 · Python dans le métier de data analyst | Situer Python dans le parcours et les outils | Carte du parcours (Fabric en janvier, pandas et scikit-learn en mars) ; Python dans Excel montré en capture ; qui fait quoi entre SQL, Excel / Power BI et Python | 10 | |
| 10:00 | Séq. 4 · À quoi ressemble un projet de machine learning | Les étapes d'un projet et la bibliothèque utilisée à chacune | Pipeline animé ; « Prédisez : quelle étape prend le plus de temps ? » | 20 | |
| 10:20 | Pause | | « On reprend à 10:35. Ensuite : ce qui se passe quand vous cliquez sur Exécuter. » | 15 | |
| 10:35 | Séq. 5 (réduite) · Ce qui tourne derrière, et le notebook | Comprendre en une image ce que fait l'interpréteur ; voir un notebook | Analogie et schéma en 5 minutes (le mot « bytecode » à l'oral pour les curieux, sources 24, 25) ; démonstration d'un notebook par le formateur (pas de pratique le jour 1) | 15 | |
| 10:50 | Chapitre 1 · Les variables | Créer, nommer, réaffecter une variable ; connaître les types de base | Définition « variable » ; démo ; règles de nommage et convention du cours ; `type()` ; « Prédisez avant d'exécuter » ; carte « version développeur » pour les rapides | 20 | |
| 11:10 | Exercices 1.1 à 1.3 | Variables de la brasserie (prix d'un casier, contenance d'un fût, nom d'une bière) | Exercices numérotés, seul, encarts Indice / Réussi si ; bonus rédigés ; tour des rangs | 20 | Module 1 |
| 11:30 | Chapitre 1 · Les opérateurs | Calculer avec `+ - * / // % **` ; affectation combinée | Démo ; comparaison avec les fonctions de quotient et de reste d'Excel ; piège de `/` et de `0.1 + 0.1 + 0.1` (source 38), avec la réponse « comment calculer un prix juste » [À SOURCER avant le storyboard : arrondi, module `decimal`] | 15 | |
| 11:45 | Exercices 1.4 et 1.5 | Prix d'une commande, casiers pleins et bouteilles restantes (`//` et `%`) | Exercices numérotés ; 1.5 facultatif | 15 | Module 1 |
| 12:00 | Correction | Corriger 1.1 à 1.5 | Un stagiaire rapide présente sa solution ; correction commentée | 15 | |
| 12:15 | Marge | Rattraper les retards | Le formateur passe dans les rangs ; bonus pour les rapides | 15 | Bonus module 1 |
| 12:30 | Pause de midi | | | 60 | |
| 13:30 | Chapitre 1 · Conversions et console | `int()`, `float()`, `str()` ; `input()` renvoie toujours du texte | Démo ; « Vrai ou faux » sur `input()` ; prédisez `int("12 kg")` | 15 | |
| 13:45 | Exercices 1.6 à 1.8 | Un devis de commande | Exercices numérotés, seul ; variante avec des valeurs écrites dans le code si `input()` ne fonctionne pas dans l'environnement utilisé | 25 | Module 1 |
| 14:10 | Correction 1.6 à 1.8 | | Correction commentée | 10 | |
| 14:20 | Lire un message d'erreur | Repérer type d'erreur, ligne, message ; corriger | Schéma du traceback ; « chasse aux bugs » : 4 scripts de la brasserie qui plantent (`NameError`, `TypeError`, `ValueError`, `SyntaxError`) et un 5e à deux erreurs pour les rapides | 20 | Chasse aux bugs 1 |
| 14:40 | Pause | | « On reprend à 14:55. Ensuite : le texte. » | 15 | |
| 14:55 | Chapitre 2 · Les chaînes de caractères | Indices (à partir de 0, contre 1 en SQL et dans Excel), indices négatifs, tranches simples, `len()`, `strip()`, `upper()`, `replace()` | Définition ; démo sur l'étiquette d'un fût ; prédisez une tranche | 15 | |
| 15:10 | Chapitre 2 · Les f-strings | Afficher un prix avec `{prix:.2f}` | Démo ; avant / après : concaténation puis f-string | 10 | |
| 15:20 | Exercices 2.1 à 2.4 | Nettoyer une étiquette saisie à la main, composer un bon de livraison | Exercices numérotés, seul ou en binôme ; bonus : bon de livraison aligné en colonnes, `sep` et `end` de `print()`, `{x=}` | 30 | Module 2 |
| 15:50 | Correction | | Un stagiaire présente sa solution ; correction commentée | 15 | |
| 16:05 | Marge pour les imprévus | Rattrapage individuel | Le formateur passe dans les rangs ; tutorat cadré (un rapide guide, sans taper à la place) ; bonus et défis | 30 | Bonus modules 1 et 2 |
| 16:35 | Clôture | « À retenir : trois idées » ; quiz anonyme de 5 questions | Diapositives à retenir et quiz | 15 | Quiz du jour 1 |
| 16:50 | Avis et suite | « Deux minutes pour donner votre avis » ; exercice facultatif à faire avant le 24/11 ; annonce du jour 2 et du jeu | | 10 | Questionnaire de feedback ; exercice de liaison |

Premier code à 09:15. Plus longue plage sans clavier : 45 minutes (09:35 - 10:20), coupée par le classement en binôme et une prédiction. Marge réelle : 15 minutes à 12:15 et 30 minutes à 16:05, en plus des 20 minutes d'accueil. Signal discret pour demander de l'aide (post-it rouge ou vert sur l'écran) et tour des rangs pendant chaque exercice.

### Préparation avant le 19/11 (issue de la simulation)

- Tester sur un poste de la salle : commande `python` ou `py`, extension Python de VS Code, Jupyter dans le navigateur (plan B), `input()` dans cet environnement.
- Fiche d'une page de la brasserie (nom, bières, prix, contenances, clients), figée.
- Bonus de chaque module rédigés ; 5e script de la chasse aux bugs.
- Fiche « questions probables » sourcée dans le cahier formateur : calculer de l'argent avec des floats, pourquoi apprendre si l'IA écrit le code, questions de développeur (`-7 // 2`, `round(2.675, 2)`, `is` ou `==`, `len(s)`, constantes, `__pycache__`, notebooks en production, version de Python, venv).
- Exercice de liaison à faire avant le 24/11, corrigé à l'ouverture du jour 2.

### Plan B (postes non installés ou Python qui ne fonctionne pas)

- La théorie du matin ne dépend pas des postes ; le premier script de 09:15 se fait au projecteur puis en binôme sur les postes qui fonctionnent.
- Pratique : Jupyter dans le navigateur (JupyterLite, source 6) [À VÉRIFIER sur un poste de la salle], ou démonstration au projecteur et exercices en binôme.
- Exercices 1.6 à 1.8 : variante sans `input()`.

### Reporté au jour 2 (issu de la simulation)

- Autres façons de lancer Python (terminal, Maj+Entrée, console interactive).
- `bool()` et `startswith()`, avec les conditions.

### Ce qui est repoussé aux jours suivants

- Conditions, listes et tuples, boucles, dictionnaires et sets : jour 2 (chapitres 3 à 6).
- Fonctions, fichiers et erreurs ; venv, bibliothèques, architecture d'un projet (séquences 7 et 8), variables d'environnement, connexions aux bases : jour 3.
- pandas, graphique, premier modèle, réseaux de neurones, sumo, évaluation : jour 4.
- Mis à jour le 17/11/2026 d'après `03-supports/storyboard-macro.md` (réorganisation demandée par le formateur). Le déroulé du jour 1 ne change pas ; début des conditions gardé en réserve si le groupe est en avance.

## Jours 2 à 4

À construire après le tri des anciens supports et des cours des autres formateurs. Esquisse : `04-ateliers/jeux/03-jeu1-missions.md` § 13.

## Mis de côté (→ bibliothèque)

- Programmation orientée objet, Flask / API, générateurs, décorateurs, asynchrone (proposé, voir `01-notes/inventaire-notions.md` § 3).
