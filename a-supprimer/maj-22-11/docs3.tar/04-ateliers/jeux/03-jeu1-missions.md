# Jeu 1 — Les missions : spécification

> **Mise à jour du 22/11/2026.** Les séries 3 à 8 se jouent dans l'usine (étoile 2 = la notion de la série, `jeux-python/CONCEPTION-usine.md` § 8) ; les séries 1 et 2 gardent les règles ci-dessous. Le placement des jeux par jour (§ 13) est remplacé par `03-supports/storyboard-macro.md` § 0 ; le sumo, par le championnat des robots.

> Fait partie du dossier de développement des mini-jeux (voir `README.md`). Moteur : `02-moteur-python.md`. Rendu : `01-direction-artistique.md`.
> Utilisation : jours 2 et 3 (24 et 25/11/2026), séances de 10 à 20 minutes avant ou à la place d'une série d'exercices numérotés.

## 1. Objectif pédagogique

> Thème validé le 17/11/2026 : **automatiser les tâches de la microbrasserie** du fil rouge. Le personnage est le préparateur de l'entrepôt de la brasserie ; chaque mission est une tâche réelle de la brasserie, écrite en Python.

Faire écrire du vrai Python, dès le jour 2, avec un retour immédiat (tests) et visible (rejeu 3D). Le même exercice est ensuite refait dans VS Code sur les données du fil rouge.

## 2. Écrans

### 2.1 Accueil (`index.html`)

- Titre du jeu, une phrase qui dit ce qu'on va faire.
- Champ « Prénom ou pseudo » (obligatoire pour envoyer les résultats, facultatif pour jouer ; message sous le champ : « Un pseudo suffit. »).
- Choix « Qualité haute / basse » et « Jouer sans la 3D ».
- Bouton « Commencer » vers la carte des missions.
- Indicateur de chargement de Python (voir moteur § 2).

### 2.2 Carte des missions

- Les séries en colonnes ou en étages de l'entrepôt ; chaque mission affiche ses étoiles obtenues (0 à 3).
- Une série s'ouvre quand la série précédente a toutes ses missions réussies (étoile 1) ; le formateur peut tout ouvrir avec un paramètre d'URL (`?formateur=1`) pour la démo [à ne pas présenter comme une sécurité : c'est un confort, pas un contrôle].
- Contrôle surprise en fin de série, signalé par un panneau différent.
- Bouton « Envoyer mes résultats » (voir § 9).

### 2.3 Écran de mission

```
+---------------------------+-----------------------------------+
|  [Carte] Mission 2.3      |  Titre qui affirme une idée        |
|                           |  Énoncé : 2-3 lignes               |
|        Vue 3D             |  Étoiles visées : * * *            |
|                           +-----------------------------------+
|                           |  Éditeur Python             (2/3)  |
|                           |  (code de départ, numéros de ligne,|
|                           |   ligne en cours surlignée)        |
|                           +-----------------------------------+
|                           |  Tests                      (1/3)  |
|  Rejeu : [|>] [Pas à pas] |  OK  Une commande vide donne 0     |
|  [x1 | x3]                |  KO  Un article en rupture...      |
|                           |  Bonus : 2 tests  Cachés : ?       |
|  [Exécuter] (Ctrl+Entrée) |  Sortie | Erreur | Indice          |
+---------------------------+-----------------------------------+
```

Proportions : vue 3D à gauche (environ 45 % de la largeur), panneau de droite 55 % ; à droite, éditeur 2/3 de la hauteur, tests 1/3 (demande du formateur). En mode sans 3D, la vue 3D est remplacée par le journal en texte (une ligne par action, couleur et symbole pour ok / échec).

Onglets sous les tests : **Sortie** (ce que le stagiaire a affiché avec `print`), **Erreur** (explication en clair, voir moteur § 7), **Indice** (voir § 6).

### 2.4 Fin de mission

- Tous les tests visibles passent : animation de réussite, étoiles gagnées, phrase de bilan (« Mission réussie. Étoile 2 : 9 actions, l'objectif était 8 ou moins. »), boutons « Améliorer » et « Mission suivante ».

### 2.5 Fin de série

- Récapitulatif des étoiles, outil débloqué (« Nouvel outil : `scanner_allee()`. Il renvoie la liste des fûts et des caisses de l'allée. »), rappel de faire le même exercice dans VS Code si le formateur l'a prévu.

## 3. Commandes

| Action | Clavier | Souris |
|---|---|---|
| Exécuter | Ctrl+Entrée | Bouton « Exécuter » |
| Rejeu pas à pas | F10 [À VÉRIFIER : conflit avec le navigateur] | Bouton « Pas à pas » |
| Tourner la caméra | | Glisser dans la vue 3D |
| Zoom | | Molette dans la vue 3D |
| Couper le son | M (hors éditeur) | Icône son |
| Pause du rejeu | P (hors éditeur) | Bouton |

Les raccourcis à une lettre ne s'appliquent jamais quand le focus est dans l'éditeur.

## 4. Éditeur

- CodeMirror (source 9) avec coloration Python, numéros de ligne, indentation de 4 espaces, la touche Tab insère 4 espaces [À VÉRIFIER : paquet et configuration exacts].
- Le code du stagiaire est sauvegardé automatiquement par mission (voir § 8) ; bouton « Revenir au code de départ » avec confirmation.
- Pendant le rejeu pas à pas, la ligne qui a produit l'action courante est surlignée (champ `ligne` du journal).
- Pas d'autocomplétion intelligente (les stagiaires doivent apprendre les noms) ; le formateur peut en décider autrement.

## 5. Format d'une mission

Un dossier par mission : `missions/<serie>.<numero>-<nom-court>/`.

### `mission.json`

```json
{
  "id": "2.3-premieres-commandes",
  "serie": 2,
  "numero": 3,
  "titre": "Une liste se lit à partir de 0",
  "notions": ["listes", "indices"],
  "enonce": "Les commandes du jour arrivent dans une liste. Écrivez preparer_debut(commandes) qui renvoie les trois premières.",
  "fonctionAttendue": "preparer_debut",
  "scene": {
    "taille": [8, 6],
    "depart": {"case": [0, 0], "direction": "est"},
    "caisses": [{"id": "C-101", "case": [2, 0], "article": "…", "poids": 12, "destination": "…"}],
    "quais": [{"nom": "…", "case": [7, 3]}],
    "obstacles": [[3, 2], [3, 3]]
  },
  "scenarioPrincipal": "scenario_principal",
  "etoiles": {
    "actionsMax": 8,
    "description2": "Le moins d'actions possible : 8 ou moins",
    "description3": "Les deux tests bonus passent"
  },
  "indices": [
    "Le premier élément d'une liste est à l'indice 0.",
    "Une tranche liste[debut:fin] s'arrête juste avant fin."
  ],
  "reussiSi": "Les trois tests visibles passent.",
  "outilsAutorises": ["avancer", "tourner_gauche", "tourner_droite", "prendre", "poser", "lire_etiquette"],
  "dureeIndicativeMin": 8
}
```

Les données concrètes (articles, destinations, poids) viendront du fil rouge [À DÉCIDER par le formateur]. Les valeurs « … » ci-dessus sont à remplir à ce moment, jamais inventées au hasard : elles doivent être cohérentes avec le jeu de données du fil rouge.

### `depart.py`

Code de départ affiché dans l'éditeur : signature de la fonction, docstring en français, éventuellement les premières lignes. Jamais vide pour les séries 1 à 3.

```python
def preparer_debut(commandes):
    """Renvoie les trois premières commandes de la liste."""
    # À vous de jouer
    return []
```

### `tests.py`

```python
def test_trois_premieres():
    """Les trois premières commandes sont renvoyées dans l'ordre"""
    assert preparer_debut(["A", "B", "C", "D"]) == ["A", "B", "C"]

def test_liste_courte():
    """Une liste de deux commandes est renvoyée entière"""
    assert preparer_debut(["A", "B"]) == ["A", "B"]

def bonus_liste_vide():
    """Une liste vide donne une liste vide"""
    assert preparer_debut([]) == []

def cache_liste_non_modifiee():
    """La liste d'origine n'est pas modifiée"""
    commandes = ["A", "B", "C", "D"]
    preparer_debut(commandes)
    assert commandes == ["A", "B", "C", "D"]

def scenario_principal():
    """Ce que la scène rejoue : la fonction appliquée aux commandes du jour"""
    ...
```

Conventions :
- Le runner exécute `tests.py` dans un espace de noms qui contient les fonctions définies par le stagiaire (ici `preparer_debut`) et l'objet `robot` réinitialisé.
- Préfixe `test_` : test visible ; `bonus_` : test bonus (étoile 3) ; `cache_` : test caché (contrôles surprises uniquement, révélé après exécution).
- La docstring est le libellé affiché dans le panneau : phrase affirmative, dans la voix du formateur.
- Les messages d'assertion comparent « Attendu » et « Obtenu » : le runner les formate automatiquement si l'assertion n'a pas de message.
- Les tests sont lisibles par des débutants : `assert` simples, pas de framework.

### Hors site : `solutions/<id>.py`

Solution de référence (servant aussi à vérifier que la mission est faisable et à fixer `actionsMax`), jamais déployée.

## 6. Indices

- Indice 1 disponible après 2 exécutions avec au moins un test visible en échec ; indice 2 après 2 échecs supplémentaires.
- L'onglet « Indice » clignote doucement une fois quand un indice se débloque (supprimé si `prefers-reduced-motion`).
- Les indices orientent sans donner le code (règle du formateur : feedback sans la solution).

## 7. Étoiles

| Étoile | Condition |
|---|---|
| 1 | Tous les tests visibles passent |
| 2 | Étoile 1 + nombre d'actions du scénario principal ≤ `actionsMax` (missions sans personnage : critère alternatif défini dans `mission.json`, par exemple nombre de lignes) |
| 3 | Étoile 1 + tous les tests bonus passent |

Les étoiles obtenues sont conservées : une nouvelle exécution moins bonne ne les retire pas.

## 8. Progression et sauvegarde

- Sauvegardée dans le navigateur du stagiaire (stockage local), avec repli en mémoire si le stockage est indisponible (lecture et écriture protégées par `try / catch`).
- Clé unique : `jeux-python.progression.v1`.

```json
{
  "pseudo": "…",
  "qualite": "haute",
  "missions": {
    "2.3-premieres-commandes": {"etoiles": [true, true, false], "essais": 5, "code": "def preparer_debut(...", "termineeLe": "2026-11-24T10:42:00"}
  },
  "outils": ["avancer", "prendre", "lire_etiquette"]
}
```

- Les postes de la salle peuvent être partagés ou réinitialisés : prévoir un bouton « Recommencer à zéro » (avec confirmation) et ne jamais compter sur la sauvegarde d'un jour à l'autre [À VÉRIFIER avec l'IT : profils Windows conservés ou non].

## 9. Envoi des résultats (Netlify Forms)

Même mécanisme que les jeux existants (observé dans `index.html` et `jeu.js` du jeu Contrôle qualité) : formulaire HTML caché déclaré pour Netlify, envoi par `fetch` en `POST` encodé en formulaire, message « Résultat envoyé » quand le site répond correctement. Procédure de mise en ligne et de notification : `LISEZ-MOI.md` des jeux existants, à reprendre.

- Nom du formulaire : `resultat-missions`.
- Champs : `pseudo`, `date`, `serie_max_atteinte`, `missions_reussies`, `etoiles_total`, `missions_a_revoir` (identifiants où l'étoile 1 manque après plus de 5 essais), `mode` (3D / sans 3D), `qualite`.
- Pas de code du stagiaire envoyé.
- Envoi à la demande (bouton) et proposé en fin de série.

## 10. Accessibilité et confort

- Taille de texte minimale 14 px dans l'interface, 16 px dans l'éditeur ; bouton « A+ » pour agrandir l'éditeur (salle avec projecteur).
- Contraste suffisant dans l'interface ; réussite / échec jamais par la couleur seule.
- Tout est faisable au clavier sauf la rotation de caméra (non nécessaire pour réussir).
- `prefers-reduced-motion` respecté (voir direction artistique § 7).

## 11. Contenu des séries

Notions et ordre à caler sur le plan validé (`02-plan.md`). Proposition de départ, sur le thème de la brasserie :

| Série | Notions (voir `01-notes/inventaire-notions.md`) | Tâches de la brasserie (exemples de missions) | Contrôle surprise |
|---|---|---|---|
| 1 | Variables, types, conversions, opérateurs arithmétiques, affectation combinée, affichage | Calculer le prix d'un casier, le volume d'un fût en litres, le prix d'une commande TVA comprise [taux à sourcer] | Un poids saisi `"12 kg"` au lieu de `12` |
| 2 | Chaînes de caractères : indices, tranches, méthodes, f-strings | Lire et nettoyer l'étiquette d'un fût (`" blonde Maison "` → `"BLONDE MAISON"` ; noms des bières à fixer avec le jeu de données), composer le texte d'un bon de livraison | Étiquette avec espaces et majuscules incohérentes |
| 3 | Conditions, opérateurs de comparaison et logiques, valeurs vraies et fausses | Envoyer chaque fût au bon quai (café, magasin, particulier), appliquer le tarif selon le client, signaler un stock bas | Ordre des `elif` piégeux (un client « café » qui est aussi « gros volume ») |
| 4 | Listes et tuples : indices, tranches, méthodes, décomposition | Préparer les trois premières commandes de la file, retrouver la dernière livraison, ranger un fût (numéro, bière) en tuple | Liste vide, commande en double |
| 5 | Boucles `for` / `while`, `range`, `enumerate`, `zip` ; compréhensions de liste en bonus | Tournée complète du préparateur, charger le chariot tant qu'il n'est pas plein, vérifier la température de chaque cuve | Chariot plein en cours de tournée |
| 6 | Dictionnaires et ensembles (`set`) | Mettre à jour le stock bière par bière, compter les fûts par destination, lister les clients livrés sans doublon | Bière inconnue du stock |
| 7 | Fonctions : paramètres, valeurs par défaut, arguments nommés, `return` (y compris plusieurs valeurs), portée, copie et référence | Écrire `facturer(commande, remise=0)` et `preparer(commande, stock)`, les réutiliser pour toute la journée | Fonction qui affiche au lieu de renvoyer ; fonction qui modifie la liste reçue sans le vouloir (test caché) |
| 8 | Fichiers et erreurs : `with open`, module `csv`, `try` / `except` / `else` / `finally`, `import` | Traiter le fichier des commandes sans planter sur une ligne mauvaise | Lot de commandes du vendredi soir : données sales (client inconnu, quantité négative, date impossible) |

Notions non jouables dans le jeu, travaillées dans VS Code : `input()` (le jeu n'a pas de console interactive), débogueur de VS Code, venv et `pip`.

Les données (bières, clients, prix, contenances) viennent du jeu de données du fil rouge, à construire ; aucune valeur au hasard. Les références réglementaires éventuelles (TVA, accises) ne sont utilisées que sourcées, sinon évitées.

Rédaction des missions : agent `concepteur-ateliers` du plugin, avec les mêmes règles que les autres ateliers (voix du formateur, fil rouge, pas d'énoncé interchangeable).

## 12. Matériaux et lumières

> Applique `07-materiaux-textures-lumieres.md` (catalogue des matières, couches, réglage de qualité). Décor « entrepôt » à adapter au fil rouge.

### Objets et matières

| Objet | Matière(s) du catalogue | Couches | Remarques |
|---|---|---|---|
| Sol de l'entrepôt | `beton_sol` + `signalisation` (marquages d'allée) | couleur, normales, ORM | Numéros d'allée générés ; marquages moins rugueux que le béton |
| Murs, portes sectionnelles | `peinture_metal` | couleur, normales (nervures) | |
| Rayonnages | `peinture_metal` (montants), `bois_palette` (plateaux) | couleur, normales, ORM | Vibrent à la collision |
| Caisses de carton (bouteilles emballées) | `carton` | couleur générée (étiquette : bière, poids, destination, code-barres), normales | Une texture par caisse, mise en cache |
| Fûts | `fut_inox` | couleur générée (bande avec le nom de la bière et la contenance), normales, ORM | Objet manipulé principal ; roule s'il tombe |
| Casiers de bouteilles | `casier_plastique` + `verre_bouteille` (bouteilles visibles) | couleur, normales | Bouteilles en semi-transparence en qualité basse |
| Cuves de fermentation (fond de l'entrepôt) | `inox` + `ecran` (température) | normales, ORM | Écran piloté par les données des missions de la série 5 |
| Palettes | `bois_palette` | couleur, normales | |
| Préparateur | `tissu` (gilet), `plastique_brillant` (casque), `caoutchouc` (semelles) | selon le modèle importé | Matériaux du modèle remplacés par le catalogue si besoin |
| Chariot | `peinture_metal`, `acier_brosse` (fourches), `caoutchouc` (roues) | couleur, normales, ORM | Objet héros : carte d'environnement nécessaire |
| Tapis roulant | `caoutchouc` (bande qui défile), `acier_brosse` (rouleaux) | couleur, normales | |
| Quais | `peinture_metal` + `signalisation` (panneau) + `led` (bandeau lumineux) | couleur générée, émission | Le bandeau change de couleur selon la livraison |
| Écran de contrôle | `ecran` | émission générée | Valeur d'une variable pendant le pas à pas |
| Bureau vitré (décor de fond) | `verre` (qualité haute), `peinture_metal` | | Semi-transparence simple en qualité basse |

### Éclairage de l'entrepôt

| Lumière | Type | Rôle | Qualité basse |
|---|---|---|---|
| Ciel et sol | `HemisphereLight` | Lumière de fond, ton chaud au sol, ton froid au plafond | Oui |
| Soleil par les verrières | `DirectionalLight` avec ombres | Lumière principale, ombres des rayonnages et du personnage | Oui, sans ombre |
| Néons du plafond | `RectAreaLight` (2 rampes) | Ambiance d'entrepôt, reflets allongés sur le sol | Matériau émissif seul |
| Lumières des quais | `PointLight` (une par quai, atténuée) | Verte à la bonne livraison, rouge à l'erreur, éteinte au repos | Matériau émissif seul |
| Gyrophare | `SpotLight` en rotation | S'allume quand une action est impossible ou la limite d'actions atteinte | Matériau émissif clignotant |
| Environnement | Carte d'environnement (HDRI d'intérieur) | Reflets du chariot, des rouleaux, du casque | Réduite ou couleur unie |

Total en qualité haute : hémisphère + directionnelle + 2 néons + lumière du quai actif + gyrophare (allumé seulement en cas d'erreur) = 6 au plus à un instant donné. Les quais inactifs n'ont pas de lumière allumée.

### Événements lumineux

| Événement | Changement |
|---|---|
| Caisse au bon quai | Lumière et bandeau du quai : vert, impulsion de 0,6 s |
| Caisse au mauvais quai | Lumière et bandeau : rouge, impulsion |
| Action impossible, limite d'actions | Gyrophare orange 1,5 s |
| Ligne en cours (pas à pas) | Écran de contrôle : valeur de la variable suivie |
| Mission réussie | Néons qui montent brièvement en intensité, quais en vert |

## 13. Placement des séries dans le cours

L'ordre des séries suit l'ordre des chapitres (`01-notes/inventaire-notions.md` § 6). Placement proposé, à confirmer par le plan (`02-plan.md`) :

| Jour | Chapitres vus dans le cours | Jeu | Pourquoi ce placement |
|---|---|---|---|
| J1 (19/11) | Introduction (séquences 1 à 6), chapitres 1 et 2 | Aucun (jeu pas encore prêt, postes à installer) | Exercices courts dans VS Code, « Prédisez avant d'exécuter » |
| J2 (24/11) | Chapitres 3, 4, 5, 6 | Séries 1 et 2 en échauffement (révision du J1), puis séries 3, 4, 5, 6 chacune juste après son chapitre | Chapitres 3 à 5 menés vite (procédural déjà connu) ; le jeu suit immédiatement la notion, avant les exercices dans VS Code |
| J3 (25/11) | Chapitres 7, 8 ; venv, `.env`, connexions aux bases | Séries 7, 8 (matin) | L'après-midi est consacré aux bases de données |
| J4 (26/11) | pandas, machine learning, réseaux de neurones | Sumo : règles et stratégie (matin), tournoi (après-midi) ; analyse des journaux et « le robot qui apprend » en bonus | Le sumo demande conditions, dictionnaires et fonctions : tout est vu à la fin du J3 |

Mis à jour le 17/11/2026 (réorganisation du storyboard macro) : **les séries 1 à 6 doivent être prêtes pour le 24/11**.

Point de vigilance : J2 est chargé (quatre chapitres et quatre séries, rythme rapide supposé). Si le temps manque, les séries restent jouables en autonomie (self study du 27/11) et les contrôles surprises passent en bonus.
