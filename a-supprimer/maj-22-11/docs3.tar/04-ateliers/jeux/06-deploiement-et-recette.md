# Structure, développement local, déploiement et recette

> **Mise à jour du 22/11/2026.** Arborescence et formulaires à jour dans `jeux-python/LISEZ-MOI.md` : formulaires `resultat-missions` et `robot-championnat` (le formulaire du sumo n'existe plus) ; le jeu 3 est le championnat des robots (`09-championnat-robots.md`).

> Fait partie du dossier de développement des mini-jeux (voir `README.md`).

## 1. Structure du dépôt

```
jeux-python/                       (dossier déposé sur Netlify)
├── index.html                     accueil : pseudo, qualité, mode sans 3D, choix du jeu
├── missions.html                  jeu 1
├── tournoi.html                   jeu 3
├── builder.html                   jeu 2 (version 2)
├── _headers                       en-têtes Netlify (isolement cross-origin pour l'interruption)
├── css/
│   └── jeux.css
├── js/
│   ├── commun/
│   │   ├── scene.js               scène Three.js, lumières, caméra, réglage de qualité
│   │   ├── textures.js            textures générées par le code (canvas), jeux de couches
│   │   ├── materiaux.js           catalogue des matières (constante MATIERES)
│   │   ├── lumieres.js            éclairage de chaque scène, événements lumineux
│   │   ├── decor.js               décor modulaire du fil rouge
│   │   ├── personnage.js          chargement du modèle, animations
│   │   ├── effets.js              particules, secousses, amortis
│   │   ├── sons.js                sons synthétisés (Web Audio)
│   │   ├── rejeu.js               rejeu d'un journal (3D et texte)
│   │   ├── sans3d.js              affichage texte du journal
│   │   ├── editeur.js             CodeMirror configuré pour Python
│   │   ├── python.js              pilote du worker (charger, exécuter, interrompre)
│   │   ├── progression.js         sauvegarde locale (stockage protégé par try / catch)
│   │   └── resultat.js            envoi Netlify Forms
│   ├── missions.js
│   ├── tournoi.js
│   └── builder.js
├── worker/
│   └── python-worker.mjs          worker module : charge Pyodide, appelle runner.py
├── python/
│   ├── runner.py
│   ├── api_robot.py
│   ├── erreurs_fr.py
│   ├── moteur_combat.py
│   ├── regles.py
│   └── strategies_reference.py
├── missions/
│   └── <serie>.<numero>-<nom>/    mission.json, depart.py, tests.py
├── assets/
│   ├── modeles/                   .glb
│   ├── textures/<matiere>/        <matiere>_couleur.png, _normales.png, _orm.png, _emission.png
│   ├── environnements/            cartes d'environnement (HDRI)
│   └── LICENCES.md                source, URL, licence, date de chaque ressource importée
├── vendor/
│   ├── three/                     Three.js (version figée)
│   ├── codemirror/
│   └── pyodide/                   Pyodide auto-hébergé
└── LISEZ-MOI.md                   mise en ligne, réglages, test avant de donner le lien

Hors site (cours/python-de-base/04-ateliers/jeux/) :
├── README.md, CONCEPTION.md, 01 à 06-*.md   spécifications
├── solutions/                     solutions des missions (jamais déployées)
├── tests/matieres.html            page témoin des matières (sphère et cube), jamais déployée
├── qa/                            scripts du contrôle qualité automatique, captures de référence, rapports
├── tournoi/                       tournoi.py, stratégies reçues, journaux CSV
└── version-locale/                API et missions pour VS Code (plan B et travail en local)
```

## 2. Choix de construction

- Objectif : garder le dépôt par glisser-déposer sur Netlify, comme pour les jeux existants.
- Three.js et Pyodide s'embarquent tels quels dans `vendor/`.
- CodeMirror est distribué en modules : soit une version utilisable sans outil de construction existe, soit on construit une seule fois le dossier final sur le poste du formateur avec un outil de construction et on ne dépose que le résultat [À DÉCIDER après vérification de la documentation de CodeMirror].
- Versions figées et notées dans `LISEZ-MOI.md` et dans `01-notes/sources.md`.

## 3. Développement en local

- Les workers modules et le chargement de fichiers par `fetch` ne fonctionnent pas de façon fiable en ouvrant `index.html` directement depuis le disque [À VÉRIFIER] : servir le dossier avec un petit serveur HTTP local, par exemple `python -m http.server` dans le dossier `jeux-python/` [À VÉRIFIER : ce serveur n'envoie pas les en-têtes de `_headers`, donc l'interruption par `SharedArrayBuffer` ne se teste qu'en ligne ou avec un serveur configuré].
- L'envoi des résultats ne fonctionne que sur le site Netlify (déjà constaté avec les jeux existants, voir leur `LISEZ-MOI.md`).
- Tests du code Python en dehors du navigateur : `python lancer_tests.py <mission>` (voir moteur § 9).

## 4. Déploiement sur Netlify

Reprendre la procédure du `LISEZ-MOI.md` des jeux existants (dépôt manuel, activation de la détection des formulaires, notification par e-mail réglée dans Netlify), avec :

- formulaires : `resultat-missions`, `resultat-tournoi` (si option A) ;
- fichier `_headers` à la racine du dossier publié. Syntaxe documentée : un chemin, puis les en-têtes indentés en dessous ; `/*` pour toutes les pages (source 10). Contenu exact [À VÉRIFIER sur MDN : en-têtes d'isolement cross-origin requis par `SharedArrayBuffer`, et vérification que Three.js, les modèles et Pyodide, tous servis par le site lui-même, se chargent toujours] ;
- le `LISEZ-MOI.md` du nouveau site rappelle : données personnelles (pseudo), suppression des envois après la formation.

## 5. Recette

### Avant chaque mise en ligne

- [ ] Contrôle qualité automatique passé (`08-controle-qualite-automatique.md`), rapport remis et validé par le formateur.

- [ ] Le site s'ouvre sans erreur dans la console du navigateur.
- [ ] Python se charge ; temps de premier chargement noté : ____ s ; second chargement : ____ s.
- [ ] Chaque mission livrée : la solution de référence obtient les 3 étoiles ; le code de départ échoue proprement ; une erreur de syntaxe, une boucle sans fin avec et sans appel à l'API, et une exception sont toutes expliquées en clair.
- [ ] Une boucle `while True: pass` est interrompue et l'interface reste utilisable.
- [ ] Mode sans 3D : toutes les missions sont faisables.
- [ ] Qualité basse : 30 images par seconde minimum sur le poste de test.
- [ ] `prefers-reduced-motion` : plus de secousse ni de confettis.
- [ ] Envoi d'un résultat avec le pseudo « Test » : visible dans l'onglet Forms de Netlify, e-mail reçu.
- [ ] Aucune solution, aucun secret dans le dossier déployé (recherche dans les fichiers).
- [ ] Textes relus : voix du formateur, aucune faute, aucun émoji.
- [ ] `assets/LICENCES.md` à jour (textures et cartes d'environnement comprises).
- [ ] Recette visuelle des matières faite (`07-materiaux-textures-lumieres.md` § 8) : page témoin en qualité haute et basse, aucun métal noir faute d'environnement, aucune texture floue ou étirée.
- [ ] Poids total des textures noté : ____ Mo.
- [ ] Images par seconde dans la scène la plus chargée, qualité haute : ____ ; basse : ____.

### Sur un poste de Technifutur (avant la session)

- [ ] Navigateur et version notés : ____.
- [ ] 3D affichée en qualité haute / basse : ____.
- [ ] Temps de chargement de Python sur le réseau de la salle : ____ s.
- [ ] Le stockage local est conservé d'une ouverture à l'autre : oui / non.

### Partie d'essai (au moins une personne autre que le développeur)

- [ ] Une série complète jouée au clavier, chronométrée : ____ min.
- [ ] Noter : où la personne a bloqué, ce qui lui a donné envie de continuer ou d'arrêter, les textes mal compris.
- [ ] Décisions retenues ou rejetées ajoutées au journal du cours.

### Tournoi

- [ ] Équilibrage validé (aucune stratégie de référence invaincue).
- [ ] `tournoi.py` produit le classement et les CSV sur le poste formateur.
- [ ] Une stratégie qui lève une exception ou renvoie une action invalide ne bloque pas le tournoi.

## 6. Après la formation

- Supprimer les envois de formulaire dans Netlify.
- Noter dans le journal du cours les retours de la question « Qu'est-ce qui vous a donné envie de continuer, ou d'arrêter ? ».
