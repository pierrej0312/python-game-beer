# Les jeux Python de la Brasserie de la Fonderie

Jeux du cours « Data Science & Machine Learning - Python de base » (Technifutur, Data Analyst 2026), joués dans le navigateur :

- **Les missions** (`site/missions.html`) : la carte des six séries. Séries 1 et 2 : des missions Python courtes dont le code pilote un entrepôt en 3D.
- **L'usine** (`site/usine.html`, ouverte depuis la carte pour les séries 3 à 8) : le stagiaire construit la fonction en machines et convoyeurs, ou l'écrit en Python ; graphismes complets, légers, ou code seul. Voir `CONCEPTION-usine.md`.
- **Le championnat des robots** : `site/robots.html` (jouer au clavier, programmer, revoir, envoyer, choisir son robot), `site/labo.html` (labo des neurones : robot 3 par renforcement, et mode ventes), `site/tournoi.html` (tournoi toutes rondes), `site/championnat.html` (championnat de la classe : inscriptions, tirage au sort, arbre à élimination directe). Voir `../09-championnat-robots.md`.
- L'atelier de construction (`site/atelier.html`) reste dans le site, sans lien : l'usine le remplace.
- La ligne de production (`site/ligne.html`, ancien jeu 2) reste dans le site sans lien : l'atelier la remplace.

Contenu du dépôt :

- `site/` : les jeux, seul dossier publié par Netlify (`netlify.toml`).
- `LISEZ-MOI.md` : mise en ligne, test, réglages.
- `REALISATION-jeu1.md`, `REALISATION-jeu2.md`, `REALISATION-atelier.md` : ce qui est construit, écarts avec les spécifications, reste à faire.
- `lancer-en-local.bat` : tester sur le PC.

Ce dépôt contient les solutions (`solutions/`, `solutions-ligne/`, `solutions-atelier/`, `outils-construction/faire_missions.py`, `outils-construction/faire_niveaux.py`, `outils-construction/faire_atelier.py`) : il doit rester privé. Les corrigés des robots du championnat sont hors du dépôt (`04-ateliers/jeux/championnat/corriges/`).

Outils du championnat : `outils-construction/faire_modeles_combat.py` (modèles de robots affichés dans l'arène), `faire_robots.py` (robots et animations Mixamo → .glb, catalogue), `faire_portraits.py` (portraits de l'écran de sélection), `robots/apercu.html` (aperçu des modèles et préparation pour Mixamo).
