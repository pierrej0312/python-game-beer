# Jeu 3 — Le tournoi de sumo des robots de la brasserie : spécification

> **Mise à jour du 22/11/2026.** **Le sumo est remplacé le 21/11 par le championnat des robots** (`09-championnat-robots.md`). Ce document est gardé pour l'historique : ses règles, fichiers (`tournoi/`, `sumo-depart.zip`) et le notebook `robot3_reseau.ipynb` ne servent plus.

> Fait partie du dossier de développement des mini-jeux (voir `README.md`). Moteur : `02-moteur-python.md`. Matériaux et lumières : `07-materiaux-textures-lumieres.md`.
> Utilisation : fin du jour 3 ou jour 4 (25-26/11/2026). Synthèse conditions + dictionnaires + fonctions, puis analyse des journaux et stratégie apprise sur les données.
> Thème validé le 17/11/2026 : robots de manutention de l'entrepôt de la brasserie, format « sumo » (pousser l'adversaire hors de la plateforme). Pas de personnages ivres (décision du formateur après discussion).

## 1. Principe

Chaque binôme programme un robot de manutention de la brasserie. Deux robots s'affrontent sur la plateforme de chargement : le but est de pousser l'autre hors de la plateforme. Chaque binôme écrit une fonction `strategie(etat)` qui reçoit l'état du combat et renvoie une action. Le combat se calcule en Python, au tour par tour, puis se rejoue en 3D. Le formateur lance ensuite un tournoi entre tous les binômes.

Humour : uniquement visuel (robots qui patinent sur une flaque de mousse, fûts qui roulent quand un robot tombe, robot qui agite les bras au bord du vide). Aucun texte drôle à l'écran.

## 2. L'état reçu par la stratégie

```python
etat = {
    "tour": 7,                      # numéro du tour, à partir de 1
    "moi": {"position": 2, "energie": 6, "ancre": False},
    "adversaire": {"position": 4, "energie": 2, "ancre": True},
    "distance": 2,                  # |position adversaire - position moi|
    "bord_derriere_moi": 2,         # nombre de cases avant de tomber, derrière moi
    "bord_derriere_adversaire": 3,
    "dernier_coup_adversaire": "recharger",   # None au premier tour
    "historique": [("avancer", "recharger"), ...]  # mes coups et ceux de l'adversaire, tours précédents
}
```

- Plateforme en une dimension (positions de 0 à `TAILLE_PLATEFORME - 1`) pour rester simple ; rendu 3D en quai de chargement surélevé, entouré de fûts et de casiers.
- Chaque robot regarde l'autre ; « derrière moi » est le côté opposé à l'adversaire.
- L'état est une copie : le modifier n'a aucun effet sur le combat.

## 3. Actions

| Action | Coût en énergie | Effet |
|---|---|---|
| `"avancer"` | 1 | Se rapproche d'une case (bloqué si la case est occupée) |
| `"reculer"` | 1 | S'éloigne d'une case (attention au bord) |
| `"pousser"` | 3 | Si distance = 1 : l'adversaire recule de `POUSSEE` cases (de `POUSSEE_ANCRE` s'il est ancré) |
| `"ancrer"` | 2 | Le robot s'ancre au sol jusqu'au tour suivant : il recule moins s'il est poussé, mais ne peut pas avancer ce tour |
| `"recharger"` | 0 | Regagne `RECHARGE` points d'énergie (plafonnés à `ENERGIE_MAX`) |

- Action inconnue, énergie insuffisante, ou valeur renvoyée qui n'est pas une chaîne : le tour est perdu, le robot ne fait rien (variante à tester pendant l'équilibrage : « recharger » imposé) ; le journal note la raison.
- Stratégie qui lève une exception : tour perdu, exception notée dans le journal (type et message), le combat continue.
- Stratégie trop lente : délai par appel `DELAI_STRATEGIE_MS` ; au-delà, tour perdu [À VÉRIFIER : mesure de ce délai dans Pyodide ; sinon limite globale du moteur].

## 4. Règles et paramètres (`regles.py`, lisible par les stagiaires)

```python
TAILLE_PLATEFORME = 9
ENERGIE_DEPART = 5
ENERGIE_MAX = 10
RECHARGE = 3
POUSSEE = 2
POUSSEE_ANCRE = 1
TOURS_MAX = 40
GRAINE = 2026          # combats reproductibles
```

Valeurs de départ, **à équilibrer** (§ 7). Résolution d'un tour : les deux stratégies choisissent sans connaître le choix de l'autre, puis résolution simultanée dans cet ordre : ancrages, déplacements, poussées, recharges [ordre à confirmer pendant l'équilibrage et à expliquer dans `regles.py`]. Deux poussées simultanées s'annulent si les deux robots sont au contact [à confirmer].

Fin du combat :
- un robot sort de la plateforme : il perd ;
- les deux sortent au même tour : égalité ;
- `TOURS_MAX` atteint : le robot le plus proche du centre gagne ; à égalité de distance, celui qui a le plus d'énergie ; sinon égalité.

### Valeurs retenues (équilibrage du 20/11/2026)

Moteur écrit le 20/11 (`tournoi/moteur_combat.py`) ; ordre de résolution et poussées simultanées confirmés tels que ci-dessus. L'équilibrage (`tournoi/equilibrage.py`, 5 robots, aller et retour, 20 graines) a changé trois valeurs : `RECHARGE = 2`, `POUSSEE_ANCRE = 0` (un robot ancré ne bouge pas), coût de `ancrer` = 1. Résultat : un cycle (foncer bat prudent, prudent bat econome, econome bat foncer ; reactif bat prudent et econome, nul contre foncer), aucun robot ne gagne tout, foncer ne domine pas, hasard perd tout. Avec les valeurs de départ, econome gagnait tous ses combats. Action non valide : le robot ne fait rien (la variante « recharger imposé » n'est pas retenue). Délai d'une stratégie trop lente : non géré dans VS Code ; à traiter dans le navigateur (worker).

## 5. Journal du combat

Une ligne par tour, exportable en CSV pour l'analyse du jour 4 :

| Colonne | Exemple |
|---|---|
| `combat_id` | `binome3-vs-binome5-1` |
| `tour` | 7 |
| `strategie_a`, `strategie_b` | `binome3`, `binome5` |
| `action_a`, `action_b` | `pousser`, `ancrer` |
| `valide_a`, `valide_b` | `True`, `True` |
| `raison_a`, `raison_b` | vide, ou `energie_insuffisante` / `exception:KeyError` |
| `position_a`, `position_b`, `energie_a`, `energie_b`, `ancre_a`, `ancre_b` | après résolution |
| `distance` | après résolution |
| `vainqueur` | renseigné au dernier tour (`a`, `b`, `egalite`) |
| `fin` | `sortie`, `tours_max` |

Le même journal alimente le rejeu 3D (une animation par tour).

## 6. Écrans

- **Atelier de stratégie** : même disposition que le jeu 1 (vue 3D à gauche, éditeur à droite 2/3, panneau du bas 1/3 avec le résultat du dernier combat et le tableau des tours).
- Boutons : « Combattre un robot d'entraînement » (choix parmi les stratégies de référence), « Rejeu », « Rejeu rapide ».
- **Tournoi** (écran du formateur, projeté) : tableau des rencontres, rejeu des combats, classement.

## 7. Stratégies de référence et équilibrage

À écrire avant la session, dans `python/strategies_reference.py` :

| Nom | Comportement |
|---|---|
| `foncer` | Avance puis pousse dès que possible, recharge quand il n'a plus d'énergie |
| `prudent` | Reste au centre, s'ancre quand l'adversaire est au contact |
| `hasard` | Action aléatoire parmi les actions possibles (graine fixée) |
| `reactif` | Joue selon le dernier coup de l'adversaire |
| `econome` | Recharge jusqu'au maximum avant toute poussée |

Critère d'équilibrage : faire jouer toutes les stratégies de référence entre elles (aller et retour, plusieurs graines) ; **aucune ne doit gagner tous ses combats**, et `foncer` ne doit pas dominer. Ajuster les paramètres de `regles.py` jusqu'à obtenir ce résultat ; noter les valeurs retenues dans le journal du cours.

## 8. Le tournoi

- Format : chaque binôme rencontre tous les autres, deux combats par rencontre (côtés inversés).
- Collecte des stratégies, deux options [À DÉCIDER par le formateur] :
  - A : envoi par formulaire Netlify (`resultat-tournoi`, champ `code`) [À VÉRIFIER : taille maximale d'un champ et d'un envoi Netlify Forms] ;
  - B : dépôt du fichier `strategie_<binome>.py` dans un dossier partagé de la salle, puis `python tournoi.py` sur le poste formateur (dossier `04-ateliers/jeux/tournoi/`), qui produit le classement et les journaux CSV.
- Le même `moteur_combat.py` tourne dans le navigateur et dans VS Code : résultats identiques.

## 9. Lien avec la suite (jour 4) et bonus « stratégie apprise sur les données »

1. **Analyse des journaux** : quelle stratégie gagne, à quel tour se décide un combat, quelle action est la plus jouée près du bord (lecture du CSV, regroupements, comptages ; à la main puis avec pandas).
2. **Mission bonus « le robot qui apprend »** : à partir des journaux du tournoi, calculer pour chaque situation simplifiée (distance, énergie basse ou haute, près du bord ou non) l'action qui a mené le plus souvent à la victoire. Écrire une `strategie(etat)` qui consulte cette table au lieu de règles écrites à l'intuition, puis la faire combattre.
   - Message pédagogique : c'est l'idée de base du machine learning (tirer une règle de décision des données), sans bibliothèque. Le vrai machine learning, avec scikit-learn, arrive dans le parcours en mars (cours de Romain Bernard).
   - Ne pas présenter cette table comme un modèle de machine learning : c'est une statistique sur des données passées.
   - Fichiers : `python/apprentissage_bonus.py` (squelette à compléter), tests dans la même logique que les missions.

## 10. Matériaux et lumières

> Applique `07-materiaux-textures-lumieres.md`.

### Objets et matières

| Objet | Matière(s) du catalogue | Couches | Remarques |
|---|---|---|---|
| Plateforme de chargement | `beton_sol` lissé (rugosité 0,35) + `signalisation` (cases numérotées, bandes jaunes et noires au bord) | couleur, normales, ORM | Sol légèrement réfléchissant ; flaques de mousse décoratives (`mousse`) |
| Robots | `peinture_metal` (carrosserie, une couleur par robot : `mint` / `coral`), `inox` (bras de levage), `caoutchouc` (chenilles), `led` (yeux et jauge d'énergie) | selon le modèle (objet héros) | Carte d'environnement obligatoire |
| Jauge d'énergie | `led` | émission | Nombre de segments allumés = énergie du robot |
| Ancrage | `led` au sol sous le robot + pieds d'ancrage en `inox` | émission | Visible seulement le tour où le robot est ancré |
| Décor autour de la plateforme | `fut_inox`, `casier_plastique`, `bois_palette` | couleur, normales | Les fûts roulent quand un robot tombe |

### Éclairage de la plateforme

| Lumière | Type | Rôle | Qualité basse |
|---|---|---|---|
| Fond | `HemisphereLight` faible | L'entrepôt reste dans la pénombre autour de la plateforme | Oui |
| Projecteur robot A | `SpotLight` (cône doux) | Suit le robot A ; ombre au sol | Remplacé par la lumière directionnelle |
| Projecteur robot B | `SpotLight` | Suit le robot B | Idem |
| Lumière principale | `DirectionalLight` avec ombres | Ombres des robots | Oui, sans ombre |
| Impact | `PointLight` brève (0,2 s) au point de poussée | Éclair au moment de la poussée | Particules seules |
| Environnement | HDRI d'entrepôt ou de hangar | Reflets sur les carrosseries et l'inox | Réduite |

### Événements lumineux

| Événement | Changement |
|---|---|
| Poussée réussie | Éclair d'impact, yeux de la cible qui clignotent |
| Ancrage | Halo émissif au sol sous le robot |
| Recharge | Jauge d'énergie qui remonte segment par segment |
| Énergie à 0 | Yeux et jauge éteints |
| Robot au bord (1 case) | Bande de bord qui clignote en orange |
| Sortie de plateforme | Projecteur du robot sorti qui s'éteint, chute et fûts qui roulent ; projecteur du vainqueur qui s'intensifie |
| Poussée décisive | Ralenti, projecteurs plus intenses pendant 1 s |

## 11. Trois générations de robots (validé le 19/11/2026)

Demande du formateur du 19/11 : une progression, du Python classique au machine learning, puis au réseau de neurones. Le sumo est joué au J5 (jeudi 26/11), après pandas et le machine learning du matin.

| Génération | Le cerveau du robot | Ce que fait le stagiaire | Notions | Ce qui part au tournoi |
|---|---|---|---|---|
| 1 · Classique | Des règles écrites à la main | `strategie(etat)` avec `if` / `elif`, le dictionnaire `etat`, des fonctions | J2, J3 | Le code de la fonction |
| 2 · Machine learning | Un arbre de décision (`DecisionTreeClassifier`) entraîné sur les journaux des combats gagnés | Charger les journaux avec pandas, `fit`, afficher l'arbre appris en règles (`export_text`), les recopier en `if` / `elif` | J4, J5 matin | Le code de la fonction (des règles trouvées par la machine) |
| 3 · Réseau de neurones | Un réseau à plusieurs couches cachées, entraîné sur les mêmes journaux | Entraîner le réseau dans le labo des neurones (mode « Sumo »), exporter son cerveau (poids et biais), le coller dans un modèle de stratégie qui fait le calcul couche par couche avec la fonction `neurone` du matin | J5 matin (neurone à la main, couches) | Le code de la fonction et le cerveau en texte (environ 1 000 caractères) |

- Grand tournoi final : les trois générations s'affrontent. Le classement dit si la machine a fait mieux que les règles écrites à la main ; le résultat n'est pas connu d'avance, et c'est le sujet de la discussion.
- Faisabilité vérifiée le 19/11/2026 en Python 3.14.6, scikit-learn 1.9.1 : `export_text` affiche un arbre en règles lisibles ; un `MLPClassifier` (couches (8, 6), activation `relu`, sortie `softmax`) rejoué en Python pur avec ses `coefs_` et `intercepts_` donne la même action que `predict` sur 300 cas sur 300 ; son cerveau tient en 1 059 caractères de texte. Le tournoi n'a donc besoin ni de scikit-learn ni d'un fichier de modèle : tout passe par le formulaire `strategie-sumo` ou par un fichier `.py`.
- Vocabulaire : « deep learning » désigne des réseaux de neurones à plusieurs couches (source 34) ; le robot de génération 3 en applique le principe à petite échelle. Ne pas le présenter comme du deep learning industriel (pas de PyTorch, pas de GPU, quelques milliers de lignes de journal).
- Données : journaux de milliers de combats entre les robots d'entraînement, générés avant le cours par le moteur du jeu (graine fixée), plus les journaux de la manche 1 du tournoi.
- Collecte (décidée le 19/11/2026) : formulaire Netlify `strategie-sumo` (champs binôme, génération, code), export CSV depuis l'onglet Forms, import dans la page Tournoi sur le poste du formateur ; repli : « Télécharger ma stratégie » (`.py`) envoyé par le canal de la classe, import de plusieurs fichiers ; zone de collage. À tester avant le J5 : taille maximale d'un champ et filtre anti-spam de Netlify sur un envoi contenant du code [À VÉRIFIER].
- Le bonus « le robot qui apprend » du § 9 (table de statistiques) est remplacé par la génération 2, qui fait la même chose avec un vrai modèle.
- Étalement validé le 19/11/2026 : J3 (fin de journée) règles et robot 1 en exercice de liaison, dans VS Code avec `moteur_combat.py` (combat affiché en texte) ; J4 manche 1 projetée à l'ouverture, journaux analysés avec pandas ; J5 robots 2 et 3, grand tournoi. Ordre de production : moteur en Python et robots d'entraînement (pour mardi), page 3D et page Tournoi (pour mercredi matin), labo des neurones (pour jeudi).

## 12. Réalisé le 20/11/2026

| Où | Quoi |
|---|---|
| `jeux-python/site/sumo.html` | Atelier de stratégie : génération 1, 2 ou 3 (modèle de départ pour chacune), combat contre un robot d'entraînement choisi (côté A ou B), bilan contre les cinq, rejeu 3D (pause, rapide, clic sur un tour du tableau) ou tableau des tours sans 3D, onglet Règles (regles.py), envoi au tournoi (formulaire Netlify `strategie-sumo` : binome, generation, code ; le robot est d'abord chargé pour vérifier qu'il n'a pas d'erreur) ou téléchargement du .py |
| `jeux-python/site/tournoi.html` | Poste du formateur : import de l'export CSV des envois (colonnes binome, generation, code ; le dernier envoi d'un binôme pour une génération l'emporte si une colonne de date existe), de fichiers .py (`prenoms_g2.py` donne la génération) ou collage ; robots d'entraînement en option ; robots qui ne se chargent pas écartés et signalés ; classement (3 points la victoire, 1 l'égalité) ; matrice des générations ; rejeu 3D de chaque combat ; export du journal (colonnes de moteur_combat.py) et des décisions (colonnes de decisions.csv) en CSV |
| `jeux-python/site/labo.html` | Labo des neurones, mode Sumo : 6 entrées (divisées par 10), couches cachées réglées à la souris (4 au plus, 16 neurones au plus), sortie sur les 5 actions ; entraînement Adam (taux 0,03, 0,01 ou 0,003 ; 20, 100 ou 300 époques), réseau redessiné (orange positif, bleu négatif, épaisseur = force), courbe d'erreur entraînement et test, part de bonnes réponses ; essai contre les robots d'entraînement (moteur Python) ; export du cerveau et ouverture dans l'atelier (génération 3) ; ajout des décisions d'un tournoi (CSV) |
| `jeux-python/site/js/sumo/arene.js` | L'arène : quai de 9 cases numérotées, bandes de sécurité, robots peints cuivre (A) et bleu acier (B), vérin de poussée, jauge d'énergie au dos, pieds et halo d'ancrage, chute avec les fûts qui roulent, projecteurs, panneau de bord (tour, énergie, action, refus) ; le tour se rejoue dans l'ordre du moteur (refus, ancrages, déplacements, poussée, énergie, chute) |
| `jeux-python/site/python/sumo_web.py` + `python/sumo/` | Le moteur de VS Code, copié tel quel ; une stratégie qui dépasse 20 000 lignes pour un coup perd son tour (le tournoi ne se bloque pas) |
| `tournoi/` | `apprentissage.py`, `donnees_apprentissage.py`, `decisions.csv`, `robot2_modele.py`, `robot3_modele.py`, `robot2_arbre.ipynb`, `robot3_reseau.ipynb`, `combat.py --robot`, `sumo-J5.zip` (stagiaires), `corriges/` |

Mesures du 20/11 (container, Python 3.14.6, scikit-learn 1.9.1) : robot de départ 2 victoires sur 10 ; robot 2 (arbre, max_depth=3) 4 sur 10 ; robot 3 (réseau (8, 6), scikit-learn ou labo après 100 époques) 6 sur 10. Un tournoi de 7 robots (42 combats) se calcule en 1 s dans le navigateur.

À vérifier après le déploiement : un envoi réel au formulaire `strategie-sumo` et les colonnes de son export CSV ; les pages sur un poste de la salle.

