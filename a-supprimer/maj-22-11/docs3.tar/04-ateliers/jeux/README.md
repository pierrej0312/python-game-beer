# Mini-jeux Python — dossier de développement

> **État au 22/11/2026** : missions des séries 1 et 2 (`missions.html`) ; séries 3 à 8 dans l'usine (`usine.html`, conception : `jeux-python/CONCEPTION-usine.md`) ; championnat des robots (`robots.html`, `labo.html`, `tournoi.html`, `championnat.html`, conception : `09-championnat-robots.md`) ; l'atelier et la ligne de production restent dans le site, sans lien. **État au 18/11/2026** : le jeu 1 est construit (version 1). Tout est dans `jeux-python/` (dépôt GitHub du jeu, site publié : `jeux-python/site/`). Lire `jeux-python/REALISATION-jeu1.md` : fichiers, points levés, écarts avec les spécifications, reste à faire.

> Cours : Data Science & Machine Learning - Python de base (`cours/python-de-base/`), formateur pierre-juif.
> Ce dossier contient tout ce qu'il faut pour développer les jeux sans repartir de zéro. Il est écrit pour la personne (ou l'agent) qui codera les jeux.
> Dernière mise à jour : 17/11/2026.

## À lire avant d'écrire une ligne de code

1. `CLAUDE.md` à la racine de l'espace (règles du dépôt : ne rien inventer, sourcer, voix du formateur, journal).
2. `formateurs/pierre-juif/voix.md` et `lexique.md` : tous les textes affichés dans les jeux sont dans sa voix.
3. `cours/python-de-base/00-brief.md` : public, dates, matériel (postes Windows 11 25H2 sans droits d'installation).
4. Les fichiers de ce dossier, dans l'ordre :

| Fichier | Contenu |
|---|---|
| `CONCEPTION.md` | Vue d'ensemble : idées des trois jeux, mécaniques de jeu, architecture, technologies, ordre de fabrication |
| `01-direction-artistique.md` | Style, palette, modèles, textures générées, lumière, effets, sons, budgets de performance, réglage de qualité |
| `02-moteur-python.md` | Exécution de Python dans le navigateur : worker, `runner.py`, API du personnage, journal d'actions, erreurs en clair, interruption |
| `03-jeu1-missions.md` | Spécification complète du jeu 1 : écrans, format d'une mission, tests, étoiles, indices, progression, envoi des résultats |
| `04-jeu3-tournoi.md` | Spécification du sumo (remplacé le 21/11 ; gardée pour l'historique) |
| `09-championnat-robots.md` | Le championnat des robots : règles, fichiers, robots 1 à 3, robots 3D, championnat de la classe |
| `jeux-python/CONCEPTION-usine.md` | L'usine des séries 3 à 8 (étoiles, consignes, affichages) |
| `mixamo-brut/A-TELECHARGER.md` | Les animations Mixamo à télécharger, et les robots préparés pour le rigging (`mixamo-brut/a-rigger/`) |
| `05-jeu2-builder.md` | Spécification du builder isométrique (version 2) |
| `06-deploiement-et-recette.md` | Structure du dépôt, développement en local, Netlify, tests, recette avant chaque session |
| `07-materiaux-textures-lumieres.md` | Rendu physique (PBR) : couches de texture (couleur, normales, ORM, émission, environnement), catalogue des matières (métal, plastique, carton…), lumières, matériaux pilotés par les données, réglage de qualité. Appliqué à chaque jeu dans la section « Matériaux et lumières » de `03`, `04` et `05` |
| `08-controle-qualite-automatique.md` | Contrôles automatiques (fonctionnement, rendu par captures, textes, livraison), grille de relecture des captures, boucle de correction (3 tours au plus), rapport remis au formateur, limites |

Jeux existants du formateur, à prendre comme référence de code et de fonctionnement : `01-notes/mini-jeux/05 - Mini-jeu 3D (Netlify)/` (Contrôle qualité, Crash-test, avec leur `LISEZ-MOI.md`).

## Règles de développement

1. **Ne rien inventer.** Toute API (Three.js, Pyodide, CodeMirror, Netlify) s'utilise d'après sa documentation officielle consultée pendant la session. Ajouter chaque page consultée dans `cours/python-de-base/01-notes/sources.md`. Les points marqués [À VÉRIFIER] dans ces fichiers doivent être vérifiés avant d'être codés.
2. **Voix du formateur dans tous les textes affichés** : vouvoiement, « stagiaires », aucun émoji, aucune blague écrite (l'humour passe par l'animation), titres qui affirment une idée, messages d'erreur qui disent quoi faire.
3. **Pas de solution dans le site.** Les solutions des missions vivent dans `solutions/`, jamais dans le dossier déployé.
4. **Aucun secret dans le code** (adresse e-mail, clé, mot de passe) : tout réglage sensible se fait dans l'interface de Netlify.
5. **Chaque jeu a un mode sans 3D** qui donne accès au même contenu.
6. **Tout ce qui est réglable est en haut des fichiers**, dans des constantes nommées (comme `CLAIMS`, `DURATION`, `PAL` dans les jeux existants), pour que le formateur ajuste sans chercher dans le code.
7. **Journaliser** dans `cours/python-de-base/journal.md` chaque décision de développement qui modifie ces spécifications, et mettre à jour le fichier de spécification concerné.

## Définition de « terminé » pour une version

- Le contrôle qualité automatique de `08-controle-qualite-automatique.md` passe sans défaut bloquant ni visible, et son rapport a été remis au formateur.
- Toutes les cases de la recette de `06-deploiement-et-recette.md` sont cochées pour cette version.
- Une vraie partie au clavier a été jouée par au moins une personne autre que le développeur.
- Le site a été ouvert sur un poste stagiaire de Technifutur (ou la limite est notée dans le journal).
- Aucun [À VÉRIFIER] restant dans le code livré.

## Glossaire

| Terme | Sens dans ce projet |
|---|---|
| Mission | Un niveau du jeu 1 : énoncé, code de départ, tests, scène |
| Série | Groupe de missions sur une notion (variables, listes…) |
| Journal d'actions | Liste des actions produites par le code du stagiaire (prendre, avancer, livrer…), rejouée par la scène |
| Rejeu | Animation de la scène à partir du journal |
| Worker | Fil d'exécution séparé du navigateur, où tourne Python (Pyodide) |
| Runner | `runner.py` : exécute le code du stagiaire et ses tests, renvoie un résultat structuré |
| Fil rouge | Le thème commun du cours : une microbrasserie fictive (choix du formateur, 17/11/2026). Le décor des jeux est l'entrepôt de la brasserie (fûts, casiers, quais de livraison) ; les exemples « entrepôt » de ces fichiers s'y appliquent |
