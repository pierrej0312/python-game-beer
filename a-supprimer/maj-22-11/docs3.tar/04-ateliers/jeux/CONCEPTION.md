# Mini-jeux Python — conception

> **Mise à jour du 22/11/2026.** Vue d'ensemble d'origine (17/11). À jour : étoiles des séries 3 à 8 = la notion de la série (`jeux-python/CONCEPTION-usine.md` § 8 ; les séries 1 et 2 gardent l'étoile 2 au nombre de lignes ou d'actions) ; jeu 3 = championnat des robots (`09-championnat-robots.md`) ; séries 3 à 8 dans l'usine.

> Cours : Data Science & Machine Learning - Python de base (`cours/python-de-base/`).
> Statut : conception validée dans son principe par le formateur le 17/11/2026 (ordre : jeu 1, puis jeu 3, builder en version 2). Détails techniques à confirmer pendant la fabrication.
> **Dossier de développement** : ce fichier est la vue d'ensemble. Le détail pour coder est dans `README.md` (à lire en premier), puis `01-direction-artistique.md` à `06-deploiement-et-recette.md`. En cas d'écart, les fichiers détaillés font foi.
> Hébergement : un seul site Netlify, comme les jeux existants (`01-notes/mini-jeux/05 - Mini-jeu 3D (Netlify)/`).
> Les faits techniques sourcés renvoient à `01-notes/sources.md`. Ce qui n'est pas encore vérifié est marqué [À VÉRIFIER].

## 1. Principes communs

- **Le jeu mène au code, il ne le remplace pas.** Chaque jeu fait écrire ou lire du vrai Python ; le même exercice est ensuite refait dans VS Code sur les données du fil rouge.
- **Pas de mécanique de tri vrai / faux** (rejeté par le formateur).
- **Un seul monde, un seul site, un seul moteur** : les trois jeux partagent le décor du fil rouge, l'éditeur de code et le moteur d'exécution Python.
- **Mode sans 3D** sur chaque jeu (comme les jeux existants) : même contenu, scène remplacée par un journal d'actions en texte. Plan B si les postes affichent mal la 3D.
- **Textes du jeu dans la voix du formateur** : vouvoiement de la classe, « stagiaires », aucun émoji, aucune blague à l'écrit, titres qui affirment une idée.
- **Durée d'une session de jeu : 10 à 20 minutes**, placée juste avant ou à la place d'une série d'exercices numérotés, jamais en plus.

## 2. Jeu 1 — Les missions (priorité 1, pour J2 et J3)

### Idée

Le préparateur de l'entrepôt de la microbrasserie (fil rouge) doit accomplir une tâche de la brasserie : préparer les commandes des cafés, envoyer un fût au bon quai, signaler un stock bas, refuser une commande mal saisie, surveiller la température des cuves. Le stagiaire écrit la fonction Python qui la réalise. Les tests disent si c'est réussi ; le personnage rejoue en 3D ce que le code a fait, erreurs comprises.

### Écran

```
+---------------------------+-----------------------------------+
|                           |  MISSION 2.3 · Les listes          |
|                           |  Énoncé court (2-3 lignes)         |
|        Vue 3D             |  ---------------------------------  |
|   (personnage, décor,     |  Éditeur Python            (2/3)   |
|    rejeu des actions)     |  def preparer_commande(...):       |
|                           |      ...                           |
|                           +-----------------------------------+
|                           |  Tests                     (1/3)   |
|  [Exécuter] [Pas à pas]   |  OK  commande vide -> 0 colis      |
|  [Sans la 3D]             |  KO  article en rupture -> signalé |
|                           |  [Indice] (après 2 échecs)         |
+---------------------------+-----------------------------------+
```

### Déroulé d'une mission

1. Le stagiaire lit l'énoncé et le code de départ (fonction à compléter, jamais une page blanche pour les premières missions).
2. « Exécuter » : le code tourne dans le navigateur (Pyodide), les tests s'exécutent, chaque test passe au vert ou au rouge avec le message de l'assertion.
3. Le personnage rejoue en 3D le journal des actions produit par le code du stagiaire (pas une animation idéale) : on voit où il se trompe.
4. Après deux échecs, l'encart « Indice » se débloque ; un second indice plus précis ensuite.
5. Mission réussie : tous les tests au vert, encart « Réussi si » coché, mission suivante. Missions bonus pour les rapides (plus de tests, cas limites).

### Contenu prévu

8 séries, dans l'ordre des chapitres du cours (variables, chaînes, conditions, listes et tuples, boucles, dictionnaires et sets, fonctions, fichiers et erreurs) : détail dans `03-jeu1-missions.md` § 11, placement jour par jour au § 13, couverture des notions dans `01-notes/inventaire-notions.md` § 5.

### Mécaniques de jeu (ce qui en fait un jeu, pas un exercice habillé)

Références de jeux de programmation dont on s'inspire pour le principe (pas pour le contenu) : Human Resource Machine, Lightbot.

| Mécanique | Description | Priorité |
|---|---|---|
| L'échec est un spectacle | Une erreur se voit dans la scène : le chariot percute le rayonnage, la caisse tombe au mauvais quai, le personnage tourne en rond dans une boucle sans fin. On a envie de relancer pour voir si ça marche. Humour visuel uniquement : aucun texte drôle à l'écran (règle du profil) | 1 |
| Trois étoiles par mission | Étoile 1 : tous les tests passent. Étoile 2 : le moins d'actions possible (seuil fixé par mission). Étoile 3 : les cas limites bonus. Les rapides chassent les étoiles pendant que les autres terminent (réponse au groupe hétérogène) | 1 |
| Outils débloqués | Réussir une série donne au personnage un nouvel outil de l'API (par exemple un scanner), lié à la notion suivante : la progression du jeu suit la progression en Python | 2 |
| Contrôle surprise de fin de série | Une « commande du vendredi soir » : données sales, tests cachés révélés seulement après exécution, comme un niveau de fin | 2 |
| Un entrepôt qui évolue | Le décor grandit et se complique au fil des séries (nouvelles allées, nouveaux quais), au lieu d'un même décor avec un nouvel énoncé | 3 |
| Soin du rendu | Animations, sons (touche M pour couper, comme les jeux existants), petits effets à la livraison d'une caisse ou au gain d'une étoile | 2 |
| Tableau des étoiles de la classe | Projeté au mur, par pseudo, uniquement si l'ambiance du groupe s'y prête (décision du formateur le jour même) | 3 |

Conséquences techniques :
- `mission.json` porte les seuils d'étoiles (`etoiles.actions_max`), la liste des tests bonus et des tests cachés.
- `runner.py` renvoie séparément les tests visibles, bonus et cachés, et le nombre d'actions du journal.
- `rejeu.js` gère les animations d'échec (collision, chute, rotation sur place) à partir des actions invalides du journal.
- La progression (étoiles, outils débloqués) est gardée dans le navigateur du stagiaire (stockage local, avec repli en mémoire si indisponible) et envoyée au formulaire en fin de session.

## 3. Jeu 3 — Le tournoi de sumo des robots de la brasserie (priorité 2, fin J3 ou J4)

> Remplacé le 21/11/2026 par le championnat des robots : `09-championnat-robots.md`.

> Spécification détaillée : `04-jeu3-tournoi.md`. Thème validé le 17/11/2026.

### Idée

Chaque binôme programme un robot de manutention de l'entrepôt de la brasserie. Deux robots s'affrontent sur la plateforme de chargement, façon sumo : le but est de pousser l'autre hors de la plateforme. Chaque binôme écrit une fonction `strategie(etat)` qui reçoit un dictionnaire (positions, énergie, distance, distance au bord, dernier coup de l'adversaire…) et renvoie une action (`"avancer"`, `"reculer"`, `"pousser"`, `"ancrer"`, `"recharger"`). Les combats se jouent tout seuls, au tour par tour, et se rejouent en 3D. Le formateur lance ensuite un tournoi entre binômes.

Humour uniquement visuel (robots qui patinent sur la mousse, fûts qui roulent quand un robot tombe). Personnages ivres écartés (contexte de formation, groupe d'adultes dont certains ne boivent pas, règle « pas d'humour dans les supports »), décision du formateur.

### Pourquoi ce format

- Mobilise conditions, dictionnaires et fonctions dans un même code.
- Le combat produit un journal (une ligne par tour) : au jour 4, on l'exporte en CSV et on l'analyse (qui gagne, avec quelle stratégie, à quel moment) : pont direct vers pandas.
- Bonus « le robot qui apprend » : tirer des journaux, pour chaque situation, l'action qui gagne le plus souvent, et en faire une stratégie. C'est l'idée de base du machine learning, sans bibliothèque ; le vrai machine learning (scikit-learn) arrive en mars dans le parcours.
- Le moteur de combat est un module Python : il tourne dans le navigateur (Pyodide) et aussi dans VS Code, à l'identique.
- Ce qui le rend vidéoludique : un adversaire, un enjeu, un spectacle, et l'envie de corriger sa stratégie après une défaite (principe de Robocode). Combat rejoué en 3D avec effets, ralenti sur la poussée décisive, tableau du tournoi projeté.

### Règles et tournoi

- Combat déterministe (graine fixée), paramètres dans `regles.py`, équilibrage par 5 stratégies de référence (aucune ne doit gagner tous ses combats).
- Collecte des stratégies par formulaire (option A) ou par dossier partagé et `tournoi.py` sur le poste formateur (option B) [À DÉCIDER].

## 4. Jeu 2 — Le builder : la ligne de production de la brasserie (version 2, prochaine session)

> Spécification détaillée : `05-jeu2-builder.md`. Thème validé le 17/11/2026.

### Idée

Le stagiaire construit, en 3D isométrique, la ligne de production de la brasserie : cuves, embouteillage, contrôle qualité, étiquetage, mise en casiers, expédition. Les bouteilles circulent sur les tapis, et le panneau latéral affiche en direct le Python que la ligne représente. Une ligne de production est un pipeline, image du flux de données du futur métier des stagiaires.

| Pièce | Équivalent Python |
|---|---|
| Cuve de fermentation (entrée) | Données de départ |
| Tapis roulant | Ordre d'exécution (une ligne après l'autre) |
| Bac étiqueté | Variable |
| Contrôle qualité (aiguillage vers le rebut) | if / elif / else |
| Carrousel de remplissage, mise en casiers de 24 | for / while |
| Machine (étiqueteuse, capsuleuse) | Fonction (paramètres, return) |
| Tableau de bord de la ligne | print |
| Quai d'expédition | return / résultat attendu |

### Architecture propre au builder

- Le plateau est un graphe (pièces = nœuds, tapis = arêtes), sauvegardé en JSON.
- Un générateur traduit le graphe en code Python lisible ; la simulation exécute ce code dans Pyodide (le même moteur que les jeux 1 et 3), pas un simulateur séparé.
- Caméra orthographique de Three.js pour la vue isométrique [À VÉRIFIER dans la documentation Three.js au moment du développement].

## 5. Architecture technique commune

```
Navigateur du stagiaire
+------------------------------------------------------------+
| Fil principal (interface)                                  |
|  - Scène 3D (Three.js) : décor, personnage, rejeu          |
|  - Éditeur de code (CodeMirror, coloration Python)         |
|  - Panneau des tests, indices, progression                 |
|  - Envoi du résultat (formulaire Netlify)                  |
|            |  postMessage (code, mission)   ^ résultats    |
|            v                                |              |
|  Worker module (fil séparé)                                |
|  - Pyodide (Python dans le navigateur)                     |
|  - runner.py : exécute le code du stagiaire, lance les     |
|    tests, collecte le journal d'actions                    |
+------------------------------------------------------------+
```

### Choix structurants

1. **Python dans un worker.** Pyodide fonctionne dans un web worker de type module, ce qui garde l'interface fluide pendant l'exécution (source 8).
2. **Le code ne pilote pas l'animation en direct.** Le code du stagiaire appelle une petite API Python (`robot.prendre(...)`, `robot.livrer(...)`) qui enregistre des actions dans un journal. Le worker renvoie le journal ; le fil principal le rejoue. Avantages : déterministe, testable, rejouable pas à pas, et le mode sans 3D n'est qu'un autre affichage du même journal.
3. **Protection contre les boucles infinies, en deux niveaux.**
   - Dans l'API : nombre maximal d'actions par exécution (par exemple 500), au-delà une exception claire (« Votre boucle ne s'arrête pas »).
   - Pour une boucle sans aucun appel à l'API (`while True: pass`) : interruption de Pyodide par un `SharedArrayBuffer` et `pyodide.setInterruptBuffer()` (source 11). Le serveur doit envoyer les en-têtes de sécurité adéquats (isolement cross-origin) ; sur Netlify, ils se déclarent dans un fichier `_headers` ou `netlify.toml` (source 10). [À VÉRIFIER : noms et valeurs exacts des en-têtes sur MDN, et effet de ces en-têtes sur le chargement de Three.js et des autres ressources.]
   - Solution de repli si l'interruption ne fonctionne pas : délai maximal, arrêt du worker et rechargement de Pyodide [À VÉRIFIER : temps de rechargement sur un poste de la salle].
4. **Pyodide hébergé sur le site Netlify lui-même** (possible d'après la documentation, source 7), pour ne pas dépendre d'un autre site depuis le réseau de Technifutur. [À VÉRIFIER : taille du téléchargement et temps de chargement sur un poste de la salle.]
5. **Aucune solution en ligne.** Tout ce qui est sur le site est lisible par les stagiaires : les solutions des missions restent dans le dossier du cours, pas dans le site. Les tests, eux, sont publics par nature.
6. **Aucun secret dans le code**, comme pour les jeux existants : l'adresse e-mail de notification se règle dans Netlify.

### Protocole entre fil principal et worker

| Message | Sens | Contenu |
|---|---|---|
| `charger` | interface → worker | version de Pyodide, paquets à charger (aucun pour les missions de base, pandas pour J4) |
| `pret` | worker → interface | temps de chargement |
| `executer` | interface → worker | identifiant de mission, code du stagiaire |
| `resultat` | worker → interface | tests (nom, OK / KO, message), journal d'actions, sortie standard, erreur Python éventuelle (type, ligne, message en clair) |
| `interrompre` | interface → worker | via le tampon partagé |

## 6. Structure du dépôt

> Version détaillée et à jour : `06-deploiement-et-recette.md` § 1.

```
jeux-python/                      (dossier déposé sur Netlify)
├── index.html                    accueil : choix du jeu, pseudo, mode sans 3D
├── missions.html                 jeu 1
├── tournoi.html                  jeu 3
├── builder.html                  jeu 2 (version 2)
├── _headers                      en-têtes Netlify (isolement cross-origin)
├── css/
│   └── jeux.css
├── js/
│   ├── commun/
│   │   ├── scene.js              création de la scène Three.js, lumières, caméra
│   │   ├── decor.js              décor du fil rouge (entrepôt…)
│   │   ├── personnage.js         modèle et animations du personnage
│   │   ├── rejeu.js              rejoue un journal d'actions (3D et texte)
│   │   ├── editeur.js            CodeMirror configuré pour Python
│   │   ├── python.js             pilote du worker (charger, exécuter, interrompre)
│   │   ├── resultat.js           envoi au formulaire Netlify
│   │   └── sans3d.js             affichage texte du journal
│   ├── missions.js
│   ├── tournoi.js
│   └── builder.js
├── worker/
│   └── python-worker.mjs         worker module : charge Pyodide, appelle runner.py
├── python/
│   ├── runner.py                 exécute le code, lance les tests, renvoie le résultat
│   ├── api_robot.py              API du personnage (journal, limite d'actions)
│   ├── moteur_combat.py          règles et moteur du tournoi (identique dans VS Code)
│   └── regles.py                 constantes du tournoi, lisibles par les stagiaires
├── missions/
│   └── 2.3-premieres-commandes/
│       ├── mission.json          titre, énoncé, notions, scène, indices, « Réussi si »
│       ├── depart.py             code de départ affiché dans l'éditeur
│       └── tests.py              tests (fonctions test_… avec assert)
├── vendor/
│   ├── three.min.js
│   ├── codemirror/               (si construit localement)
│   └── pyodide/                  copie auto-hébergée de Pyodide
└── LISEZ-MOI.md                  mise en ligne, réglages, test avant de donner le lien

Hors site (dans cours/python-de-base/04-ateliers/jeux/) :
├── solutions/                    solutions des missions, jamais déployées
├── tournoi/                      tournoi.py pour le poste formateur, stratégies reçues
└── CONCEPTION.md                 ce document
```

## 7. Technologies et langages

| Élément | Choix | Remarque |
|---|---|---|
| Interface | HTML, CSS, JavaScript (modules ES) | Même base que les jeux existants |
| 3D | Three.js | Les jeux existants embarquent la version 0.158.0 (licence MIT) ; mise à jour éventuelle à décider [À VÉRIFIER : dernière version et changements] |
| Éditeur de code | CodeMirror (composant d'éditeur de code pour le web, licence permissive, analyseur Python complet) (source 9) | Nom exact du paquet et version à vérifier [À VÉRIFIER] |
| Python dans le navigateur | Pyodide (distribution Python pour le navigateur basée sur WebAssembly ; NumPy, pandas, Matplotlib, scikit-learn disponibles) (source 7) | Version de CPython embarquée à vérifier, à aligner autant que possible sur Python 3.14 des postes [À VÉRIFIER] |
| Missions, tests, moteurs | Python | Tests écrits en `assert` simples, lisibles par des débutants |
| Données des missions | JSON | Un fichier par mission |
| Construction | Aucune étape de construction si CodeMirror peut être embarqué tel quel ; sinon un outil de construction lancé une fois sur le poste du formateur, et seul le dossier final est déposé [À DÉCIDER] | Garder le dépôt par glisser-déposer sur Netlify |
| Hébergement | Netlify (dépôt manuel), en-têtes par `_headers` (source 10), résultats par Netlify Forms | Procédure déjà décrite dans le LISEZ-MOI des jeux existants |
| Tests du site | Navigateur automatique (comme les jeux existants), puis une vraie partie au clavier sur un poste de Technifutur | La seconde est obligatoire avant la session |

## 8. Données envoyées et vie privée

- Envoyé : pseudo, jeu, mission atteinte, nombre d'essais, missions à revoir (et, pour le tournoi, le code de la stratégie si l'option A est retenue).
- Le groupe est prévenu, le pseudo est proposé, les envois sont supprimés de Netlify après la formation (même règle que les jeux existants).

## 9. Ordre de fabrication

| Échéance | Livrable |
|---|---|
| Avant J1 (19/11) | Test de chargement : ouvrir le site d'un jeu existant et une page Pyodide minimale sur un poste stagiaire |
| Avant J2 (24/11) | Jeu 1 : moteur (worker, runner, API, rejeu, éditeur, tests) + missions des séries 1 à 5, avec les mécaniques de priorité 1 (échec spectaculaire, étoiles). Partie d'essai par 2 ou 3 personnes avant le 24/11 |
| Avant J3 (25/11) | Jeu 1 : séries 6 à 8, mécaniques de priorité 2 (outils débloqués, contrôles surprises, sons) |
| Avant J4 (26/11) | Jeu 3 : moteur de combat, rejeu 3D, `tournoi.py`, export du journal en CSV |
| Session suivante | Jeu 2 : builder |

## 10. Points ouverts

- Fil rouge : microbrasserie fictive (choisi le 17/11/2026) ; nom de la brasserie et jeu de données à construire.
- Tous les [À VÉRIFIER] ci-dessus.
- Le plaisir de jeu ne se vérifie qu'en jouant : ajouter au questionnaire de feedback la question « Qu'est-ce qui vous a donné envie de continuer, ou d'arrêter ? ».
- Comportement de la 3D et de Pyodide sur les postes de Technifutur (Windows 11 25H2, navigateur et carte graphique inconnus).
