# Storyboard macro — les 5 jours

> Vue globale du cours, pour décider des changements d'ensemble avant de détailler jour par jour. Proposé le 17/11/2026, **à valider par le formateur**.
> Jour 1 : détaillé et validé (`02-plan.md`, `03-supports/storyboard-J1.md`). Jours 2 à 4 : proposition à affiner après le tri des anciens supports et des cours des autres formateurs.
> Sources de cette vue : brief, `01-notes/inventaire-notions.md` (notions et priorités, § 5 et § 7), `01-notes/proposition-theorie-intro.md`, `04-ateliers/jeux/03-jeu1-missions.md` § 13 (placement des jeux), `01-notes/fil-rouge-brasserie.md`, planning de la formation.
> **Réorganisé le 17/11/2026** (demande du formateur) : les stagiaires ont déjà pratiqué le procédural (SQL procédural, scripts MongoDB) ; variables, opérateurs, conditions et boucles iront vite. Le temps gagné va aux dictionnaires (avancés au J2), aux bases de données (avancées au J3) et à un premier contact avec les réseaux de neurones (J4).
> Horaires de chaque jour : 8:30 - 17:00, pauses 10:20 (15 min), 12:30 - 13:30, 14:40 (15 min) [jours 2 à 4 : mêmes pauses supposées].

> **Réorganisé le 19/11/2026 : cinq jours au lieu de quatre** (le cours de mathématiques est repoussé ; un collègue ajoute un jour de Python). Décisions du formateur du 19/11 : le J2 est donné tel quel (diapositives, jeu, exercices, débogueur) par un collègue le vendredi 20/11 ; le jour gagné va **en priorité à pandas et au machine learning**. Les sections 3 à 5 ci-dessous restent la référence du contenu de J2 et J3 ; l'ancien J4 est réparti sur J4 et J5 (section 0). **Proposition à valider par le formateur.**

## 0. Les cinq jours (validé le 19/11/2026 : J5 avec le bloc « réseaux de neurones approfondis », sumo construit pour jeudi, séries 7 et 8 dans l'atelier ; mis à jour le 22/11 : le championnat des robots remplace le sumo, les séries 3 à 8 se jouent dans l'usine)

| Jour | Date | Formateur | Titre | Ce que le stagiaire sait faire le soir |
|---|---|---|---|---|
| J1 | jeu. 19/11 | Pierre Juif | Pourquoi Python, et vos premières lignes | inchangé |
| J2 | ven. 20/11 | collègue | Décider, répéter, ranger | inchangé (section 3) |
| J3 | mar. 24/11 | Pierre Juif | Fiabiliser et se connecter | inchangé (section 4) |
| J4 | mer. 25/11 | Pierre Juif | Analyser avec pandas | Charger le résultat d'une requête ou un fichier dans un DataFrame, filtrer, nettoyer, regrouper, joindre deux sources, tracer un graphique lisible |
| J5 | jeu. 26/11 | Pierre Juif | Vers le machine learning | Préparer des données pour un modèle, entraîner et évaluer une régression, comprendre et entraîner un petit réseau de neurones, réussir l'évaluation finale |

Ce qui ne change pas : le contenu de J2 et J3, le self study du 27/11, les questionnaires CourseFlow (un par journée : un questionnaire de plus à prévoir pour le J5).
À reprendre dans le J3 : rien, sauf les dates (« demain » devient « mardi » au J2, fait le 19/11). Le J3 installe déjà pandas et matplotlib dans le venv : rien à installer au J4 ni au J5.

### J4 · mercredi 25/11 · Analyser avec pandas (ex-matin du J4, développé)

Les notions pandas sont à sourcer dans la documentation officielle au moment du détail [À VÉRIFIER au détail].

| Horaire | Séquence | Contenu | Forme | Durée |
|---|---|---|---|---|
| 08:30 | Ouverture | Récap du J3 ; championnat des robots, manche 1 projetée en 3D (robots 1 écrits la veille, page Tournoi), à la place du quiz flash | Championnat, projeté | 15 |
| 08:45 | Premier notebook | Créer `notebooks/analyse_ventes.ipynb`, choisir le noyau du venv, cellule de code et cellule de texte, ordre d'exécution, redémarrer et tout réexécuter ; tout le J4 se fait dans ce notebook (audit du 19/11) | Démo, chacun fait pareil | 10 |
| 08:55 | Du résultat de requête au DataFrame | Vue globale : schéma animé A01 (le projet de ML, étapes 1 à 3 aujourd'hui) ; une requête SQL Server (J3) devient un DataFrame ; lignes, colonnes, types ; premier coup d'œil (`head`, `info`, `describe`) ; un objet porte des valeurs (attributs, sans parenthèses : `df.shape`) et des actions (méthodes, avec parenthèses : `df.head()`) (audit du 19/11) | Schéma animé, avant / après, démo | 30 |
| 09:25 | Sélectionner et filtrer | Schéma animé A15 (un filtre = une colonne de vrai / faux) ; colonnes, lignes, filtres par condition (les conditions du J2 appliquées à une colonne entière) ; comparaison avec WHERE | Schéma animé, démo, « Prédisez » | 25 |
| 09:50 | Exercices 1 | Les ventes de fûts : par bière, au-dessus d'un seuil, d'un client | Exercices numérotés | 30 |
| 10:20 | Correction |  |  | 15 |
| 10:35 | Pause |  |  | 15 |
| 10:50 | Nettoyer | Valeurs manquantes, types, doublons : `commandes.csv` sale du J3, cette fois avec pandas | Démo, avant / après | 25 |
| 11:15 | Regrouper et agréger | Schéma animé A16 (séparer, calculer, combiner) ; `groupby`, agrégats, tri ; le total par bière du J1 enfin compris ; comparaison avec GROUP BY | Schéma animé, démo, vrai ou faux | 25 |
| 11:40 | Exercices 2 | Le chiffre par client et par mois, le top 3 des bières ; puis les journaux du championnat (export « Journaux » de la page Tournoi) : victoires par robot, coups qui touchent le plus, action jouée selon la distance (mini-jeu du J4) [À VÉRIFIER au détail : énoncés à écrire sur l'export réel] | Exercices numérotés | 35 |
| 12:15 | Correction et marge |  |  | 15 |
| 13:30 | Une liste en une ligne | Compréhension de liste : `[c for c in df.columns if …]`, la boucle du J2 écrite en une ligne (audit du 19/11) | Démo, un exercice | 5 |
| 13:35 | Joindre deux sources | Schéma animé A17 (deux tableaux, une clé) ; ventes (SQL Server) et clients (MongoDB) dans un même tableau ; comparaison avec JOIN | Schéma animé, démo pas à pas | 25 |
| 14:00 | Les dates | Convertir une colonne en dates, ventes par semaine et par mois | Démo | 20 |
| 14:20 | Exercices 3 | Jointure et dates | Binômes | 25 |
| 14:45 | Pause |  |  | 15 |
| 15:00 | Graphiques | matplotlib (et le tracé direct de pandas) : courbe des ventes semaine après semaine, barres par bière ; un graphique lisible (titre, axes, unités) | Démo, chacun trace | 25 |
| 15:25 | Atelier fil rouge | Le tableau de bord de la brasserie : ventes par bière et par mois, meilleurs clients, un graphique ; prépare les données du modèle du J5 | Binômes | 45 |
| 16:10 | Marge | Correction de l'atelier, bonus |  | 20 |
| 16:30 | Clôture | À retenir, quiz, avis | | 30 |

### J5 · jeudi 26/11 · Vers le machine learning (proposition du 19/11/2026, à valider : intègre le bloc « réseaux de neurones approfondis », le réseau dessiné, le labo des neurones et le championnat des robots en trois générations, `04-ateliers/jeux/09-championnat-robots.md`)

| Horaire | Séquence | Contenu | Forme | Durée |
|---|---|---|---|---|
| 08:30 | Ouverture | Récap du J4, quiz flash | | 15 |
| 08:45 | Des données à un modèle | Vue globale : schéma animé A01 (étapes 4 et 5 aujourd'hui) ; ce qu'on prédit, avec quoi ; schéma animé A18 (entraînement et test) ; le tableau de l'atelier du J4 comme point de départ | Schémas animés, démo | 20 |
| 09:05 | Machine learning facile | Schéma animé A19 (la droite qui s'ajuste, l'erreur = les écarts) ; prévoir les ventes de fûts : `fit`, `predict`, mesurer l'erreur ; `X` est un tableau (`df[["semaine"]]`), `y` une colonne (audit du 19/11) | Démo guidée, chacun entraîne son modèle | 40 |
| 09:45 | Exercices | Changer les données d'entrée, comparer les erreurs ; un bug de forme à corriger (`df["semaine"]` au lieu de `df[["semaine"]]`) | Binômes | 25 |
| 10:10 | Correction |  |  | 15 |
| 10:25 | Pause |  |  | 15 |
| 10:40 | Réseaux de neurones · théorie sans code | Neurone artificiel (A03), couches (A04), erreur et descente de gradient (A05), rétropropagation (A06), minimums locaux (A07), surapprentissage (A08) | Schémas animés, la salle prédit | 35 |
| 11:15 | Neural Network Playground | La salle prédit puis vérifie : sans couche cachée, avec couches, activation, taux d'apprentissage | Démo, la salle décide | 15 |
| 11:30 | Un neurone à la main en Python | `neurone(entrees, poids, biais)`, calculé au tableau puis exécuté | Démo, chacun l'écrit | 10 |
| 11:40 | Votre réseau dans scikit-learn | `MLPRegressor` sur les ventes de fûts, mise à l'échelle ; comparer à la régression ; `coefs_`, `intercepts_` ; `dessiner_reseau(modele)` : le réseau entraîné dessiné (poids en couleur et en épaisseur) ; `partial_fit` : le réseau redessiné passe par passe pendant que l'erreur baisse ; `random_state` ; la courbe d'apprentissage `loss_curve_` tracée avec matplotlib (une époque : chaque donnée utilisée une fois) (audit du 19/11) | Démo guidée, chacun l'entraîne et le dessine | 30 |
| 12:10 | Marge | Rattrapage ; bonus « un neurone qui apprend tout seul » pour les rapides |  | 20 |
| 13:30 | Robot 1 · amélioré | Le robot classique écrit au J3, retravaillé contre les robots d'entraînement après la manche 1 | Championnat, chacun son robot | 20 |
| 13:50 | Robot 2 · machine learning | Arbre de décision entraîné sur les décisions des gagnants (pandas, `fit`) ; d'abord, une décision tenue ne compte qu'une fois (sinon l'arbre ne fait que se mettre en garde : 0 victoire sur 12) ; les règles apprises, écrites en Python par `arbre_en_code` ; en tête, une diapo : prédire un nombre (régression, mesure R²) ou une catégorie (classification, taux de bonnes réponses) (audit du 19/11) | Démo guidée, binômes | 33 |
| 14:23 | Marge |  |  | 17 |
| 14:40 | Pause | | | 15 |
| 14:55 | Robot 3 · réseau de neurones | Labo des neurones, mode « Combat » : apprentissage par renforcement (le réseau joue des milliers de combats contre les robots d'entraînement et garde ce qui fait gagner : 4 puis 8 victoires sur 12 en 23 générations, mesuré le 22/11), couches à la souris, réseau qui se redessine, courbe des victoires ; le cerveau exporté entre dans la stratégie, calculé avec la fonction `neurone` du matin | Labo, chacun son robot | 30 |
| 15:25 | Championnat de la classe | Tirage au sort, arbre à élimination directe, un combat par match rejoué en 3D jusqu'au champion (page Championnat) ; classique contre machine learning contre réseau de neurones : qui gagne, et pourquoi [À VÉRIFIER : 15 matchs pour 16 stagiaires, environ 1 min 30 chacun : 20 minutes est juste] | Projeté | 20 |
| 15:45 | Le pipeline revisité | Retour au schéma A01 : ce que vous savez faire ; janvier (Fabric), mars (scikit-learn, pandas / Polars) | Synthèse | 10 |
| 15:55 | Évaluation finale | À concevoir avec l'étape évaluations (tous les jours) | Individuel | 45 |
| 16:40 | Clôture | Questionnaire de fin de cours, avis | | 20 |

Championnat des robots étalé sur trois jours (décision du 19/11/2026 pour le sumo, gardée pour le championnat qui le remplace le 21/11) : J3 → règles en fin de journée et robot 1 (classique) comme exercice de liaison, dans VS Code avec le moteur du combat en Python ; J4 → manche 1 projetée à l'ouverture, journaux analysés avec pandas (mini-jeu du J4, à la place d'une série 9 « pandas ») ; J5 → robots 2 et 3, grand tournoi. Si le temps manque avant mardi, le robot 1 passe au J4 matin.

Bibliothèques des J4 et J5 (réponse au formateur du 19/11/2026) : pandas (J4, toute la journée), matplotlib (J4 après-midi, J5), scikit-learn (J5) ; NumPy arrive comme dépendance de pandas, scikit-learn et matplotlib (métadonnées vérifiées le 19/11), montré en 10 minutes sans cours ; ni PyTorch (écarté le 17/11, installation lourde sur des postes sans droits) ni Plotly (doublon de matplotlib, installation en plus). Tout s'installe au J3 dans le venv, en une commande ; condition : l'accès à PyPI depuis la salle, à tester le 19/11.

Réseau de neurones montré graphiquement (décision du 19/11/2026) : dessin du réseau entraîné (`dessiner_reseau`), entraînement passe par passe redessiné (`partial_fit`), page « labo des neurones » sur le site du jeu.

Bonus du J5 (décision du 19/11/2026) : « un neurone qui apprend tout seul », descente de gradient en Python pur (une quinzaine de lignes), en lien avec le schéma A05 ; pour les rapides, hors noyau.
| | Clôture | Questionnaire de fin de cours | | |


> Sections 1 à 7 : version du 17/11 (quatre jours), gardée pour l'historique. La référence est la section 0 et les storyboards détaillés de chaque jour.

## 1. Le cours en une phrase par jour

| Jour | Date | Titre | Ce que le stagiaire sait faire le soir |
|---|---|---|---|
| J1 | jeu. 19/11 | Pourquoi Python, et vos premières lignes | Exécuter un script, lire une erreur, calculer avec des variables, nettoyer un texte, afficher un prix |
| J2 | mar. 24/11 | Décider, répéter, ranger | Écrire des conditions, parcourir des listes avec des boucles, ranger des données par clé dans des dictionnaires |
| J3 | mer. 25/11 | Fiabiliser et se connecter | Écrire des fonctions, lire un fichier sans planter, créer un environnement de projet, connecter Python à SQL Server, MongoDB et Neo4j sans mot de passe dans le code, corriger un code de connexion généré par IA |
| J4 | jeu. 26/11 | Vers le machine learning | Analyser des résultats de requête avec pandas, entraîner un premier modèle, comprendre et entraîner un petit réseau de neurones, réussir l'évaluation finale |

Après le cours : self study le 27/11 (séries du jeu en autonomie), puis Python revient en janvier (notebooks Fabric) et en mars (data science, scikit-learn, pandas / Polars).

## 2. Les fils qui traversent les 4 jours

| Fil | J1 | J2 | J3 | J4 |
|---|---|---|---|---|
| Ouverture | Accueil, postes, brasserie | Correction de l'exercice de liaison | Récap et quiz flash du J2 | Récap et quiz flash du J3 |
| Théorie d'introduction | Séquences 1 à 6 | Autres façons de lancer Python | Séquences 7 et 8 (venv, dépendances, architecture d'un projet, `.env`) | Le pipeline du J1 revisité |
| Chapitres (= séries du jeu) | 1 Variables · 2 Texte | 3 Conditions · 4 Listes et tuples · 5 Boucles · 6 Dictionnaires et sets | 7 Fonctions · 8 Fichiers et erreurs | — |
| Jeu 1 (missions) | — (pas encore prêt) | Séries 1-2 en échauffement, puis 3 à 6 | Séries 7, 8 | Séries en autonomie pour les rapides |
| Jeu 3 (sumo) | — | — | — | Règles et stratégie (matin), tournoi (après-midi) |
| Chasse aux bugs | 1 · erreurs de base | 2 · conditions et boucles | 3 · fichiers sales ; code de connexion généré par IA | — |
| Données de la brasserie | Prix, étiquettes, devis | Commandes du jour, quais, remises, tournée, cuves, stock par bière | `commandes.csv` sale ; ventes dans SQL Server, clients dans MongoDB, livraisons dans Neo4j | Historique des ventes de fûts (modèle et réseau de neurones), journaux du sumo |
| Lien avec ce que les stagiaires connaissent | Excel (QUOTIENT, MOD, STXT), SQL | SQL procédural (IF, WHILE), documents MongoDB = dictionnaires | Leurs propres bases SQL Server, MongoDB, Neo4j | Leur module d'IA générative (réseaux de neurones) |
| Erreurs et débogage | Lire un traceback | Débogueur de VS Code (pas à pas) | try / except | — |
| Machine learning | Cercles IA, projet de ML, aperçu de code | — | Lire une signature de fonction (arguments nommés) | Régression, réseau de neurones (scikit-learn), démonstration visuelle dans le navigateur |
| Clôture | À retenir + quiz 5 questions + avis | idem | idem | Évaluation finale + questionnaire de fin de cours |
| Lien avec le jour suivant | Exercice facultatif avant mardi | Retrouver adresses et identifiants de ses bases | Vérifier ses connexions aux bases (fichier `.env`) | Pistes pour janvier et mars |

## 3. Jour 2 · mardi 24/11 · Décider, répéter, ranger

Chapitres 3 à 5 menés vite (le procédural est connu) ; on s'appuie sur les équivalents en SQL procédural et en MongoDB. Si le groupe va plus vite encore, le chapitre 6 commence avant midi.

| Horaire | Séquence | Contenu | Forme | Durée |
|---|---|---|---|---|
| 08:30 | Ouverture | Correction de l'exercice de liaison, programme du jour | Un stagiaire présente sa solution | 15 |
| 08:45 | Prise en main du jeu | Séries 1 et 2 en échauffement (révision du J1) | Jeu 1, seul | 20 |
| 09:05 | Lancer Python autrement | Terminal, Maj+Entrée, console interactive (reporté du J1) | Démo, chacun essaie | 10 |
| 09:15 | Chapitre 3 · Conditions | `if` / `elif` / `else`, comparaisons, `and` / `or` / `not`, `bool()`, valeurs vraies et fausses, `startswith()` ; comparaison avec IF du SQL procédural | Démo, « Prédisez » (ordre des `elif`) | 15 |
| 09:30 | Jeu série 3 | Envoyer chaque fût au bon quai, tarif selon le client | Jeu 1 | 15 |
| 09:45 | Exercices module 3 | Remises par type de client, alerte de stock bas | Exercices numérotés | 20 |
| 10:05 | Chapitre 4 · Listes et tuples | Indices, tranches, méthodes, `len`, `in`, `sorted`, tuples et décomposition | Démo, vrai ou faux | 15 |
| 10:20 | Pause | | | 15 |
| 10:35 | Jeu série 4 | Préparer les premières commandes de la file | Jeu 1 | 15 |
| 10:50 | Exercices module 4 | Les commandes du jour | Exercices numérotés | 20 |
| 11:10 | Chapitre 5 · Boucles | `for`, `range`, `enumerate`, `zip`, `while` ; comparaison avec WHILE du SQL procédural ; compréhensions en bonus | Démo, « Prédisez » | 20 |
| 11:30 | Jeu série 5 | La tournée du préparateur, les températures des cuves | Jeu 1 | 15 |
| 11:45 | Exercices module 5 | Totaux, comptages, alertes sur les commandes | Exercices numérotés | 20 |
| 12:05 | Correction et marge | | | 25 |
| 13:30 | Le débogueur | Point d'arrêt, pas à pas (lien avec le rejeu pas à pas du jeu) | Démo, chacun essaie | 15 |
| 13:45 | Chasse aux bugs 2 | Mauvais ordre des `elif`, décalage de un, boucle qui ne s'arrête pas | Binômes | 20 |
| 14:05 | Chapitre 6 · Dictionnaires et sets | Clé / valeur, `get`, `items`, parcours, ordre d'insertion ; sets ; un document MongoDB est un dictionnaire | Définition, démo | 20 |
| 14:25 | Jeu série 6 | Mettre à jour le stock bière par bière | Jeu 1 | 15 |
| 14:40 | Pause | | | 15 |
| 14:55 | Exercices module 6 | Le stock de la Fonderie, les clients livrés sans doublon | Exercices numérotés | 25 |
| 15:20 | Atelier fil rouge | La journée de livraison : commandes du jour → quais, remises, stock mis à jour | Exercice intégré, binômes | 30 |
| 15:50 | Correction | | | 15 |
| 16:05 | Marge | Tableau des collections (liste, tuple, dictionnaire, set), bonus, séries du jeu | | 25 |
| 16:30 | Clôture | À retenir, quiz 5 questions, avis, exercice de liaison : retrouver l'adresse et les identifiants de ses trois bases | | 30 |

Volume indicatif : environ 65 diapositives.

## 4. Jour 3 · mercredi 25/11 · Fiabiliser et se connecter

> Constat de l'atelier final SQL + NoSQL (formateur) : beaucoup de stagiaires ont voulu relier Python à leurs bases pour visualiser leurs requêtes, avec du code entièrement généré par IA, qu'ils n'ont pas compris et qui était parfois mal fait. L'après-midi prend le temps de cette connexion, proprement, avec des variables d'environnement.
> Bases couvertes : SQL Server, MongoDB, Neo4j, toujours installées sur les postes des stagiaires (confirmé par le formateur le 17/11/2026). Adresses et identifiants propres à chaque stagiaire : à retrouver avant le J3.
> SQL Server : connexion par un login SQL dédié au cours (décision du formateur), pas par `sa`. Faits vérifiés (source 61) : le login SQL exige le mode « SQL Server et Windows » ; le changer demande le rôle sysadmin (ou CONTROL SERVER) et un redémarrage de SQL Server ; si l'installation était en mode Windows seul, `sa` reste désactivé, et la documentation déconseille de l'activer.
> Confirmé par le formateur (17/11/2026) : le stagiaire peut créer le login et redémarrer le service SQL Server lui-même via `services.msc`. Si l'instance est en mode Windows seul : passer en mode mixte, redémarrer, créer le login. Repli si un poste résiste : authentification Windows (pas de mot de passe dans le `.env`).
> Préparation : à la clôture du J2, l'exercice de liaison devient « retrouver l'adresse et les identifiants de vos trois bases » (fiche à remplir, sans mot de passe sur papier partagé) ; script de création du login SQL et modèle `.env` à fournir.

| Horaire | Séquence | Contenu | Forme | Durée |
|---|---|---|---|---|
| 08:30 | Ouverture | Récap du J2, quiz flash | | 15 |
| 08:45 | Chapitre 7 · Fonctions | `def`, paramètres, `return` (plusieurs valeurs), valeurs par défaut, arguments nommés, portée, copie et référence | Définition, démo, « Prédisez » (liste modifiée dans une fonction) | 25 |
| 09:10 | Jeu série 7 | `facturer()`, `preparer()` | Jeu 1 | 15 |
| 09:25 | Exercices module 7 | La facture d'une commande | Exercices numérotés | 25 |
| 09:50 | Lire une signature | Arguments nommés dans la documentation de pandas et de scikit-learn | Démo sur la documentation officielle | 10 |
| 10:00 | Chapitre 8 · Fichiers et import | `with open`, module `csv`, `import` et bibliothèque standard | Démo | 20 |
| 10:20 | Pause | | | 15 |
| 10:35 | `try` / `except` | `except` ciblé, `else`, `finally` | Démo, vrai ou faux | 15 |
| 10:50 | Jeu série 8 | Le lot de commandes du vendredi soir | Jeu 1 | 15 |
| 11:05 | Exercices module 8 et chasse aux bugs 3 | Lire `commandes.csv` sans planter : client inconnu, quantité négative, date impossible | Binômes | 35 |
| 11:40 | Correction et marge | | | 50 |
| 13:30 | Séq. 7 · Bibliothèques et venv | « Ça marche sur mon PC » ; PyPI, `pip`, venv, fichier de dépendances ; installer dans le venv, en une commande, pandas, matplotlib, scikit-learn, les pilotes des bases et python-dotenv (rien à installer au J4) | Problème, démo, chacun crée son venv | 25 |
| 13:55 | Séq. 8 · Architecture d'un projet | `data/`, `src/`, `notebooks/`, dépendances, `README` ; `.env` et `.gitignore` : ce qui ne va jamais dans Git | Ranger 10 fichiers dans la bonne case | 15 |
| 14:10 | Variables d'environnement | `os.environ`, `os.getenv`, un `.env` lu par python-dotenv ; jamais de mot de passe dans le code | Définition, démo, vrai ou faux | 20 |
| 14:30 | MongoDB depuis Python | `pymongo` : connexion, `find`, les documents arrivent en dictionnaires | Démo, chacun interroge sa base | 10 |
| 14:40 | Pause | | | 15 |
| 14:55 | SQL Server depuis Python | `mssql-python` (installé par `pip`, sans autre logiciel sous Windows) : connexion, requête paramétrée (jamais par concaténation), résultats en tuples, fermeture | Démo pas à pas, chacun se connecte | 25 |
| 15:20 | Écrire dans la base | `INSERT` paramétré puis `conn.commit()` sur la table d'essai `essais_commandes` (seule table où le login peut écrire) ; `insert_one` cité pour MongoDB (audit du 19/11) | Démo, chacun exécute | 10 |
| 15:30 | Neo4j depuis Python | Pilote `neo4j` : `execute_query` en Cypher, les enregistrements | Démo, chacun interroge sa base | 15 |
| 15:45 | Atelier · le code généré par IA | Un script de connexion « généré par IA » : mot de passe en dur, requête par concaténation, connexion jamais fermée, erreur étouffée ; corriger | Chasse aux bugs, binômes | 30 |
| 16:15 | Marge | Rattrapage des connexions qui résistent |  | 15 |
| 16:30 | Clôture | À retenir, quiz, avis ; vérifier son `.env` pour demain | | 30 |

Volume indicatif : environ 65 diapositives.

## 5. Jour 4 · jeudi 26/11 · Vers le machine learning

| Horaire | Séquence | Contenu | Forme | Durée |
|---|---|---|---|---|
| 08:30 | Ouverture | Récap du J3, quiz flash | | 15 |
| 08:45 | Du résultat de requête à pandas | Résultats d'une requête SQL Server vers un DataFrame ; `head`, filtres, `groupby` (le total par bière du J1, enfin compris) | Avant / après, démo | 25 |
| 09:10 | Exercices pandas | Ventes par bière, par client, par mois | Exercices numérotés | 20 |
| 09:30 | Un graphique simple | matplotlib : les ventes de fûts semaine après semaine | Démo | 15 |
| 09:45 | Machine learning facile | Prévoir les ventes de fûts : séparation entraînement / test, `fit`, `predict`, mesurer l'erreur | Démo guidée, chacun entraîne son modèle | 35 |
| 10:20 | Pause | | | 15 |
| 10:35 | Réseaux de neurones, en facile | Un neurone : entrées, poids, somme, activation ; des couches ; l'apprentissage ajuste les poids. Démonstration visuelle dans le navigateur (Neural Network Playground) | Schéma, démo, la salle prédit | 25 |
| 11:00 | Un petit réseau de neurones en Python | `MLPRegressor` de scikit-learn sur les mêmes ventes de fûts, avec mise à l'échelle des données ; comparer son erreur à celle de la régression | Démo guidée, chacun l'entraîne | 25 |
| 11:25 | Sumo des robots | Règles, état, actions ; stratégie contre les robots d'entraînement | Jeu 3, binômes | 35 |
| 12:00 | Marge | | | 30 |
| 13:30 | Tournoi de sumo | Tournoi projeté entre binômes | Jeu 3 | 30 |
| 14:00 | Le pipeline revisité | Retour au schéma du J1 : ce que vous savez faire maintenant ; ce qui arrive en janvier (Fabric) et en mars (scikit-learn, pandas / Polars) ; les outils de deep learning qu'ils croiseront | Synthèse | 15 |
| 14:15 | Questions et marge | | | 25 |
| 14:40 | Pause | | | 15 |
| 14:55 | Évaluation finale | Quiz et petit exercice de code | Individuel | 35 |
| 15:30 | Correction de l'évaluation | | | 25 |
| 15:55 | Bonus | Analyse des journaux du sumo avec pandas, « le robot qui apprend », séries du jeu | Au choix | 35 |
| 16:30 | Clôture du cours | À retenir sur 4 jours, questionnaire de fin de cours | | 30 |

Volume indicatif : environ 60 diapositives.

Faits vérifiés pour ce jour (sources 59 et 60, testés en Python 3.14) :
- scikit-learn propose un réseau de neurones simple, le perceptron multicouche (`MLPClassifier`, `MLPRegressor`) ; sa documentation prévient qu'il n'est pas prévu pour les grands volumes et n'utilise pas de carte graphique, et renvoie vers d'autres outils pour le deep learning.
- Le perceptron multicouche est sensible à l'échelle des données : la documentation recommande de les standardiser (`StandardScaler`), de préférence dans un pipeline, avec la même transformation sur les données de test.
- Neural Network Playground : visualisation interactive d'un réseau de neurones, dans le navigateur, sans installation (taux d'apprentissage, activation, données, couches) [À VÉRIFIER : accès depuis le réseau de Technifutur].
- Essai du 17/11/2026 sur des ventes de fûts fictives (104 semaines) : erreur moyenne 3,26 fûts pour la régression, 3,17 pour un petit réseau de neurones. Message pour la salle : un réseau de neurones n'est pas magique ; il ne vaut que par les données qu'on lui donne.
- Pilotes des bases (J3) : voir sources 53 à 58.

### Proposition en attente (17/11/2026) : réseaux de neurones approfondis

Demande du formateur : une stagiaire docteure en neurosciences connaît bien le neurone biologique ; aller plus loin, d'abord en théorie sans code, puis en Python.
Proposition : passer de 50 à 85 min en reprenant les 35 min de bonus de 15:55.

| Bloc | Contenu | Durée |
|---|---|---|
| Théorie sans code | Neurone artificiel : entrées, poids, biais, somme pondérée, activation ; couches cachées ; prédiction ; erreur (perte) ; apprendre = ajuster poids et biais pour réduire l'erreur (descente de gradient, rétropropagation en intuition) ; surapprentissage | 35 |
| Neural Network Playground | La salle prédit puis vérifie : sans couche cachée, avec couches, activation, taux d'apprentissage | 15 |
| Un neurone à la main en Python | Une fonction `neurone(entrees, poids, biais)` en Python pur (réutilise les fonctions du J3), calculée à la main puis exécutée | 10 |
| Le réseau dans scikit-learn | `MLPRegressor` dans un pipeline ; lire `coefs_` (poids) et `intercepts_` (biais) ; changer `random_state` et constater des résultats différents | 25 |

Faits vérifiés (source 59, code testé en Python 3.14) :
- chaque neurone fait une somme pondérée des valeurs de la couche précédente, puis applique une activation non linéaire ;
- `coefs_` : matrices de poids entre couches ; `intercepts_` : vecteurs de biais ; essai : couches (16, 16) → poids (1, 16), (16, 16), (16, 1) ;
- entraînement par descente de gradient, gradients calculés par rétropropagation ;
- perte non convexe : plusieurs minimums locaux, des initialisations différentes donnent des résultats différents ; essai sur les 26 dernières semaines : erreur 3,28 (random_state 0), 14,03 (1), 14,06 (2) ; avertissement de convergence à 3000 itérations ;
- activation par défaut constatée dans le code : `relu` (le texte de la page décrit tanh dans la formule) ; solveur par défaut constaté : `adam`.
- Schémas animés du bloc : A03 à A08 (`03-supports/animations/README.md`) ; surapprentissage sourcé (source 66), taux d'apprentissage (65), rétropropagation (64).
- Comparaison neurone biologique / artificiel : [À VÉRIFIER, aucune source consultée] ; ne rien affirmer sans source, la stagiaire peut challenger l'analogie.

Retiré par rapport à la version précédente : les ventes à la main avec `csv` (déjà vu au J3), `datetime` (bonus), l'analyse des journaux du sumo et « le robot qui apprend » (bonus de 15:55). Hors périmètre (bibliothèque) : interfaces graphiques ou web, visualisation de graphes Neo4j, recherche vectorielle, frameworks de deep learning (installation trop lourde pour des postes sans droits).

## 6. Volumes et livrables à produire

| Livrable | J1 | J2 | J3 | J4 |
|---|---|---|---|---|
| Diapositives | 73 (storyboard écrit) | ~65 | ~65 | ~60 |
| Exercices numérotés | 0.1, 1.1-1.8, 2.1-2.4, chasse 1 | modules 3 à 6, chasse 2, atelier livraison | modules 7, 8, chasse 3, venv, `.env`, connexions aux 3 bases, atelier code généré par IA | pandas, graphique, modèle de prévision, réseau de neurones |
| Jeu | — | Jeu 1 séries 1-6 | Jeu 1 séries 7-8 | Sumo (entraînement et tournoi) |
| Données | fiche brasserie | commandes du jour, stock | `commandes.csv` sale ; scripts de création des données de la brasserie dans SQL Server, MongoDB et Neo4j | historique des ventes de fûts |
| Évaluation | quiz du jour | quiz du jour | quiz du jour | évaluation finale + questionnaire de fin |
| À livrer avant | 19/11 | 23/11 | 24/11 | 25/11 |

## 7. Décisions macro

Prises le 17/11/2026 :
- Connexion de Python à SQL Server, MongoDB et Neo4j avec variables d'environnement, et atelier sur un code de connexion généré par IA (placés au J3) ; machine learning facile (prévoir les ventes de fûts) ; coupes acceptées (ventes à la main, `datetime`, analyse des journaux et « le robot qui apprend » en bonus).
- Réseaux de neurones « en facile » au J4 (perceptron multicouche de scikit-learn, démonstration dans le navigateur) ; chapitres 3 à 5 accélérés, dictionnaires avancés au J2, bases de données avancées au J3.

Encore ouvertes :
1. **Évaluation finale** : format (quiz seul, quiz + exercice de code), notée ou formative (35 min prévues).
2. **Débogueur de VS Code** au jour 2 (15 min) : à garder, ou en bonus ?
3. **Tournoi de sumo** : collecte des stratégies par formulaire ou par dossier partagé.
7. **Production du jeu** : avec les dictionnaires au J2, les séries 1 à 6 du jeu 1 doivent être prêtes pour le 24/11 (au lieu de 1 à 5).
4. **Volume des jours 2 et 3** : J2 porte quatre chapitres (rythme rapide supposé), J3 deux chapitres et les bases de données ; à confirmer après le tri des anciens supports ; repli : séries du jeu et exercices en autonomie le 27/11.
5. **Récap du matin** (J3, J4) : quiz flash de 5 minutes, ou autre forme ?
6. **Bases de données sur les postes** : toujours présentes le 26/11 ? identifiants et mode d'authentification de SQL Server à connaître avant de préparer les démos.
