# Storyboard — Jour 3 · mardi 24/11/2026

> **Mise à jour du 22/11/2026.** J3-58b : le championnat des robots remplace le sumo (décision du 21/11, règles enrichies le 22/11 : `04-ateliers/jeux/09-championnat-robots.md`) ; séries 7 et 8 jouées dans l'usine. Le reste de la version 1.3 est inchangé.

> Déroulé : `storyboard-macro.md` § 4 (jour 3), inchangé par la réorganisation en cinq jours du 19/11/2026 (§ 0). Le J2 a été donné le vendredi 20/11 par un collègue, avec les supports du cours. Fil rouge : `01-notes/fil-rouge-brasserie.md`. Charte : `chartes/bstorm/charte.md`. Sources : numéros de `01-notes/sources.md` (88 à 101 ajoutées le 19/11/2026).
> **Statut : version 1.3 du 19/11/2026, validée par le formateur** (version 1.2 validée le 19/11 ; la 1.3 applique sa décision après l'audit de couverture). Version 1.3 : séquence « Écrire dans la base » ajoutée (15:20, 10 min, J3-48b) ; Neo4j et l'atelier décalés de 10 min ; marge de fin 25 → 15 min. Version 1.2 : J3-58b ajoutée (sumo, robot 1 en exercice de liaison, décision du 19/11). Version 1.1 : cinq schémas animés ajoutés (A11, A12, A13, A02, A14 ; décision du formateur du 19/11), une diapositive chacun, 2 minutes prises dans la séquence où elle se trouve.
> 67 diapositives + 3 de réserve. Chaque code affiché sans base de données est repris dans `04-ateliers/J3/verification-storyboard.py` et a été exécuté en Python 3.14.6 le 19/11/2026 ; ses sorties sont celles écrites ici. Le code des trois bases ne peut pas tourner ici (pas de serveur SQL Server, MongoDB ni Neo4j) : il est écrit d'après la documentation officielle et les pilotes installés (mssql-python 1.18.0, pymongo 4.20.0, neo4j 6.4.1, python-dotenv 1.2.4), et marqué « à exécuter en salle ».
> **Noyau et bonus** : comme au J2, la première mission de chaque série est le noyau ; dans chaque module, les exercices du noyau sont annoncés. Le reste est du bonus.
> **Les données de la brasserie dans vos bases** (à produire avec les ateliers, après validation) : un script SQL (base `Fonderie` : tables `bieres`, `clients`, `ventes` ; login `cours_python` en lecture, et en écriture sur la seule table d'essai `essais_commandes` (`GRANT INSERT`, source 112)), un script mongosh (base `fonderie`, collection `clients`), un script Cypher (clients, livraisons, bières). Les mêmes ventes servent au J4 (pandas) et au J5 (modèle).
> **Point de décision à 14:30** : si l'installation du venv a pris plus de 30 minutes, Neo4j passe en démonstration seule et en bonus.
> Règles reprises des jours 1 et 2 : un titre tient sur une ligne (45 caractères au plus), un titre de carte en 25 caractères, une question de quiz sur une ligne ; le détail va dans les notes orateur ; position des bonnes réponses variée.

---

## Ouverture · 08:30 - 08:45

### J3-01 · `titre`
- Surtitre : FORMATION · DATA ANALYST 2026
- Titre : Python de base
- Sous-titre : Jour 3 · Fiabiliser et se connecter
- Formateur : Pierre Juif · Date : 24 novembre 2026 · Lieu : Technifutur Seraing
- Oral : vendredi, c'était un collègue ; tour de salle : qu'est-ce qui a marché, qu'est-ce qui coince ?

### J3-02 · `programme`
- Surtitre : JOUR 3 · MARDI 24 NOVEMBRE
- Titre : Fiabiliser et se connecter
- Matin · 8:30 - 12:30 : 08:45 Les fonctions · 09:10 Jeu, série 7 · 09:50 Lire une signature · 10:00 Les fichiers · 10:35 Les erreurs · 10:50 Jeu, série 8 · 11:40 Marge
- Après-midi · 13:30 - 17:00 : 13:30 Le venv · 13:55 Ranger un projet · 14:10 Les secrets · 14:30 MongoDB · 14:55 SQL Server · 15:20 Écrire dans la base · 15:30 Neo4j · 15:45 Le code de l'IA · 16:30 Quiz
- Durée : 2 min · Source : storyboard-macro.md § 4

### J3-03 · `objectifs`
- Surtitre : OBJECTIFS DU JOUR
- Titre : Ce soir, vous saurez faire quatre choses
- Réutiliser — un calcul, écrit une fois dans une fonction
- Lire — un fichier CSV sans planter sur une ligne sale
- Isoler — un projet dans son environnement virtuel
- Interroger — vos trois bases depuis Python, sans mot de passe dans le code
- Durée : 2 min

### J3-04 · `quatre-cartes`
- Surtitre : LES CINQ JOURS
- Titre : Vous êtes ici : fiabiliser et se connecter
- Cartes : J1 et J2 · Les bases — Fait : variables, texte, conditions, listes, boucles, dictionnaires · J3 · Fiabiliser et se connecter — Aujourd'hui : fonctions, fichiers, vos trois bases · J4 · Analyser avec pandas — Demain : vos ventes dans un tableau · J5 · Vers le machine learning — Jeudi : modèle, réseau de neurones, sumo
- Durée : 1 min · Source : storyboard-macro.md § 0

### J3-05 · `vrai-faux`
- Surtitre : QUIZ FLASH · VENDREDI
- Titre : Vrai ou faux ? Trois idées de vendredi
- 1. `stock.get("B07", 0)` plante si la clé B07 n'existe pas. — **Faux** : `get` renvoie la valeur par défaut (41).
- 2. Dans une liste, `commandes[-1]` est la dernière commande. — **Vrai** (22).
- 3. Une boucle `while` s'arrête toute seule au bout de 1 000 tours. — **Faux** : elle tourne tant que sa condition est vraie (67, 76).
- Interaction : la salle vote à main levée avant chaque réponse · Durée : 5 min
- Oral : repérer qui hésite : ce sont eux qui ont besoin du rattrapage de 11:40.

---

## Chapitre 7 · Les fonctions · 08:45 - 09:10

### J3-06 · `section`
- Numéro : 07
- Titre : Les fonctions
- Sous-titre : Écrire un calcul une fois, l'appeler partout

### J3-07 · `definition`
- Surtitre : DÉFINITION
- Titre : Une fonction donne un nom à un calcul
- Mot : fonction — nom féminin · `def`
- Définition : Un bloc de code nommé, qui reçoit des valeurs (les paramètres) et renvoie un résultat avec `return`.
- Exemple : `def prix_futs(nb_futs, prix_fut, remise):` … `prix_futs(4, 62.00, 0.10)` vaut 223.2
- Durée : 2 min · Source : 67 (§ 4.8)
- Oral : vous en utilisez depuis jeudi : `print`, `len`, `int` sont des fonctions. Aujourd'hui, vous écrivez les vôtres.

### J3-07b · `titre-seul` · schéma animé A11
- Surtitre : SCHÉMA
- Titre : Les valeurs entrent, le résultat sort
- Visuel : schéma animé A11-appel-fonction (8 à 12 s, boucle) : `prix_futs(4, 62.00, 0.10)` ; les trois valeurs glissent dans les trois paramètres de la boîte `def` ; le calcul s'allume ligne par ligne ; `return` envoie 223.2 vers `total = …` à l'extérieur. Seconde passe : une boîte sans `return`, c'est `None` qui sort. Image fixe pour le PDF : la valeur 223.2 sortie de la boîte.
- Durée : 2 min · Source : 67 (§ 4.8 : paramètres, `return`, `None` sans `return`)
- Oral : la boîte ne voit que ce qu'on lui donne, et l'extérieur ne voit que ce qu'elle renvoie.

### J3-08 · `code-avant-apres`
- Surtitre : LE PROBLÈME
- Titre : Un calcul recopié est un calcul à corriger trois fois
- Avant (titre : Recopié) :
  ```python
  total_cafe = 4 * 62.00
  total_cafe = total_cafe - total_cafe * 0.10
  total_comptoir = 6 * 62.00
  total_comptoir = total_comptoir - total_comptoir * 0.10
  ```
- Après (titre : Nommé une fois) :
  ```python
  def prix_futs(nb_futs, prix_fut, remise):
      total = nb_futs * prix_fut
      return total - total * remise

  print(prix_futs(4, 62.00, 0.10), prix_futs(6, 62.00, 0.10))
  ```
- Résultat (les deux versions) : `223.2 334.8`
- Durée : 3 min · Source : 67 ; exécuté
- Oral : le jour où la remise des cafés passe à 12 %, la version de gauche se corrige à deux endroits, et on en oublie un. C'est le même principe qu'une vue en SQL.

### J3-09 · `code-resultat`
- Surtitre : DÉMO
- Titre : Une valeur par défaut rend un paramètre facultatif
- Fichier : facturer.py
- Code :
  ```python
  def facturer(nb_futs, prix_fut, remise=0):
      total = nb_futs * prix_fut
      return total - total * remise

  print(facturer(4, 62.00))
  print(facturer(4, 62.00, remise=0.10))
  ```
- Résultat : `248.0` / `223.2`
- Interaction : démo en direct · Durée : 4 min · Source : 67 (§ 4.9.1 et 4.9.2) ; exécuté
- Oral : `remise=0.10` est un argument nommé : c'est la forme que vous lirez partout dans pandas et scikit-learn. Règle : les arguments nommés viennent après les autres (67). Piège à signaler sans le démontrer : une valeur par défaut est calculée une seule fois ; jamais de liste vide comme valeur par défaut (67, avertissement « Important warning »).

### J3-10 · `quiz`
- Surtitre : PRÉDISEZ · QUESTION 1 SUR 2
- Titre : Qu'affiche ce programme ?
- Code : `def afficher_total(nb_futs, prix_fut):` / `    print(nb_futs * prix_fut)` / (ligne vide) / `total = afficher_total(2, 68.00)` / `print(total)`
- A : 136.0 deux fois · B : 136.0, puis None · C : None · D : Une erreur
- Réponse : B · Résultat exécuté : `136.0` / `None`
- Durée : 3 min · Source : 67 (« Falling off the end of a function also returns None ») ; exécuté
- Oral : afficher n'est pas renvoyer. Une fonction sans `return` renvoie `None` : c'est le contrôle surprise de la série 7.

### J3-11 · `code-resultat`
- Surtitre : DÉMO
- Titre : Une fonction peut renvoyer deux valeurs à la fois
- Fichier : facture.py
- Code :
  ```python
  def facture(nb_futs, prix_fut):
      total = nb_futs * prix_fut
      consigne = nb_futs * 30.00
      return total, consigne

  montant, consigne = facture(3, 72.00)
  print(f"{montant:.2f} € + {consigne:.2f} € de consigne")
  ```
- Résultat : `216.00 € + 90.00 € de consigne`
- Durée : 3 min · Source : 72 (tuples et décomposition) ; fil rouge (consigne de 30,00 € par fût) ; exécuté
- Oral : `return total, consigne` renvoie un tuple ; la décomposition de vendredi le range dans deux noms. En mars : `X_train, X_test, y_train, y_test = …`, la même chose.

### J3-12 · `vrai-faux`
- Surtitre : LA PORTÉE
- Titre : Vrai ou faux ? Trois idées sur la portée
- 1. Une variable créée dans une fonction existe encore après l'appel. — **Faux** : `print(total)` après l'appel donne `NameError: name 'total' is not defined` (67 ; exécuté).
- 2. Une fonction peut lire une variable définie en dehors d'elle. — **Vrai**, mais elle ne peut pas la modifier sans `global` (67). Le cours s'en passe.
- 3. Une fonction sans `return` renvoie 0. — **Faux** : elle renvoie `None` (67).
- Interaction : la salle vote · Durée : 3 min

### J3-13 · `quiz`
- Surtitre : PRÉDISEZ · QUESTION 2 SUR 2
- Titre : Qu'affiche ce programme ?
- Code : `def retirer_premiere(commandes):` / `    commandes.pop(0)` / `    return len(commandes)` / (ligne vide) / `file = ["Café du Pont", "Cave aux Bulles", "Marie Dumont"]` / `reste = retirer_premiere(file)` / `print(reste, len(file))`
- A : 2 3 · B : 3 3 · C : 2 2 · D : Une erreur
- Réponse : C · Résultat exécuté : `2 2`
- Durée : 4 min · Source : 27 (Programming FAQ : « arguments are passed by assignment » ; `y = x` ne copie pas la liste) ; exécuté
- Oral : `commandes` et `file` sont deux noms pour la même liste. La fonction a vidé la file du préparateur sans le dire. Pour ne pas y toucher : travailler sur une copie, `commandes[1:]` ou `list(commandes)`. C'est le test caché de la série 7.

### J3-13b · `titre-seul` · schéma animé A12
- Surtitre : SCHÉMA
- Titre : Deux noms, une seule liste
- Visuel : schéma animé A12-deux-noms (8 à 10 s) : une liste de trois clients dans un bac ; l'étiquette `file` pointe dessus ; à l'appel, une deuxième étiquette `commandes` se colle sur le même bac ; `pop(0)` retire le premier client : les deux étiquettes voient deux éléments. Fin : `commandes[1:]` crée un second bac, le premier reste intact. Image fixe : les deux étiquettes sur le même bac.
- Durée : 2 min · Source : 27 (Programming FAQ : `y = x` ne copie pas, les arguments sont passés par affectation)
- Oral : montrer après la réponse du quiz, pas avant.

### J3-14 · `code-resultat`
- Surtitre : BONNE PRATIQUE
- Titre : Une docstring dit ce que la fonction renvoie
- Fichier : facturer.py
- Code :
  ```python
  def facturer(nb_futs, prix_fut, remise=0):
      """Renvoie le prix des fûts, remise déduite (0.10 pour 10 %)."""
      total = nb_futs * prix_fut
      return total - total * remise

  help(facturer)
  ```
- Résultat : `facturer(nb_futs, prix_fut, remise=0)` / `    Renvoie le prix des fûts, remise déduite (0.10 pour 10 %).`
- Durée : 2 min · Source : 67 (§ 4.9.7 : une première ligne courte, majuscule, point final) ; exécuté (la sortie de `help` commence par une ligne « Help on function facturer… », coupée ici)
- Oral : la docstring est ce que vous lirez demain en survolant `read_csv` : celle de pandas fait plusieurs pages.

---

## Jeu série 7 · 09:10 - 09:25

### J3-15 · `exercice`
- Surtitre : JEU · SÉRIE 7
- Titre : La facture, écrite une seule fois
- Durée : 15 min · Niveau : Débutant · Format : Seul · Livrable : Série 7
- Consigne : Écrivez `facturer()` avec une remise facultative. · Renvoyez le prix et la consigne en une fois. · Préparez une commande sans toucher à la liste reçue.
- Encart · Indice : Afficher n'est pas renvoyer.
- Source : 03-jeu1-missions.md § 11 (série 7) ; missions de l'usine, ouvertes depuis la carte des missions (python-game-beer.netlify.app) ; étoile 2 = la notion de la série est utilisée (`jeux-python/CONCEPTION-usine.md` § 8)
- Oral : noyau : la première mission. Contrôle surprise : la liste reçue doit rester intacte. Plan B : `missions-J3/serie7/` dans VS Code.

---

## Exercices module 7 · 09:25 - 09:50

### J3-16 · `exercice`
- Surtitre : MODULE 7 · EXERCICES 7.1 À 7.4
- Titre : La facture d'une commande
- Durée : 20 min · Niveau : Débutant · Format : Seul · Livrable : facturation.py
- Consigne : 7.1 `prix_casiers(nb_casiers, prix_casier)` renvoie le prix de casiers sans consigne. · 7.2 Ajoutez `remise=0`, en pourcentage décimal. · 7.3 `consigne(nb_casiers, nb_futs)` : 3,00 € par casier, 30,00 € par fût. · 7.4 `facture_magasin(nb_casiers, prix_casier)` applique la remise magasin (2 % dès 5 casiers, 5 % dès 10) en appelant 7.2.
- Encart · Réussi si : `prix_casiers(12, 26.40, remise=0.05)` donne 300.96 ; `consigne(12, 2)` donne 96.0 ; `facture_magasin(7, 31.20)` donne 214.03 (arrondi au centime).
- Source : fil rouge (prix, consignes, remises magasin) ; valeurs exécutées en Python 3.14.6 (300.96, 96.0, 214.032 arrondi à 214.03)
- Oral : noyau : 7.1 et 7.3. Développeurs : écrire les docstrings et appeler 7.4 pour les trois paliers. De 09:45 à 09:50 : correction à chaud de 7.4 (une fonction qui en appelle une autre).

---

## Lire une signature · 09:50 - 10:00

### J3-17 · `code-explications`
- Surtitre : PRÉPARER DEMAIN
- Titre : Une signature se lit comme une liste de réglages
- Code :
  ```python
  pandas.read_csv(filepath_or_buffer, *, sep=..., delimiter=None,
                  header='infer', names=..., index_col=None,
                  usecols=None, dtype=None, ..., decimal='.', ...)

  ventes = pd.read_csv("ventes.csv", sep=";", decimal=",")
  ```
- Explications : `filepath_or_buffer` — le seul argument sans nom : le fichier · `*` — tout ce qui suit s'écrit nommé (`sep=`) · `sep=";"` — le séparateur d'un CSV exporté d'Excel en français · `decimal=","` — la virgule des nombres européens
- Durée : 5 min · Source : 52 (read_csv) ; signature relue dans pandas 3.1.1 installé : `filepath_or_buffer` positionnel ou nommé, `sep` et les suivants « keyword-only » (après `*`), `decimal='.'` par défaut
- Oral : vous ne lirez jamais les 50 paramètres. Méthode : le nom de la fonction, les arguments sans valeur par défaut (obligatoires), puis seulement ceux dont vous avez besoin. Ouvrir la page de `read_csv` à l'écran.

### J3-18 · `quiz`
- Surtitre : PRÉDISEZ
- Titre : Lequel de ces appels est refusé par Python ?
- A : `facturer(4, 62.00)` · B : `facturer(4, prix_fut=62.00)` · C : `facturer(remise=0.10, 4, 62.00)` · D : `facturer(nb_futs=4, prix_fut=62.00)`
- Réponse : C · exécuté : `SyntaxError: positional argument follows keyword argument`
- Durée : 2 min · Source : 67 (§ 4.9.2 : « keyword arguments must follow positional arguments »)

---

## Chapitre 8 · Fichiers et import · 10:00 - 10:20

### J3-19 · `section`
- Numéro : 08
- Titre : Les fichiers et les erreurs
- Sous-titre : Lire le lot du vendredi soir sans planter

### J3-20 · `code-explications`
- Surtitre : LES MODULES
- Titre : `import` ouvre la boîte à outils de Python
- Code :
  ```python
  import csv
  from datetime import date
  import pandas as pd
  ```
- Explications : `import csv` — tout le module, on écrit `csv.reader` · `from datetime import date` — un seul outil, on écrit `date` · `as pd` — un alias court, la convention de pandas
- Durée : 3 min · Source : 70 (modules) ; 52 (convention `import pandas as pd` dans la documentation de pandas) [À VÉRIFIER : convention `pd` à citer depuis la page 52 ou le guide « 10 minutes to pandas »]
- Oral : `csv` et `datetime` sont livrés avec Python (bibliothèque standard) ; pandas s'installe, cet après-midi.

### J3-21 · `code-resultat`
- Surtitre : DÉMO
- Titre : `with open` ferme le fichier, même en cas d'erreur
- Fichier : lire_commandes.py
- Code :
  ```python
  import csv

  with open("commandes.csv", encoding="utf-8", newline="") as f:
      for ligne in csv.reader(f, delimiter=";"):
          print(ligne)
  ```
- Résultat (3 premières lignes sur 8) : `['date', 'client', 'biere', 'format', 'quantite']` / `['2026-11-20', 'C01', 'B01', 'fut', '4']` / `['2026-11-20', 'C05', 'B03', 'casier', '12']`
- Visuel : à côté du code, le fichier `commandes.csv` ouvert dans VS Code (8 lignes, séparateur `;`)
- Durée : 5 min · Source : 40 → reconsultée en 3.14 (88 : `with`, `encoding="utf-8"` recommandé) ; 89 (csv : `newline=''`, `delimiter`, chaque ligne est une liste de chaînes) ; exécuté
- Oral : regarder les guillemets : `'4'` est du texte. Le module csv ne convertit rien (89).

### J3-22 · `code-resultat`
- Surtitre : DÉMO
- Titre : `DictReader` range chaque ligne dans un dictionnaire
- Fichier : lire_commandes.py
- Code :
  ```python
  with open("commandes.csv", encoding="utf-8", newline="") as f:
      lecteur = csv.DictReader(f, delimiter=";")
      premiere = next(lecteur)
  print(premiere)
  print(premiere["quantite"] * 2)
  ```
- Résultat : `{'date': '2026-11-20', 'client': 'C01', 'biere': 'B01', 'format': 'fut', 'quantite': '4'}` / `44`
- Interaction : « Prédisez » la seconde ligne avant d'exécuter (réponse attendue : 8 ; réponse réelle : 44)
- Durée : 4 min · Source : 89 (DictReader : clés = première ligne) ; exécuté
- Oral : `"4" * 2` répète le texte. Il faut `int(premiere["quantite"])`. `next` prend une seule ligne : mentionné, pas enseigné.

### J3-23 · `code-resultat`
- Surtitre : LE PROBLÈME
- Titre : Une seule ligne sale arrête tout le programme
- Code : `print(int("12 kg"))`
- Résultat : `ValueError: invalid literal for int() with base 10: '12 kg'`
- Durée : 2 min · Source : 68 (ValueError) ; exécuté
- Oral : le lot du vendredi soir a 7 commandes ; la sixième dit « 12 kg ». Sans protection, les commandes suivantes ne sont jamais lues. Transition vers la pause : « après la pause, on met un filet ».

### J3-24 · `pause`
- Titre : Pause · Reprise : On reprend à 10:35. · Consigne : Ensuite : `try` et `except`. · Durée : 15'

---

## try / except · 10:35 - 10:50

### J3-25 · `definition`
- Surtitre : DÉFINITION
- Titre : `try` essaie, `except` rattrape l'erreur prévue
- Mot : exception — nom féminin · `try` / `except`
- Définition : Une erreur levée pendant l'exécution ; `except` l'attrape si son type correspond, et le programme continue après le bloc.
- Exemple : `try:` `quantite = int("12 kg")` `except ValueError:` `quantite = 0`
- Durée : 2 min · Source : 90 (tutoriel « Errors and Exceptions » : le reste du `try` est sauté ; l'exception non attrapée arrête le programme)
- Oral : on attrape l'erreur qu'on attend, `ValueError`, pas toutes les erreurs.

### J3-25b · `titre-seul` · schéma animé A13
- Surtitre : SCHÉMA
- Titre : La ligne sale est déviée, les autres passent
- Visuel : schéma animé A13-try-except (10 à 14 s) : les lignes de `commandes.csv` avancent une par une sur un tapis ; chacune entre dans le bloc `try` ; `'12 kg'` déclenche `ValueError` : elle bascule vers `except` (rouge, « Ligne rejetée ») ; les autres sortent par `else` et s'ajoutent au total ; le tapis continue. Variante finale grisée : sans `try`, le tapis s'arrête à la ligne sale. Image fixe : la ligne rouge déviée, le tapis qui continue.
- Durée : 2 min · Source : 90 (déroulement de try / except / else)
- Oral : même image que le jeu : la ligne sale ne fait plus tomber toute la chaîne.

### J3-26 · `code`
- Surtitre : DÉMO
- Titre : La ligne sale est rejetée, les autres sont comptées
- Fichier : total_casiers.py
- Code :
  ```python
  import csv

  total = 0
  with open("commandes.csv", encoding="utf-8", newline="") as f:
      for ligne in csv.DictReader(f, delimiter=";"):
          try:
              quantite = int(ligne["quantite"])
          except ValueError:
              print("Ligne rejetée :", ligne["quantite"])
          else:
              if ligne["format"] == "casier":
                  total += quantite
  print("Casiers commandés :", total)
  ```
- Résultat : `Ligne rejetée : 12 kg` / `Casiers commandés : 15`
- Durée : 5 min · Source : 90 (`else` : exécuté si le `try` n'a pas levé d'exception, préférable à du code dans le `try`) ; 89 ; exécuté [script à recalculer avec le fichier final]
- Oral : 12 + 6 − 3 = 15. Le `try` a laissé passer −3 casiers et le client C99 : ce ne sont pas des erreurs Python, ce sont des erreurs métier. C'est l'exercice de 11:05.

### J3-27 · `vrai-faux`
- Surtitre : VRAI OU FAUX
- Titre : Vrai ou faux ? Trois idées sur `try`
- 1. `finally` s'exécute même si une erreur a été levée. — **Vrai** (90).
- 2. Un `except` sans type est une bonne habitude : on attrape tout. — **Faux** : on cache aussi les erreurs qu'on n'attendait pas ; c'est un des bugs de l'atelier de 15:45 (90).
- 3. `date.fromisoformat("2026-11-31")` donne le 1er décembre. — **Faux** : `ValueError: day 31 must be in range 1..30 for month 11 in year 2026` (91 ; exécuté).
- Durée : 4 min
- Oral : la troisième ligne prépare l'exercice : une date impossible se détecte avec le même `try`.

---

## Jeu série 8 · 10:50 - 11:05

### J3-28 · `exercice`
- Surtitre : JEU · SÉRIE 8
- Titre : Le lot du vendredi soir
- Durée : 15 min · Niveau : Débutant · Format : Seul · Livrable : Série 8
- Consigne : Comptez les lignes du lot. · Convertissez chaque quantité sans planter. · Écartez la date impossible.
- Encart · Indice : Une quantité négative n'est pas une erreur Python.
- Source : 03-jeu1-missions.md § 11 (série 8) ; missions de l'usine (le fichier est fourni par la mission)
- Oral : noyau : la première mission. Plan B : `missions-J3/serie8/`.

---

## Exercices module 8 et chasse aux bugs 3 · 11:05 - 11:40

### J3-29 · `exercice`
- Surtitre : MODULE 8 · EXERCICES 8.1 À 8.4
- Titre : Le lot du vendredi soir, ligne par ligne
- Durée : 25 min · Niveau : Intermédiaire · Format : Binômes · Livrable : lot_vendredi.py
- Consigne : 8.1 Comptez les lignes de `lot_vendredi.csv` (sans l'en-tête). · 8.2 Rejetez, avec leur motif, les quantités illisibles ou négatives. · 8.3 Rejetez les clients inconnus (codes C01 à C08) et les dates impossibles. · 8.4 Totalisez les casiers acceptés par bière, dans un dictionnaire.
- Encart · Réussi si : 16 lignes ; 5 rejetées (2 quantités illisibles, 1 négative, 1 client inconnu, 1 date impossible) ; 11 acceptées ; casiers acceptés : B01 14, B02 2, B03 13, B04 3 (corrigé `04-ateliers/J3/corriges/lot_vendredi.py`, exécuté le 20/11)
- Source : fil rouge ; 89, 90, 91 ; fichier et corrigé à produire avec les ateliers
- Oral : noyau : 8.1 et 8.2. Une fonction `ligne_valide(ligne)` qui renvoie `(True, "")` ou `(False, motif)` : c'est le chapitre 7 appliqué.

### J3-30 · `exercice`
- Surtitre : CHASSE AUX BUGS 3
- Titre : Trois scripts lisent le fichier, trois se trompent
- Durée : 10 min · Niveau : Intermédiaire · Format : Binômes · Livrable : la règle de chaque bug
- Consigne : Un collègue a laissé trois scripts dans le dossier partagé. Chacun tourne, chacun donne un résultat faux. · Trouvez la ligne, corrigez-la, écrivez la règle en une phrase.
- Encart · Méthode : Comparez le résultat avec le fichier ouvert à côté : la vérité est dans les données.
- Bugs prévus : `except:` sans type qui avale une faute de frappe dans un nom (`NameError` cachée : 0 casier) ; quantité additionnée comme texte (`Fûts commandés : 423` au lieu de 9) ; l'en-tête compté comme une commande avec `csv.reader` (8 au lieu de 7). Le bug de l'encodage est abandonné : son effet dépend du poste. Scripts : `04-ateliers/J3/chasse-aux-bugs-3/`, exécutés le 20/11
- Source : 88, 89, 90 ; scripts à écrire et exécuter avec les ateliers

---

## Correction et marge · 11:40 - 12:30

### J3-31 · `titre-seul`
- Surtitre : MARGE
- Titre : Correction, rattrapage, séries du jeu
- Interaction : correction de 8.2 et des trois bugs ; rattrapage du noyau du matin (le formateur va vers ceux qui ont hésité au quiz flash) ; les rapides : 8.4, séries 7 et 8 en entier
- Durée : 50 min

### J3-32 · `pause`
- Titre : Pause · Reprise : On reprend à 13:30. · Consigne : Pause de midi. Ensuite : chacun son environnement. · Durée : 1 h

---

## Séquence 7 · Bibliothèques et venv · 13:30 - 13:55

### J3-33 · `texte-encart`
- Surtitre : LE PROBLÈME
- Titre : « Ça marche sur mon PC » n'est pas une garantie
- Texte : Votre script de mars demandera pandas 3.1 ; celui d'un collègue, une version plus ancienne. Une seule installation de Python ne peut pas satisfaire tous les projets.
- Encart · titre : La réponse · texte : Un environnement virtuel par projet : son Python, ses paquets, sa liste.
- Durée : 2 min · Source : 92 (tutoriel « Virtual Environments and Packages » : une installation ne peut pas toujours satisfaire toutes les applications)

### J3-34 · `definition`
- Surtitre : DÉFINITION
- Titre : Un venv est un dossier jetable, pas un logiciel
- Mot : environnement virtuel — nom masculin · venv
- Définition : Un dossier qui contient un Python et les paquets d'un seul projet. Il ne va jamais dans Git : on le supprime et on le recrée.
- Exemple : `python -m venv .venv` crée le dossier `.venv` dans le projet.
- Durée : 2 min · Source : 92 (`.venv`, nom courant) ; 21 → reconsultée (93 : « disposable », « Not checked into source control systems such as Git »)

### J3-35 · `terminal`
- Surtitre : DÉMO · CHACUN FAIT PAREIL
- Titre : Trois commandes installent tout jusqu'à jeudi
- Titre de la fenêtre : Terminal de VS Code, dossier python-fonderie
- Commandes :
  ```
  python -m venv .venv
  .venv\Scripts\python -m pip install pandas matplotlib scikit-learn ipykernel python-dotenv mssql-python pymongo neo4j
  .venv\Scripts\python -m pip freeze > requirements.txt
  ```
- Étapes : 1. Créer — le dossier `.venv` · 2. Installer — dans le venv, par son propre Python · 3. Noter — les versions, dans `requirements.txt`
- Durée : 12 min (installation comprise) · Source : 92 (`python -m pip install`, `pip freeze > requirements.txt`) ; 93 (pas besoin d'activer : appeler le Python du venv par son chemin) ; demande IT (liste des paquets)
- Oral : on n'active pas le venv : sous PowerShell, l'activation peut être bloquée par la politique d'exécution (93), et on n'en a pas besoin. VS Code choisit le venv tout seul. Si `pip` échoue (pas d'accès à PyPI) : plan B de la demande IT, les paquets installés pour tous par l'IT. À vérifier sur un poste de la salle le jeudi 19/11.

### J3-36 · `processus-5`
- Surtitre : VS CODE
- Titre : VS Code choisit le venv du projet
- Étapes : 1. Ouvrir — le dossier python-fonderie · 2. Regarder — la version de Python, en bas à droite · 3. Choisir — « Python: Select Interpreter » si ce n'est pas `.venv` · 4. Exécuter — `import pandas` ne lève plus d'erreur · 5. Noter — un notebook choisit aussi son noyau
- Durée : 3 min · Source : 94 (VS Code : recherche des `.venv` du dossier, « Python: Select Interpreter », sélecteur dans la barre d'état)

### J3-37 · `vrai-faux`
- Surtitre : VRAI OU FAUX
- Titre : Vrai ou faux ? Trois idées sur le venv
- 1. Je copie mon dossier `.venv` sur la clé USB pour l'emporter. — **Faux** : il ne se déplace pas, il se recrée avec `requirements.txt` (93).
- 2. `pip install -r requirements.txt` réinstalle les mêmes versions. — **Vrai** (92).
- 3. Le venv contient aussi mon code. — **Faux** : le code reste à côté, dans le projet (93).
- Durée : 3 min

---

## Séquence 8 · Architecture d'un projet · 13:55 - 14:10

### J3-38 · `deux-colonnes`
- Surtitre : RANGER UN PROJET
- Titre : Chaque fichier a sa place dans le projet
- Colonne gauche (arborescence) : `python-fonderie/` · `data/` (commandes.csv, ventes.csv) · `src/` (facturation.py, lot_vendredi.py) · `notebooks/` (ventes.ipynb, demain) · `.venv/` · `.env` · `.gitignore` · `requirements.txt` · `README.md`
- Colonne droite : `data/` — les données, jamais modifiées à la main · `src/` — le code réutilisable · `.env` — vos secrets, sur votre poste seulement · `.gitignore` — ce que Git ignore : `.venv/` et `.env` · `requirements.txt` — de quoi recréer le venv
- Durée : 4 min · Source : 95 (gitignore : un nom ignoré à tout niveau, `/` final pour un dossier) ; 93 ; 96 (python-dotenv : ajouter `.env` au `.gitignore`) ; organisation `data/ src/ notebooks/` : pratique courante, pas une règle officielle (à dire comme tel)

### J3-39 · `exercice`
- Surtitre : À VOUS
- Titre : Rangez dix fichiers dans le bon dossier
- Durée : 8 min · Niveau : Débutant · Format : Binômes · Livrable : le dossier python-fonderie rangé
- Consigne : Déplacez les fichiers d'hier et de ce matin dans `data/`, `src/` ou à la racine. · Créez `.gitignore` avec deux lignes. · Ouvrez `requirements.txt` : combien de paquets ?
- Encart · Réussi si : `.gitignore` contient `.venv/` et `.env`.
- Durée totale de la séquence : 15 min
- Oral : un fichier déjà suivi par Git n'est pas concerné par `.gitignore` (95) : c'est pourquoi on l'écrit avant le premier commit.

---

## Variables d'environnement · 14:10 - 14:30

### J3-40 · `definition`
- Surtitre : DÉFINITION
- Titre : Un secret se lit, il ne s'écrit pas dans le code
- Mot : variable d'environnement — nom féminin · `os.getenv`
- Définition : Une valeur nommée, rangée hors du code, que le programme lit au démarrage.
- Exemple : `os.getenv("NEO4J_PASSWORD")` renvoie le mot de passe, ou `None` s'il n'existe pas.
- Durée : 3 min · Source : 58 (os.environ, os.getenv) ; exécuté (`None` pour une variable absente)
- Oral : l'atelier SQL + NoSQL : des mots de passe en dur, dans du code généré, parfois partagé. Aujourd'hui, ça s'arrête.

### J3-40b · `titre-seul` · schéma animé A02
- Surtitre : SCHÉMA
- Titre : Le mot de passe quitte le code
- Visuel : schéma animé A02-variables-env (10 à 12 s) : un script avec `PWD=Fonderie2026!` surligné en rouge ; le mot de passe glisse vers un fichier `.env` posé sur le poste ; dans le script, la ligne devient `os.getenv("NEO4J_PASSWORD")` ; une flèche part du `.env` vers la connexion ; Git passe sur le projet, prend le code, laisse `.env` grâce à `.gitignore`. Image fixe : le code sans secret, le `.env` à côté, Git qui l'ignore.
- Durée : 2 min · Source : 58, 95, 96
- Oral : le code peut circuler, le secret reste sur le poste.

### J3-41 · `code-avant-apres`
- Surtitre : DÉMO
- Titre : Le fichier `.env` reste sur votre poste
- Avant (titre : .env, à la racine du projet) :
  ```
  SQL_CONNECTION_STRING="Server=localhost;Database=Fonderie;UID=cours_python;PWD=…;Encrypt=yes;TrustServerCertificate=yes"
  MONGO_URI="mongodb://localhost:27017/"
  NEO4J_URI="neo4j://localhost:7687"
  NEO4J_USER="neo4j"
  NEO4J_PASSWORD="…"
  ```
- Après (titre : src/connexions.py) :
  ```python
  import os
  from dotenv import load_dotenv

  load_dotenv()
  print(os.getenv("MONGO_URI"))
  ```
- Résultat : `mongodb://localhost:27017/`
- Durée : 6 min · Source : 96 (python-dotenv 1.2.4 : `load_dotenv()` cherche `.env` dans le dossier du script puis dans les dossiers parents ; n'écrase pas une variable existante ; format `CLE=valeur`) ; 97 (forme de la chaîne SQL Server en authentification SQL) ; 99 (URI MongoDB locale) ; 100 (URI Neo4j `neo4j://localhost`, port Bolt 7687) ; exécuté (script dans `src/`, `.env` à la racine : trouvé)
- Oral : adresses : celles que vous avez retrouvées pour l'exercice de vendredi soir. Les mots de passe ne passent jamais par le chat de la formation ni par une feuille.

### J3-42 · `vrai-faux`
- Surtitre : VRAI OU FAUX
- Titre : Vrai ou faux ? Trois idées sur les secrets
- 1. Un mot de passe dans le code est sûr si le dépôt est privé. — **Faux** : le code se copie, se partage, se colle dans une IA.
- 2. `os.getenv("ABSENT")` plante. — **Faux** : il renvoie `None` (58 ; exécuté).
- 3. `.env` doit être dans `.gitignore` avant le premier commit. — **Vrai** (95, 96).
- Durée : 3 min
- Oral : le premier point est une pratique de sécurité, pas une règle de Python : le dire comme tel.

### J3-43 · `exercice`
- Surtitre : À VOUS
- Titre : Votre `.env` en cinq lignes
- Durée : 8 min · Niveau : Débutant · Format : Seul · Livrable : .env et connexions.py
- Consigne : Créez `.env` à la racine avec vos adresses. · Lancez `connexions.py` : il affiche vos trois adresses, jamais un mot de passe.
- Encart · Réussi si : `None` n'apparaît nulle part.

---

## MongoDB depuis Python · 14:30 - 14:40

### J3-44 · `code-resultat`
- Surtitre : DÉMO · MONGODB
- Titre : Un document MongoDB arrive en dictionnaire
- Fichier : src/clients_mongo.py
- Code :
  ```python
  import os
  from dotenv import load_dotenv
  from pymongo import MongoClient

  load_dotenv()
  with MongoClient(os.getenv("MONGO_URI")) as client:
      clients = client["fonderie"]["clients"]
      cafe = clients.find_one({"type": "café"})
      print(cafe["nom"], cafe["ville"])
  ```
- Résultat attendu (à exécuter en salle) : `Café du Pont Seraing`
- Interaction : chacun exécute sur sa base · Durée : 10 min
- Source : 99 (MongoClient, URI locale, `with` ferme le client) ; 101 (accès par crochets à la base et à la collection) ; 98 (`find_one` renvoie le premier document correspondant comme dictionnaire Python, ou `None`)
- Oral : promesse de vendredi tenue : le document est un dictionnaire, la doc le dit (98). `find` renvoie un curseur, qu'on parcourt avec `for`. Si `find_one` renvoie `None` : les données de la brasserie ne sont pas chargées, script mongosh du dossier.

### J3-45 · `pause`
- Titre : Pause · Reprise : On reprend à 14:55. · Consigne : Ensuite : SQL Server. · Durée : 15'

---

## SQL Server depuis Python · 14:55 - 15:20

### J3-46 · `processus-5`
- Surtitre : SQL SERVER · AVANT PYTHON
- Titre : Un login du cours, pas votre compte sa
- Étapes : 1. Vérifier — le mode « SQL Server et Windows » · 2. Redémarrer — le service, si le mode a changé · 3. Exécuter — `fonderie.sql` dans SSMS · 4. Lire — le login `cours_python` : lecture, et une table d'essai · 5. Tester — la chaîne de connexion du `.env`
- Durée : 8 min (exécution comprise) · Source : 61 (mode d'authentification, redémarrage) ; 102 (`CREATE LOGIN … WITH PASSWORD`, politique de mot de passe par défaut) ; 103 (`CREATE USER … FOR LOGIN`) ; 104 (`db_datareader` : lecture de toutes les tables ; `ALTER ROLE … ADD MEMBER`)
- Oral : décision du formateur du 17/11 : un login dédié, pas `sa`. Repli si un poste résiste : authentification Windows, `Trusted_Connection=yes` dans la chaîne [À VÉRIFIER en salle : mot-clé accepté par mssql-python 1.18.0 d'après son code, pas d'exemple dans la documentation].

### J3-47 · `code`
- Surtitre : DÉMO · SQL SERVER
- Titre : Une requête paramétrée, jamais concaténée
- Fichier : src/ventes_sql.py
- Code :
  ```python
  import os
  from dotenv import load_dotenv
  from mssql_python import connect

  load_dotenv()
  conn = connect(os.getenv("SQL_CONNECTION_STRING"))
  cursor = conn.cursor()
  cursor.execute(
      "SELECT biere, SUM(quantite) AS total FROM ventes "
      "WHERE format = %(format)s GROUP BY biere",
      {"format": "fut"},
  )
  for ligne in cursor.fetchall():
      print(ligne.biere, ligne.total)
  cursor.close()
  conn.close()
  ```
- Résultat attendu (à exécuter en salle) : une ligne par bière, B01 272, B02 166, B03 140, B04 111, B05 207 (fûts de l'année, calculés sur le jeu de données de `fonderie.sql` ; l'ordre des lignes n'est pas garanti sans `ORDER BY`)
- Interaction : chacun exécute · Durée : 12 min
- Source : 97 (quickstart mssql-python : `connect`, `cursor`, paramètres `%(nom)s` passés en dictionnaire, ce qui protège de l'injection SQL ; `fetchall` ; accès aux colonnes par nom ; `close`) ; 105 (code de mssql-python 1.18.0 : une ligne `Row` s'utilise par indice ou par nom de colonne)
- Oral : le paramètre est un dictionnaire de vendredi. Jamais `"… WHERE client = '" + code + "'"` : c'est l'injection SQL, et c'est le premier bug de l'atelier de 15:45.

### J3-47b · `titre-seul` · schéma animé A14
- Surtitre : SCHÉMA
- Titre : Une valeur en paramètre ne devient jamais du SQL
- Visuel : schéma animé A14-requete-parametree (12 à 15 s), deux voies côte à côte. À gauche, concaténation : le stagiaire tape `C01' OR '1'='1` ; le texte se colle dans la requête et change son sens (toutes les lignes sortent, en rouge). À droite, paramètre : la même saisie voyage dans un dictionnaire, à part de la requête ; le serveur la compare comme une valeur : aucune ligne. Image fixe : les deux voies et leur résultat.
- Durée : 2 min · Source : 97 (le passage en paramètres protège de l'injection SQL) ; 106 (« Do not hardcode or concatenate parameters ») [À VÉRIFIER : la saisie piégée exacte et le résultat seront exécutés sur la base `Fonderie` en salle ou sur une base de test ; à défaut, l'animation montre le principe sans afficher un résultat chiffré]
- Oral : c'est le premier bug de l'atelier de 15:45.

### J3-48 · `quiz`
- Surtitre : PRÉDISEZ
- Titre : Une ligne de `fetchall()` ressemble à quoi ?
- A : Un dictionnaire · B : Une ligne qui s'utilise par indice et par nom de colonne · C : Une chaîne de texte · D : Un DataFrame
- Réponse : B
- Durée : 2 min · Source : 105 ; 97
- Oral : demain, ces lignes entrent dans pandas et deviennent un tableau.

---

## Écrire dans la base · 15:20 - 15:30

### J3-48b · `code`
- Surtitre : À VOUS · ÉCRIRE DANS LA BASE
- Titre : Une écriture devient définitive avec `commit()`
- Fichier : src/essai_commande.py
- Code :
  ```python
  import os
  from dotenv import load_dotenv
  from mssql_python import connect

  load_dotenv()
  conn = connect(os.getenv("SQL_CONNECTION_STRING"))
  cursor = conn.cursor()
  cursor.execute(
      "INSERT INTO essais_commandes (poste, biere, quantite) "
      "VALUES (%(poste)s, %(biere)s, %(quantite)s)",
      {"poste": "Poste 07", "biere": "B03", "quantite": 2},
  )
  conn.commit()
  cursor.close()
  conn.close()
  ```
- Résultat attendu (à exécuter en salle) : rien à l'écran ; la ligne apparaît dans `SELECT * FROM essais_commandes`. Puis chacun retire `conn.commit()`, insère une deuxième ligne et la cherche [effet constaté en salle sur la base `Fonderie` ; colonnes de `essais_commandes` à figer avec `fonderie.sql`]
- Interaction : chacun exécute, puis retire `commit()` et compare · Durée : 10 min
- Source : 109 (code de mssql-python 1.18.0 : `connect(…, autocommit=False)` par défaut, `Connection.commit`) ; 97 (paramètres `%(nom)s` en dictionnaire) ; 112 (`GRANT INSERT ON OBJECT::schéma.table`, pour le script `fonderie.sql`) ; 111 (`insert_one` dans pymongo 4.20.0)
- Oral : la connexion s'ouvre sans validation automatique : sans `commit()`, l'écriture n'est pas validée. Le login n'a le droit d'écrire que dans cette table d'essai, pas dans `ventes`. Même règle qu'en lecture : la valeur passe en paramètre. Côté MongoDB, l'équivalent est `collection.insert_one(document)`, avec un dictionnaire.

---

## Neo4j depuis Python · 15:30 - 15:45

### J3-49 · `code`
- Surtitre : DÉMO · NEO4J
- Titre : Cypher passe par `execute_query`, avec paramètres
- Fichier : src/livraisons_neo4j.py
- Code :
  ```python
  import os
  from dotenv import load_dotenv
  from neo4j import GraphDatabase

  load_dotenv()
  auth = (os.getenv("NEO4J_USER"), os.getenv("NEO4J_PASSWORD"))
  with GraphDatabase.driver(os.getenv("NEO4J_URI"), auth=auth) as driver:
      driver.verify_connectivity()
      records, summary, keys = driver.execute_query(
          "MATCH (c:Client {ville: $ville})<-[:LIVRE]-(l:Livraison) "
          "RETURN c.nom AS nom, count(l) AS livraisons",
          ville="Seraing", database_="neo4j",
      )
      for r in records:
          print(r["nom"], r["livraisons"])
  ```
- Résultat attendu (à exécuter en salle) : `Café du Pont 11` et `Taverne Saint-Jean 10` (livraisons d'octobre et novembre 2026 dans `fonderie.cypher` ; le Comité des fêtes d'Ougrée, à Seraing aussi, n'a pas de livraison sur ces deux mois)
- Interaction : chacun exécute · Durée : 12 min
- Source : 100 (`GraphDatabase.driver(URI, auth=…)`, `verify_connectivity`, `with`) ; 106 (manuel du pilote Python : `execute_query`, paramètres `$nom` passés en arguments nommés, « Do not hardcode or concatenate parameters », `database_`, `records, summary, keys`) ; enregistrement lu par clé : constaté sur neo4j 6.4.1 installé (`r["nom"]`) [modèle `Client`, `Livraison`, `LIVRE` à figer avec le script Cypher]
- Oral : la même règle que SQL : la valeur passe en paramètre. Point de décision : si l'heure est dépassée, démonstration seule, exercice en bonus.

---

## Atelier · le code généré par IA · 15:45 - 16:15

### J3-50 · `exercice`
- Surtitre : CHASSE AUX BUGS 4
- Titre : Le script de l'IA marche, et il est dangereux
- Durée : 30 min · Niveau : Intermédiaire · Format : Binômes · Livrable : ventes_client.py corrigé
- Consigne : Un stagiaire a demandé à une IA un script qui affiche les ventes d'un client. Il marche. · Trouvez les quatre problèmes et corrigez-les avec ce que vous avez vu aujourd'hui. · Écrivez, pour chacun, la règle en une phrase.
- Encart · Indice : Cherchez un mot de passe, un `+` dans une requête, une connexion jamais fermée, un `except` qui ne dit rien.
- Bugs prévus : mot de passe en dur dans la chaîne de connexion ; requête construite par concaténation avec `input()` ; connexion jamais fermée ; `except: pass` qui cache l'erreur de connexion
- Source : 96, 97, 90 ; script à écrire avec les ateliers (il doit tourner sur la base `Fonderie`)
- Oral : la question n'est pas « faut-il utiliser l'IA », c'est « qui relit ». De 16:05 à 16:15 : mise en commun des quatre règles.

---

## Marge · 16:15 - 16:30

### J3-51 · `titre-seul`
- Surtitre : MARGE
- Titre : Les connexions qui résistent, puis les bonus
- Interaction : le formateur passe sur les postes dont une connexion échoue ; les autres : finir Neo4j, séries 7 et 8, exercice 8.4
- Durée : 15 min

---

## Clôture · 16:30 - 17:00

### J3-52 · `a-retenir`
- Surtitre : À RETENIR
- Titre : Trois idées à garder de ce mardi
- 1. Une fonction renvoie ; afficher n'est pas renvoyer.
- 2. `try` attrape l'erreur attendue ; le métier se vérifie à part.
- 3. Un secret vit dans `.env`, jamais dans le code.
- Durée : 3 min

### J3-53 à J3-57 · `quiz` · QUIZ · QUESTIONS 1 À 5
- Q1 · Que renvoie une fonction sans `return` ? A : 0 · B : Une chaîne vide · C : Une erreur · D : None — Réponse : D (67)
- Q2 · `csv.reader` lit `12`. Quel est son type ? A : str · B : int · C : float · D : Cela dépend du fichier — Réponse : A (89)
- Q3 · Où écrire le mot de passe de votre base ? A : Dans le code, en commentaire · B : Dans `.env`, ignoré par Git · C : Dans `requirements.txt` · D : Dans le `README` — Réponse : B (96)
- Q4 · Que fait `python -m pip freeze > requirements.txt` ? A : Il installe les paquets · B : Il supprime le venv · C : Il écrit la liste des paquets installés · D : Il met pandas à jour — Réponse : C (92)
- Q5 · Pourquoi passer une valeur en paramètre plutôt que par `+` dans la requête ? A : Pour éviter l'injection SQL · B : Pour aller plus vite · C : Parce que `+` est interdit en Python · D : Pour trier les résultats — Réponse : A (97, 106)
- Durée : 10 min au total · Interaction : anonyme, sur papier ou formulaire (comme les jours 1 et 2)

### J3-58 · `texte-encart`
- Surtitre : POUR DEMAIN
- Titre : Vos connexions doivent marcher demain matin
- Texte : Demain, vos ventes passent de SQL Server à pandas. Ce soir, relancez `ventes_sql.py` : il doit afficher une ligne par bière.
- Encart · titre : Si ça coince · texte : Notez le message d'erreur complet, sans le mot de passe : on le lit ensemble à 8:30.
- Durée : 2 min

### J3-58b · `exercice`
- Surtitre : POUR DEMAIN · LE CHAMPIONNAT DES ROBOTS
- Titre : Votre premier robot monte sur le ring demain
- Durée : 5 min de présentation · Niveau : Débutant · Format : Seul (chacun inscrit son robot) · Livrable : mon_robot.py
- Consigne : Deux robots s'affrontent en temps réel sur le ring du hall de la brasserie : garde haute, garde basse, direct, crochet, coup bas, projection, esquive, coup spécial. · Votre robot est une fonction : `strategie(etat)` reçoit un dictionnaire et renvoie une action, par exemple `"direct"` ou `"garde"`. · Testez-le contre les six robots d'entraînement avec `python combat.py mur`, puis revoyez le combat en 3D (fichier `combat.json`, onglet Revoir de l'arène).
- Encart · Indice : Aucune garde n'arrête tout : regardez ce que prépare l'adversaire, `etat["adversaire"]["action"]`.
- Source : `04-ateliers/jeux/09-championnat-robots.md` (règles du 22/11 : onze actions, deux gardes) ; dossier remis aux stagiaires : `04-ateliers/jeux/championnat/championnat-depart.zip`. Le robot de départ (direct au contact, sinon avancer) gagne 6 combats sur 12 contre les robots d'entraînement (mesuré le 22/11).
- Oral : la manche 1 ouvre la journée de demain, projetée en 3D. Ceux qui ont fini dans la marge de 16:15 peuvent commencer tout de suite. Ce robot est la première de trois générations : jeudi, la machine apprendra à jouer à leur place (un arbre de décision, puis un réseau de neurones qui apprend en combattant).

### J3-59 · `fin`
- Surtitre : FIN DU JOUR 3
- Titre du feedback : Votre avis en deux minutes
- Texte : Scannez le code : environ deux minutes, réponses confidentielles.
- Visuel : QR code du questionnaire CourseFlow du jour 3 [À VÉRIFIER : lien et QR code à fournir par le formateur]
- Suite : Analyser avec pandas · Date : Jour 4 · mercredi 25 novembre 2026, 8h30 · Contact : Pierre Juif
- Durée : 15 min (avis compris)

---

## Réserve (hors déroulé)

### J3-R1 · `code-resultat`
- Surtitre : EN AVANCE · FINALLY
- Titre : `finally` s'exécute dans tous les cas
- Code : `def lire_quantite(texte):` / `    try:` / `        return int(texte)` / `    except ValueError:` / `        return 0` / `    finally:` / `        print("ligne lue :", texte)` puis `print(lire_quantite("4"))` et `print(lire_quantite("12 kg"))`
- Résultat : `ligne lue : 4` / `4` / `ligne lue : 12 kg` / `0`
- Source : 90 (`finally` juste avant le `return`) ; exécuté
- Oral : diapositive masquée ; utile pour les développeurs. Un `return` dans `finally` est déconseillé (avertissement depuis 3.14, 90).

### J3-R2 · `code-resultat`
- Surtitre : EN AVANCE · PANDAS
- Titre : Le même fichier, en une ligne de pandas
- Code : `import pandas as pd` / `commandes = pd.read_csv("data/commandes.csv", sep=";")` / `print(commandes.head())`
- Source : 52 [à exécuter avec le fichier final]
- Oral : pour ceux qui veulent voir demain aujourd'hui.

### J3-R3 · `terminal`
- Surtitre : PLAN B · ACTIVATION
- Titre : Activer le venv dans PowerShell, si nécessaire
- Commandes : `.venv\Scripts\Activate.ps1` ; si refusé : `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`
- Source : 93
- Oral : seulement si un outil exige un venv activé ; changer la politique d'exécution touche le compte du stagiaire : à faire avec l'accord de l'IT.

---

## Visuels à produire

| Diapositive | Visuel | Quand |
|---|---|---|
| J3-21 | Capture de `commandes.csv` ouvert dans VS Code | Avec les ateliers |
| J3-38 | Arborescence du projet (texte dans la diapositive, pas d'image) | — |
| J3-07b, J3-13b, J3-25b, J3-40b, J3-47b | Schémas animés A11, A12, A13, A02, A14 (`03-supports/animations/`) | Avec les diapositives du J3 |
| J3-59 | QR code CourseFlow du jour 3 | Dès réception du lien |

## À vérifier avant production

- J3-29 : fait le 20/11.
- J3-20 : convention `import pandas as pd`, à citer depuis la documentation de pandas.
- J3-30 : sans objet (bug remplacé le 20/11).
- J3-35 : accès à PyPI depuis la salle (test à faire le jeudi 19/11 sur un poste stagiaire).
- J3-46 : `Trusted_Connection=yes` avec mssql-python, en salle.
- J3-44, J3-47, J3-49 : à exécuter une fois sur une machine avec les trois bases chargées (scripts du dossier `04-ateliers/J3/donnees/`).
- J3-59 : QR code CourseFlow du jour 3.

## Temps

Matin : ouverture 15 · chapitre 7 : 25 · série 7 : 15 · exercices 7 : 25 · signature : 10 · chapitre 8 : 20 · pause 15 · try / except : 15 · série 8 : 15 · exercices 8 et chasse aux bugs 3 : 35 · marge 50. Total : 240 minutes.
Après-midi : venv 25 · architecture 15 · variables d'environnement 20 · MongoDB 10 · pause 15 · SQL Server 25 · écrire dans la base 10 · Neo4j 15 · atelier IA 30 · marge 15 · clôture 30. Total : 210 minutes.
