# Fil rouge — la Brasserie de la Fonderie

> Fiche du fil rouge, figée le 17/11/2026 pour le jour 1. **Toutes les données sont fictives** (noms, prix, clients, températures) : elles servent aux exercices, aux missions des jeux et au jeu de données des jours 3 et 4. Ne pas les présenter comme des prix ou des pratiques réelles du secteur.
> Nom vérifié le 17/11/2026 par recherche web : aucune brasserie de ce nom trouvée (seuls un bar-restaurant « La Fonderie » à Ernée, en France, et le musée La Fonderie à Molenbeek sont ressortis). Les noms en « Forge » sont déjà pris par de vraies brasseries : à éviter. Ne pas utiliser non plus la « Brasserie du Sart », citée dans les exemples du modèle de diapositives.

## 1. L'histoire en trois phrases (pour l'ouverture du jour 1)

La Brasserie de la Fonderie est une microbrasserie installée dans une ancienne fonderie de la région liégeoise. Elle brasse cinq bières, livre des cafés, des magasins, des particuliers et des événements, et tout son suivi tient aujourd'hui dans des fichiers Excel recopiés à la main. Pendant quatre jours, les stagiaires écrivent en Python les petits programmes qui automatisent ce suivi : prix des commandes, étiquettes, préparation des livraisons, stock, fichier des ventes.

## 2. Les bières

Les noms rappellent le vocabulaire de la sidérurgie (coulée, laitier, braise, crassier, étincelle).

| Code | Nom | Style | Alcool (% vol.) | Couleur dans les jeux |
|---|---|---|---|---|
| B01 | La Coulée | Blonde | 6,5 | `sun` |
| B02 | Le Laitier | Blanche | 5,0 | `cream` |
| B03 | La Braise | Ambrée | 7,0 | `coral` |
| B04 | Le Crassier | Brune | 8,0 | `ink` |
| B05 | L'Étincelle | IPA | 5,5 | `mint` |

## 3. Formats et prix (fictifs, hors TVA)

| Format | Contenu |
|---|---|
| Bouteille | 33 cl |
| Casier | 24 bouteilles de 33 cl |
| Fût | 20 litres |

| Code | Bière | Prix d'un casier (€) | Prix d'un fût (€) |
|---|---|---|---|
| B01 | La Coulée | 28,80 | 62,00 |
| B02 | Le Laitier | 26,40 | 58,00 |
| B03 | La Braise | 31,20 | 68,00 |
| B04 | Le Crassier | 33,60 | 72,00 |
| B05 | L'Étincelle | 30,00 | 66,00 |

Consignes (fictives) : 3,00 € par casier, 30,00 € par fût.
Les prix sont **hors TVA** : la TVA n'est pas utilisée dans les exercices tant que son taux n'est pas sourcé.

## 4. Les clients

| Code | Nom | Type | Ville |
|---|---|---|---|
| C01 | Café du Pont | café | Seraing |
| C02 | Le Comptoir des Hauts-Fourneaux | café | Liège |
| C03 | Taverne Saint-Jean | café | Seraing |
| C04 | Épicerie Vrac & Fils | magasin | Liège |
| C05 | Cave aux Bulles | magasin | Herstal |
| C06 | Marie Dumont | particulier | Flémalle |
| C07 | Comité des fêtes d'Ougrée | événement | Seraing |
| C08 | Lucas Bertrand | particulier | Liège |

Les noms de personnes et de commerces sont inventés ; toute ressemblance est fortuite. Les villes sont réelles et servent seulement à situer les livraisons.

Remises (fictives, utilisées à partir du jour 2, conditions) :
- café : 10 % sur les fûts ;
- magasin : 2 % sur les casiers à partir de 5 casiers, 5 % à partir de 10 casiers (palier de 2 % ajouté le 17/11/2026 pour le piège de l'ordre des `elif`, jour 2) ;
- particulier : pas de remise ;
- événement : un fût offert pour 10 fûts commandés.

## 5. L'entrepôt (décor des jeux)

| Quai | Destination |
|---|---|
| Q1 | Cafés |
| Q2 | Magasins |
| Q3 | Particuliers |
| Q4 | Événements |
| R | Rebut (casier abîmé, commande invalide) |

- Chariot du préparateur : 4 fûts ou 6 casiers au plus par tournée.
- Cuves de fermentation : 4 cuves (C1 à C4) ; plage de température fixée par le brasseur de la Fonderie : 18 à 22 °C (valeur fictive pour les exercices, ce n'est pas une recommandation de brassage).

## 6. Stock de départ (lundi matin)

| Code | Bière | Casiers | Fûts |
|---|---|---|---|
| B01 | La Coulée | 40 | 12 |
| B02 | Le Laitier | 25 | 6 |
| B03 | La Braise | 18 | 8 |
| B04 | Le Crassier | 9 | 4 |
| B05 | L'Étincelle | 30 | 10 |

Seuil d'alerte de stock bas : 10 casiers ou 3 fûts.

## 7. Données utilisées par jour

| Jour | Données |
|---|---|
| J1 | Prix d'un casier, contenance d'un fût et d'une bouteille, nom et degré d'une bière, devis d'une commande, étiquette d'un fût saisie à la main, bon de livraison |
| J2 | Commandes du jour (listes), quais et remises (conditions), tournée du chariot et températures des cuves (boucles), stock par bière (dictionnaires), clients livrés (sets) |
| J3 | Facturation (fonctions), fichier des commandes `commandes.csv` avec des lignes sales (fichiers et erreurs), les mêmes données dans SQL Server, MongoDB et Neo4j |
| J4 | Fichier des ventes du mois `ventes.csv` (pandas), journaux du championnat des robots (remplace le sumo le 21/11) |

Fichiers CSV à construire avant le jour 3 (avec des erreurs volontaires documentées : poids saisi « 12 kg », client inconnu, quantité négative, date impossible).
