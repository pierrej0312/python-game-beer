# Inventaire des notions — Python de base

> Statut : proposition du 17/11/2026, à valider par le formateur, puis à transmettre au planificateur (`02-plan.md`).
> Sources de l'inventaire : table des matières de l'ancien support « Python - Base (Bstorm) » (rappelée par le formateur), demande du formateur sur la théorie d'introduction (`proposition-theorie-intro.md`), suite du parcours (notebooks Fabric en janvier, pandas / Polars et scikit-learn en mars).
> Priorités : **I** = indispensable, **U** = utile, **B** = bonus pour les rapides, **H** = hors périmètre (bibliothèque).
> Le temps disponible prime (4 jours, groupe hétérogène) : ce qui ne tient pas passe en bonus ou en bibliothèque. Aucune affirmation technique de ce fichier n'entre dans un support sans être sourcée dans la documentation officielle de Python.

## 1. Notions de l'ancien support (toutes reprises)

| Notion | Détail | Priorité | Jour proposé | Série du jeu 1 | Remarque |
|---|---|---|---|---|---|
| Variables | Nom, valeur, type ; règles de nommage (`snake_case`) ; mots réservés | I | J1 | 1 | Ancien support : « 33 mots réservés » et type `unicode` à revérifier (Python 2) |
| Types de base | `int`, `float`, `str`, `bool`, `None` ; `type()` | I | J1 | 1 | |
| Conversions | `int()`, `float()`, `str()`, `bool()` | I | J1 | 1 | |
| Interaction avec la console | `print()` (séparateur, fin de ligne), `input()` (renvoie toujours du texte) | I | J1 | 1 (affichage seulement) | `input()` ne se joue pas dans le jeu : exercices dans VS Code |
| Opérateurs arithmétiques | `+ - * / // % **` | I | J1 | 1 | `**` absent de l'ancien support |
| Opérateurs de comparaison | `== != < <= > >=` ; `in` ; `is` | I | J1-J2 | 3 | Ancienne définition de `is` à corriger (identité, pas contenu) |
| Opérateurs logiques | `and`, `or`, `not` | I | J2 | 3 | |
| Affectation combinée | `+=`, `-=`, `*=`… ; affectation multiple | I | J1 | 1 | |
| Structure conditionnelle | `if`, `elif`, `else` | I | J2 | 3 | |
| Boucle `while` | Condition de sortie, boucle infinie | I | J2 | 5 | Absente des notebooks de machine learning analysés (§ 7) : notion de base gardée, mais une seule mission |
| Boucle `for` | Sur une collection, `range()`, `enumerate()` | I | J2 | 5 | |
| Collection `list` | Création, indices (y compris négatifs), tranches, `append`, `insert`, `remove`, `pop`, `len`, `in`, tri | I | J2 | 4 | |
| Collection `tuple` | Non modifiable ; décomposition (`a, b = ...`) ; retour multiple d'une fonction | I | J2-J3 | 4 et 7 | |
| Collection `dict` | Clé / valeur, ajout, modification, `get`, `keys`, `values`, `items`, parcours | I | J3 | 6 | Ancien support : dictionnaire « non ordonné » à revérifier (ordre d'insertion conservé dans les versions récentes) |
| Collection `set` | Sans doublon, appartenance, union / intersection / différence | U | J3 | 6 | Utile pour dédoublonner des données |
| Tableau comparatif des collections | Ordonnée, modifiable, doublons, accès | I | J3 | | Repris de l'ancien support, corrigé et sourcé |
| Fonctions (« méthodes » dans l'ancien support) | `def`, paramètres, `return`, procédure / fonction, portée locale / globale, `global` déconseillé | I | J3 | 7 | Ancien support : « paramètres copiés » à corriger (passage de références, effet sur les listes) |
| Gestion des erreurs | `try`, `except` (spécialisés, multiples), `else`, `finally` | I | J3 | 8 | |

## 2. Notions absentes de l'ancien support, proposées

| Notion | Pourquoi | Priorité | Jour proposé | Série du jeu 1 |
|---|---|---|---|---|
| Chaînes de caractères : indices et tranches, méthodes (`upper`, `lower`, `strip`, `split`, `replace`, `startswith`), f-strings | Nettoyer des données texte est le quotidien d'un data analyst ; les f-strings remplacent les concaténations | I | J1-J2 | 2 |
| Valeurs « vraies » et « fausses » (liste vide, `0`, `None`, chaîne vide) | Comprendre les conditions courtes et éviter des bugs | U | J2 | 3 |
| `zip()`, `sorted()` avec `key`, `min`, `max`, `sum` | Opérations de base sur des données | U | J2-J3 | 5 et 6 |
| Copie et référence (mutable / non modifiable) | Le bug « j'ai modifié ma liste sans le vouloir » ; corrige l'erreur de l'ancien support | I | J3 | 7 (test caché) |
| Paramètres par défaut, arguments nommés, docstring | Lire la documentation de pandas et de scikit-learn, où tout est argument nommé | I | J3 | 7 |
| Méthodes d'un objet (`texte.upper()`, `liste.append()`) : la notation pointée | Lire `df.groupby(...).sum()` en mars ; sans faire de programmation orientée objet | I | J2-J3 | 2 et 4 |
| Modules et `import`, alias (`import pandas as pd`) ; bibliothèque standard (`math`, `random`, `datetime`, `csv`, `pathlib`) | Base de tout projet ; prépare `import pandas as pd` | I | J3-J4 | 8 |
| Lire et écrire un fichier : `with open(...)`, module `csv` | Le CSV des ventes du fil rouge | I | J3-J4 | 8 |
| Dates avec `datetime` | Données datées (commandes, ventes) | U | J3-J4 | 8 (mission bonus : dates de livraison) |
| Compréhensions de liste | Code compact, très présent dans les exemples en ligne | U | J3 | 5 (bonus) |
| `lambda` (pour `sorted(key=...)`) | Prépare `apply` en pandas | B | J4 | |
| Lire un message d'erreur (traceback) | Premier réflexe avant d'appeler le formateur | I | J1, puis tout le cours | Panneau d'erreur du jeu |
| Débogueur de VS Code (point d'arrêt, pas à pas) | Comprendre ce que fait le code ; même idée que le rejeu pas à pas du jeu | U | J2 | Pas à pas du jeu, puis VS Code |
| Bonnes pratiques : noms parlants, commentaires, PEP 8 (survol) | Code lisible par les collègues | U | Tout le cours | |
| Annotations de type (lecture seulement) | Les comprendre quand on les rencontre dans la documentation | B | J4 | |
| Venv, `pip`, dépendances, architecture d'un projet | Voir `proposition-theorie-intro.md`, séquences 7 et 8 | I | J4 | |
| Pont vers pandas (le même CSV, à la main puis avec pandas) | Préparer la suite du parcours | I | J4 | |
| Lire un appel matplotlib simple (`plt.plot`, `plt.show`) | Très présent dans les notebooks de machine learning (§ 7) ; lecture, pas cours de visualisation | U | J4 | |
| Coder avec un assistant IA | Ce qu'on lui demande, ce qu'on vérifie | U | J4 | |

## 3. Hors périmètre proposé (vers la bibliothèque)

| Sujet | Raison | Où il revient |
|---|---|---|
| Programmation orientée objet (classes, héritage, encapsulation) | Trop poussé pour 4 jours ; pas nécessaire pour utiliser pandas et scikit-learn | Supports [Dev] Python (orienté objet) |
| Flask, API, déploiement | Hors parcours data analyst | Supports [Dev] Python (`secu_test_deploy`) |
| Générateurs, décorateurs, programmation asynchrone | Trop avancé | |
| NumPy, pandas en profondeur, visualisation | Cours suivants du parcours | Bloc IA accélératrice (mars), notebooks Fabric (janvier) |

## 4. Point d'attention : le volume

L'inventaire complet (I + U) dépasse probablement 4 jours pour un groupe hétérogène. Le planificateur devra :
- garder toutes les notions I dans le tronc commun ;
- placer les U en exercices courts ou en bonus selon le temps ;
- réserver les B aux rapides (étoiles 3 du jeu, exercices bonus) ;
- prévoir une marge pour les imprévus (installation, incompréhensions), comme le demande le cadrage.

## 5. Couverture des notions par les jeux (vérifiée le 17/11/2026)

| Notion (priorité I) | Jeu 1 (missions) | Jeu 3 (sumo, remplacé le 21/11 par le championnat des robots) | Ailleurs |
|---|---|---|---|
| Variables, types, conversions, opérateurs arithmétiques | Série 1 | | |
| `print` | Série 1 (onglet Sortie) | | |
| `input()` | Non (pas de console interactive) | | Exercices VS Code, J1 |
| Chaînes, f-strings, notation pointée | Série 2 | | |
| Comparaison, logique, `if` / `elif` / `else` | Série 3 | Cœur de toute stratégie | |
| Listes, tuples, décomposition | Série 4 | `historique` (liste de tuples) | |
| `for`, `while`, `range`, `enumerate`, `zip` | Série 5 | Bonus « le robot qui apprend » (parcours des journaux) | |
| Dictionnaires, `set` | Série 6 | `etat` est un dictionnaire | |
| Fonctions, arguments nommés, copie et référence | Série 7 | `strategie(etat)` | |
| Fichiers, `csv`, `try` / `except`, `import` | Série 8 | Journaux CSV du tournoi (J4) | |
| Lire un traceback | Panneau d'erreur de toutes les missions | Erreurs de stratégie notées dans le journal | |
| Venv, `pip`, architecture d'un projet | Non | | Théorie J4 (séquences 7 et 8), démo |
| Pont vers pandas | Non | Analyse des journaux CSV (J4) | |

Notions sans jeu, à travailler dans VS Code : `input()`, débogueur, venv et `pip`. Le builder (version 2) couvrira plus tard la logique avant la syntaxe au jour 1 ; pour cette session, le jour 1 n'a pas de jeu.

## 6. Ordre des chapitres et des jeux

L'ordre des séries du jeu 1 **est** l'ordre des chapitres du cours : une seule progression. Ordre retenu (17/11/2026) :

1. Variables, types, opérateurs, affichage
2. Chaînes de caractères
3. Conditions
4. Listes et tuples
5. Boucles
6. Dictionnaires et sets
7. Fonctions
8. Fichiers et erreurs

Conditions avant listes, comme dans l'ancien support : une décision simple ne demande pas de collection, et les boucles arrivent juste après les listes qu'elles parcourent. Si le plan change cet ordre, les séries du jeu changent avec lui (`03-jeu1-missions.md` § 11 et § 13).

## 7. Ce que les cours de machine learning attendent (analyse du 17/11/2026)

Analyse automatique des 57 notebooks de `01-notes/anciens-cours/autres-formateurs/[AI - DataScience]/08_sklearn_ml_datamining/` (théorie et exercices scikit-learn ; 1 408 cellules de code, environ 9 250 lignes). Ces notebooks viennent d'un autre formateur : rien ne garantit que le cours de machine learning de mars (Romain Bernard) les utilise, mais ils montrent le Python réellement écrit dans un cours de ce type.

| Construction Python | Occurrences | Conséquence pour ce cours |
|---|---|---|
| Arguments nommés dans les appels (`f(x, test_size=0.2)`) | environ 1 320 | Indispensable, et à lire dans une signature de fonction |
| `import` / `from ... import` | 430 | Indispensable, avec les alias (`as`) |
| Appels chaînés (`df.dropna().head()`) | environ 250 | Notation pointée indispensable |
| Modules les plus importés | seaborn, pandas, numpy, matplotlib, puis scikit-learn | Le pont du jour 4 vers pandas est justifié ; matplotlib en lecture |
| `print(` | 214 | Indispensable |
| Dictionnaires écrits en littéral (`{"cle": valeur}`) | 154 | Indispensable (paramètres de modèles) |
| Boucles `for` | 144 | Indispensable |
| `def` | 91 | Fonctions indispensables |
| f-strings | 77 | Indispensables |
| `if` / `elif` | 72 | Indispensables |
| Tranches `[a:b]` | 39 | Indispensables |
| `enumerate(` | 38 | Indispensable |
| Décomposition de tuple (`X_train, X_test = ...`) | 34 | Indispensable : c'est la forme de nombreux retours de fonctions |
| `try` / `except` | 14 | Indispensable |
| `with open` | 13 | Indispensable |
| Compréhensions de liste | 13 | Passées de bonus à utile |
| `range(` | 11 | Indispensable |
| `set(` | 11 | Utile |
| `lambda` | 1 | Bonus confirmé |
| `while` | 0 | Gardée comme notion de base, une seule mission |
| `zip(` | 0 | Utile, sans plus |
| `class` | 0 | Hors périmètre confirmé |
| `global` | 0 | À déconseiller, comme dans l'ancien support |

Comptage par expressions régulières : ordre de grandeur, pas une mesure exacte.

## 8. Ajouts du 17/11/2026 (jour 4, demande du formateur)

| Notion | Pourquoi | Priorité | Jour |
|---|---|---|---|
| Variables d'environnement (`os.environ`, `os.getenv`), fichier `.env`, python-dotenv, `.gitignore` | Ne jamais écrire un mot de passe dans le code ; les stagiaires l'ont fait avec du code généré par IA à l'atelier SQL + NoSQL | I | J3 |
| Connexion à SQL Server (`mssql-python`), requête paramétrée, résultats en tuples, fermeture | Relier Python aux bases vues en formation | I | J3 |
| Connexion à MongoDB (`pymongo`) et Neo4j (`neo4j`) | Idem ; les résultats arrivent en dictionnaires et en enregistrements | I | J3 |
| Relire et corriger un code généré par IA | Les stagiaires ont utilisé du code généré sans le comprendre | I | J3 |
| Premier modèle scikit-learn : entraînement / test, `fit`, `predict`, erreur | Machine learning « facile », prévision des ventes de fûts | U | J4 |
| Réseau de neurones en facile : neurone (entrées, poids, somme, activation), couches, apprentissage = ajustement des poids ; démonstration dans Neural Network Playground | Sujet qui intéresse vraiment le groupe (formateur) ; lien avec leur module d'IA générative | U | J4 |
| `MLPRegressor` de scikit-learn dans un pipeline avec `StandardScaler`, comparé à la régression sur les mêmes ventes de fûts | Montrer qu'un réseau de neurones s'entraîne avec les mêmes `fit` / `predict`, et qu'il n'est pas magique | U | J4 |
| Interfaces graphiques ou web, visualisation de graphes Neo4j, recherche vectorielle depuis Python | Demandé par des stagiaires, mais hors du temps disponible | H | Bibliothèque |
| Frameworks de deep learning (PyTorch, Keras, TensorFlow), GPU | Installation lourde sur des postes sans droits ; scikit-learn suffit pour une première approche | H | Bibliothèque |

Réorganisation du 17/11/2026 : variables, opérateurs, conditions et boucles iront vite (procédural déjà pratiqué en SQL et en MongoDB, selon le formateur). Chapitres 3 à 6 au J2 (dictionnaires avancés), chapitres 7 et 8 puis bases de données au J3, pandas, machine learning et réseaux de neurones au J4. Détail : `03-supports/storyboard-macro.md`.
