"""Corrigé du robot 2 (notebook robot2_arbre.ipynb, décisions tenues comptées une fois, max_depth=4, random_state=0).

Les règles de ce robot ne sont pas écrites à l'intuition : elles viennent d'un arbre de décision entraîné sur les
décisions qui ont mené à la victoire, celles des robots d'entraînement et celles des joueurs de la classe
(notebook robot2_arbre.ipynb, export_text). Recopiez l'arbre en if / elif. Il parle avec les nombres calculés au début.
"""
import regles


def strategie(etat):
    adv = etat["adversaire"]
    distance = etat["distance"]
    vie_moi, vie_adversaire = etat["moi"]["vie"], adv["vie"]
    energie_moi, energie_adversaire = etat["moi"]["energie"], adv["energie"]
    bord_moi, bord_adversaire = etat["moi"]["bord_derriere"], adv["bord_derriere"]
    adv_prepare = 1 if adv["phase"] == "preparation" else 0
    adv_frappe = 1 if adv["phase"] == "frappe" else 0
    adv_recupere = 1 if adv["phase"] == "recuperation" else 0
    adv_garde = 1 if adv["phase"] == "garde" else 0
    adv_garde_basse = 1 if adv["phase"] == "garde_basse" else 0
    adv_sonne = 1 if adv["phase"] == "sonne" else 0
    adv_reste = adv["reste"]
    # le coup que l'adversaire prépare, frappe ou finit : 1 pour ce coup, 0 pour les autres
    adv_direct = 1 if adv["action"] == "direct" else 0
    adv_crochet = 1 if adv["action"] == "crochet" else 0
    adv_coup_bas = 1 if adv["action"] == "coup_bas" else 0
    adv_projection = 1 if adv["action"] == "projection" else 0
    adv_special = 1 if adv["action"] == "special" else 0

    # Recopiez ici les règles de l'arbre. Une ligne « |--- distance <= 150.00 » devient « if distance <= 150.00: »,
    # la ligne « class: direct » en dessous devient « action = "direct" ».
    if distance <= 172.00:
        if adv_recupere <= 0.50:
            if adv_prepare <= 0.50:
                if bord_moi <= 52.00:
                    action = "garde"
                else:
                    action = "garde"
            else:
                if bord_moi <= 62.00:
                    action = "esquive"
                else:
                    action = "garde_basse"
        else:
            if distance <= 162.00:
                if energie_moi <= 7.50:
                    action = "garde"
                else:
                    action = "direct"
            else:
                if adv_reste <= 3.50:
                    action = "garde"
                else:
                    action = "garde"
    else:
        if bord_adversaire <= 557.50:
            if vie_adversaire <= 86.00:
                if adv_frappe <= 0.50:
                    action = "avancer"
                else:
                    action = "avancer"
            else:
                if distance <= 257.50:
                    action = "avancer"
                else:
                    action = "avancer"
        else:
            if distance <= 221.50:
                if distance <= 179.50:
                    action = "garde"
                else:
                    action = "garde"
            else:
                if bord_moi <= 27.50:
                    action = "avancer"
                else:
                    action = "avancer"

    # sécurité : une action trop chère est refusée, et le robot perdrait l'instant
    cout = regles.COUPS[action]["energie"] if action in regles.COUPS else regles.ESQUIVE["energie"] if action == "esquive" else 0
    if cout > energie_moi:
        action = "garde"
    return action
