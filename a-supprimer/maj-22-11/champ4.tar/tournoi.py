"""Le tournoi, sur le poste du formateur : chaque robot rencontre tous les autres, deux combats par rencontre (côtés inversés).

    python tournoi.py robots/                    les fichiers robots/*.py (un par stagiaire, nommé d'après son prénom ou son pseudo)
    python tournoi.py robots/ --entrainement     ajoute les six robots d'entraînement
    python tournoi.py robots/ --journal manche1.csv

Victoire : 3 points ; égalité : 1. Un fichier qui ne se charge pas est écarté et signalé.
La page Tournoi du jeu en ligne fait la même chose, avec le rejeu en 3D.
"""
import sys
from itertools import combinations
from pathlib import Path

from combat import charger
from moteur import combattre, ecrire_journal
from robots_entrainement import adversaires


def robots(dossier, entrainement):
    trouves = {n: (lambda n=n: adversaires()[n]) for n in adversaires()} if entrainement else {}
    for f in sorted(Path(dossier).glob("*.py")):
        try:
            s = charger(f)
            trouves[f.stem] = lambda s=s: s
        except (Exception, SystemExit) as e:
            print(f"Écarté : {f.name} ({type(e).__name__} : {e})")
    return trouves


def jouer(trouves):
    points = {n: {"points": 0, "v": 0, "n": 0, "d": 0} for n in trouves}
    journal = []
    for na, nb in combinations(trouves, 2):
        for a, b in ((na, nb), (nb, na)):
            r = combattre(trouves[a](), trouves[b](), a, b)
            journal += r["journal"]
            if r["vainqueur"] == "egalite":
                for n in (a, b):
                    points[n]["points"] += 1
                    points[n]["n"] += 1
            else:
                g, p = (a, b) if r["vainqueur"] == "a" else (b, a)
                points[g]["points"] += 3
                points[g]["v"] += 1
                points[p]["d"] += 1
    return points, journal


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    trouves = robots(sys.argv[1], "--entrainement" in sys.argv)
    points, journal = jouer(trouves)
    print(f"{'rang':<5}{'robot':<20}{'points':>7}{'V':>4}{'N':>4}{'D':>4}")
    for rang, (n, p) in enumerate(sorted(points.items(), key=lambda x: (-x[1]["points"], -x[1]["v"])), start=1):
        print(f"{rang:<5}{n:<20}{p['points']:>7}{p['v']:>4}{p['n']:>4}{p['d']:>4}")
    if "--journal" in sys.argv:
        chemin = sys.argv[sys.argv.index("--journal") + 1]
        ecrire_journal(journal, chemin)
        print(f"Journal de {len(journal)} instants enregistré : {chemin}")
