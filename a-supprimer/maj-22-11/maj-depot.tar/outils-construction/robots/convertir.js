// Conversion FBX (Mixamo) → glTF binaire (.glb), dans le navigateur, avec les outils de three.js (FBXLoader, GLTFExporter).
// Appelée par faire_robots.py. Les FBX bruts ne sont jamais publiés : seuls les .glb produits vont dans le site.
import * as THREE from "three";
import { FBXLoader } from "./three/loaders/FBXLoader.js";
import { GLTFExporter } from "./three/exporters/GLTFExporter.js";

const fbx = new FBXLoader();
const exporteur = new GLTFExporter();
const enBase64 = (tampon) => { const o = new Uint8Array(tampon); let s = ""; for (let i = 0; i < o.length; i += 0x8000) s += String.fromCharCode(...o.subarray(i, i + 0x8000)); return btoa(s); };
const exporter = (objet, animations = []) => exporteur.parseAsync(objet, { binary: true, animations, onlyVisible: false });
const trouver = (racine, motif) => { let r = null; racine.traverse((o) => { if (!r && o.isBone && motif.test(o.name)) r = o; }); return r; };

// Un robot : le modèle et son squelette, sans animation (les animations viennent du jeu partagé).
window.robotGLB = async (url) => {
  const objet = await fbx.loadAsync(url);
  objet.animations = [];
  let maillages = 0, os = 0, textures = 0;
  objet.traverse((o) => {
    if (o.isMesh) { maillages++; for (const m of [].concat(o.material)) if (m && m.map) textures++; }
    if (o.isBone) os++;
  });
  const boite = new THREE.Box3().setFromObject(objet);
  const glb = await exporter(objet);
  return { glb: enBase64(glb), maillages, os, textures, hauteur: boite.getSize(new THREE.Vector3()).y, hanches: trouver(objet, /hips/i)?.name || null };
};

// Le jeu d'animations : le squelette du premier fichier et toutes les animations, chacune renommée comme son fichier.
// Pour chaque animation, l'instant où une main ou un pied va le plus loin vers l'avant : le moment du coup (« impact »).
window.animationsGLB = async (liste) => {
  const clips = [], impacts = {};
  let squelette = null;
  for (const { url, nom } of liste) {
    const objet = await fbx.loadAsync(url);
    if (!objet.animations.length) continue;
    const clip = objet.animations[0]; clip.name = nom;
    if (!squelette) squelette = objet;
    clips.push(clip);
  }
  if (!squelette) throw new Error("aucune animation trouvée");
  squelette.traverse((o) => { if (o.isMesh) o.visible = false; });
  const hanches = trouver(squelette, /hips/i);
  const bouts = [/righthand$/i, /lefthand$/i, /rightfoot$/i, /leftfoot$/i].map((m) => trouver(squelette, m)).filter(Boolean);
  const melangeur = new THREE.AnimationMixer(squelette);
  const p = new THREE.Vector3(), h = new THREE.Vector3();
  for (const clip of clips) {
    melangeur.stopAllAction();
    const a = melangeur.clipAction(clip); a.play();
    let meilleur = -Infinity, quand = 0;
    for (let t = 0; t <= clip.duration * 0.8; t += 1 / 30) {
      a.time = t; melangeur.update(0); squelette.updateMatrixWorld(true);
      if (!hanches) break;
      hanches.getWorldPosition(h);
      for (const b of bouts) { b.getWorldPosition(p); if (p.z - h.z > meilleur) { meilleur = p.z - h.z; quand = t; } }
    }
    impacts[clip.name] = Math.round(quand * 100) / 100;
    a.stop();
  }
  // le squelette seul : on retire les maillages du fichier (le robot vient de son propre fichier)
  const aRetirer = []; squelette.traverse((o) => { if (o.isMesh) aRetirer.push(o); });
  for (const m of aRetirer) m.parent.remove(m);
  const glb = await exporter(squelette, clips);
  return { glb: enBase64(glb), animations: clips.map((c) => ({ nom: c.name, duree: Math.round(c.duration * 100) / 100, impact: impacts[c.name] })) };
};
window.pret = true;
